import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import api from '../api/client'
import toast from 'react-hot-toast'
import VisitReportForm from '../components/VisitReportForm.jsx'
import QuoteForm from '../components/QuoteForm.jsx'
import CustomerEditForm from '../components/CustomerEditForm.jsx'

function numberFormat(v) {
  if (v == null) return '-'
  return new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 0 }).format(v)
}

export default function CustomerDetail() {
  const { id } = useParams()
  const qc = useQueryClient()
  const q = useQuery({
    queryKey: ['customer', id],
    queryFn: async () => (await api.get(`/customers/${id}`)).data
  })

  const customer = q.data
  
  // Kullanıcı bilgisini al (admin kontrolü için)
  const userQ = useQuery({
    queryKey: ['current-user'],
    queryFn: async () => (await api.get('/auth/me')).data
  })
  
  const [visitFormOpen, setVisitFormOpen] = useState(false)
  const [showCornerForm, setShowCornerForm] = useState(false)
  const [editingCorner, setEditingCorner] = useState(null)
  const [showQuoteForm, setShowQuoteForm] = useState(false)
  const [showEditForm, setShowEditForm] = useState(false)

  // Köşebent detaylarını getir
  const cornerDetailsQ = useQuery({
    queryKey: ['corner-details', id],
    queryFn: async () => (await api.get(`/customers/${id}/corner-details`)).data,
    enabled: !!id
  })

  async function editCornerDetail(detail) {
    setEditingCorner(detail)
    setShowCornerForm(true)
  }

  async function deleteCornerDetail(detailId) {
    if (!confirm('Bu köşebent detayını silmek istediğinizden emin misiniz?')) return
    
    try {
      await api.delete(`/customers/corner-details/${detailId}`)
      toast.success('Köşebent detayı silindi')
      cornerDetailsQ.refetch()
    } catch (error) {
      toast.error('Silme işlemi başarısız')
    }
  }

  async function deleteCustomer() {
    if (!confirm('Bu müşteriyi kalıcı olarak silmek istediğinizden emin misiniz?\n\nBu işlem geri alınamaz ve tüm köşebent detayları da silinir.')) return
    
    try {
      await api.delete(`/customers/${id}`)
      toast.success('Müşteri silindi')
      // Müşteriler listesine yönlendir
      window.location.href = '/customers'
    } catch (error) {
      toast.error(error.response?.data?.error || 'Silme işlemi başarısız')
    }
  }

  if (q.isLoading) return <div>Yükleniyor...</div>
  if (q.error) return (
    <div className="space-y-4">
      <div>Yüklenirken hata oluştu</div>
      <div className="text-sm text-gray-500">
        {q.error.response?.data?.error || q.error.message}
        {q.error.response?.data?.leadCompany && (
          <div className="mt-2">
            <span className="font-medium">{q.error.response.data.leadCompany}</span> bir lead kaydı. 
            <Link className="text-primary hover:underline ml-1" to="/leads">
              Leads sayfasına git
            </Link>
          </div>
        )}
      </div>
      <Link className="text-sm text-primary hover:underline" to="/customers">← Müşteriler Listesine Dön</Link>
    </div>
  )
  if (!customer) return (
    <div className="space-y-4">
      <div>Müşteri bulunamadı</div>
      <Link className="text-sm text-primary hover:underline" to="/customers">← Müşteriler Listesine Dön</Link>
    </div>
  )

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">{customer.company}</h1>
        <Link className="text-sm text-primary hover:underline" to="/customers">← Listeye Dön</Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <section className="bg-white border rounded p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <Info label="Yetkili" value={customer.contactName} />
              <Info label="Telefon" value={customer.phone || '-'} />
              <Info label="E-posta" value={customer.email || '-'} />
              <Info label="Şehir" value={customer.region?.name || '-'} />
              <Info label="Ortalama Ciro" value={`₺ ${numberFormat(customer.avgRevenue)}`} />
              <Info label="Rakip" value={customer.competitor || '-'} />
              <Info label="Ödeme/Vade" value={customer.paymentTerms || '-'} />
            </div>
            {customer.notes && (
              <div className="mt-4">
                <div className="text-sm text-gray-500 mb-1">Notlar</div>
                <div className="text-sm">{customer.notes}</div>
              </div>
            )}
          </section>

          {/* Köşebent Detayları */}
          <section className="bg-white border rounded p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="font-medium">Köşebent Detayları</div>
              <button
                className="bg-primary text-white px-3 py-1 rounded text-sm hover:opacity-90"
                onClick={() => setShowCornerForm(true)}
              >
                Yeni Köşebent
              </button>
            </div>
            
            <div className="overflow-x-auto border rounded">
              <table className="w-full table-auto">
                <thead className="bg-gray-50">
                  <tr>
                    <Th className="min-w-[80px]">Kanat 1</Th>
                    <Th className="min-w-[80px]">Kanat 2</Th>
                    <Th className="min-w-[100px]">Et Kalınlığı</Th>
                    <Th className="min-w-[80px]">Boy</Th>
                    <Th className="min-w-[60px]">Adet</Th>
                    <Th className="min-w-[100px]">Hedef Fiyat</Th>
                    <Th className="min-w-[120px]">Özellikler</Th>
                    <Th className="min-w-[80px]">Gramaj</Th>
                    <Th className="min-w-[120px]">İşlemler</Th>
                  </tr>
                </thead>
                <tbody>
                  {(cornerDetailsQ.data || []).map((detail) => (
                    <tr key={detail.id} className="border-t hover:bg-gray-50">
                      <Td>{detail.kanat1Mm}mm</Td>
                      <Td>{detail.kanat2Mm}mm</Td>
                      <Td>{detail.etKalinligiMm}mm</Td>
                      <Td>{detail.boyMm}mm</Td>
                      <Td>{detail.adet}</Td>
                      <Td>{detail.hedefFiyatTl ? `₺${numberFormat(detail.hedefFiyatTl)}` : '-'}</Td>
                      <Td>
                        <div className="text-xs space-y-1">
                          {detail.baskiliMi && <div className="bg-blue-100 text-blue-700 px-1 rounded">Baskılı</div>}
                          {detail.centikliMi && <div className="bg-green-100 text-green-700 px-1 rounded">Çentikli</div>}
                          {detail.kilitliMi && <div className="bg-purple-100 text-purple-700 px-1 rounded">Kilitli</div>}
                        </div>
                      </Td>
                      <Td>{detail.gramaji ? `${detail.gramaji}g` : '-'}</Td>
                      <Td>
                        <div className="flex gap-1">
                          <button
                            className="text-xs px-2 py-1 bg-yellow-100 text-yellow-700 rounded hover:bg-yellow-200"
                            onClick={() => editCornerDetail(detail)}
                          >
                            Düzenle
                          </button>
                          <button
                            className="text-xs px-2 py-1 bg-red-100 text-red-700 rounded hover:bg-red-200"
                            onClick={() => deleteCornerDetail(detail.id)}
                          >
                            Sil
                          </button>
                        </div>
                      </Td>
                    </tr>
                  ))}
                  {cornerDetailsQ.data && cornerDetailsQ.data.length === 0 && (
                    <tr><td className="p-4 text-sm text-gray-500" colSpan={9}>Henüz köşebent detayı eklenmemiş</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </section>

          {/* Ziyaret Raporları */}
          <section className="bg-white border rounded p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="font-medium">Ziyaret Raporları</div>
              <button
                className="bg-primary text-white px-3 py-1 rounded text-sm hover:opacity-90"
                onClick={() => setVisitFormOpen(true)}
              >
                Rapor Ekle
              </button>
            </div>
            <div className="text-sm text-gray-500">
              Ziyaret raporları için "Ziyaret Raporları" sayfasını kullanın.
            </div>
          </section>
        </div>

        <div className="space-y-6">
          <section className="bg-white border rounded p-4 space-y-3">
            <div className="font-medium">Hızlı İşlemler</div>
            <div className="flex flex-wrap gap-2">
              <ActionButton label="Ziyaret Raporu Ekle" onClick={() => setVisitFormOpen(true)} />
              <ActionButton label="Köşebent Ekle" onClick={() => setShowCornerForm(true)} />
              <button 
                className="bg-green-600 text-white px-4 py-2 rounded text-sm hover:bg-green-700"
                onClick={() => setShowQuoteForm(true)}
              >
                📄 Teklif Gönder
              </button>
              
              {/* Admin Butonları */}
              {userQ.data?.role === 'ADMIN' && (
                <>
                  <button 
                    className="bg-blue-600 text-white px-4 py-2 rounded text-sm hover:bg-blue-700"
                    onClick={() => setShowEditForm(true)}
                  >
                    ✏️ Düzenle
                  </button>
                  <button 
                    className="bg-red-600 text-white px-4 py-2 rounded text-sm hover:bg-red-700"
                    onClick={deleteCustomer}
                  >
                    🗑️ Sil
                  </button>
                </>
              )}
            </div>
          </section>
        </div>
      </div>

      <VisitReportForm
        open={visitFormOpen}
        customerId={id}
        onClose={(success) => {
          setVisitFormOpen(false)
          if (success) q.refetch()
        }}
      />

      {showCornerForm && (
        <CornerDetailForm
          open={showCornerForm}
          customerId={id}
          detail={editingCorner}
          onClose={(success) => {
            setShowCornerForm(false)
            setEditingCorner(null)
            if (success) cornerDetailsQ.refetch()
          }}
        />
      )}

      <QuoteForm
        open={showQuoteForm}
        customerId={id}
        onClose={(success, quote) => {
          setShowQuoteForm(false)
          if (success && quote) {
            // Teklif oluşturulduktan sonra PDF sayfasına yönlendir
            window.open(`/quote-pdf/${quote.id}`, '_blank')
          }
        }}
      />

      <CustomerEditForm
        open={showEditForm}
        customer={customer}
        onClose={(success) => {
          setShowEditForm(false)
          if (success) {
            q.refetch()
          }
        }}
      />
    </div>
  )
}

function Info({ label, value }) {
  return (
    <div>
      <div className="text-sm text-gray-500">{label}</div>
      <div className="text-sm font-medium">{value}</div>
    </div>
  )
}

function ActionButton({ label, onClick }) {
  return (
    <button
      onClick={onClick}
      className="text-xs px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded"
    >
      {label}
    </button>
  )
}

function Th({ children, className = "" }) {
  return <th className={`text-left text-xs font-medium text-gray-500 uppercase tracking-wider px-3 py-2 ${className}`}>{children}</th>
}

function Td({ children }) {
  return <td className="px-3 py-2 text-sm">{children}</td>
}

// Köşebent Detay Formu - basit versiyon
function CornerDetailForm({ open, customerId, detail, onClose }) {
  const isEdit = !!detail
  const [formData, setFormData] = useState({
    kanat1Mm: detail?.kanat1Mm || '',
    kanat2Mm: detail?.kanat2Mm || '',
    etKalinligiMm: detail?.etKalinligiMm || '',
    boyMm: detail?.boyMm || '',
    adet: detail?.adet || '',
    hedefFiyatTl: detail?.hedefFiyatTl || '',
    baskiliMi: detail?.baskiliMi || false,
    centikliMi: detail?.centikliMi || false,
    kilitliMi: detail?.kilitliMi || false,
    gramaji: detail?.gramaji || ''
  })
  const [loading, setLoading] = useState(false)

  // Form verilerini detail değiştiğinde güncelle
  useEffect(() => {
    if (detail) {
      setFormData({
        kanat1Mm: detail.kanat1Mm || '',
        kanat2Mm: detail.kanat2Mm || '',
        etKalinligiMm: detail.etKalinligiMm || '',
        boyMm: detail.boyMm || '',
        adet: detail.adet || '',
        hedefFiyatTl: detail.hedefFiyatTl || '',
        baskiliMi: detail.baskiliMi || false,
        centikliMi: detail.centikliMi || false,
        kilitliMi: detail.kilitliMi || false,
        gramaji: detail.gramaji || ''
      })
    } else {
      setFormData({
        kanat1Mm: '',
        kanat2Mm: '',
        etKalinligiMm: '',
        boyMm: '',
        adet: '',
        hedefFiyatTl: '',
        baskiliMi: false,
        centikliMi: false,
        kilitliMi: false,
        gramaji: ''
      })
    }
  }, [detail])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    
    try {
      const payload = {
        kanat1Mm: parseFloat(formData.kanat1Mm),
        kanat2Mm: parseFloat(formData.kanat2Mm),
        etKalinligiMm: parseFloat(formData.etKalinligiMm),
        boyMm: parseFloat(formData.boyMm),
        adet: parseInt(formData.adet),
        hedefFiyatTl: formData.hedefFiyatTl ? parseFloat(formData.hedefFiyatTl) : null,
        baskiliMi: formData.baskiliMi,
        centikliMi: formData.centikliMi,
        kilitliMi: formData.kilitliMi,
        gramaji: formData.gramaji ? parseFloat(formData.gramaji) : null
      }

      if (isEdit) {
        await api.put(`/customers/corner-details/${detail.id}`, payload)
        toast.success('Köşebent detayı güncellendi')
      } else {
        await api.post(`/customers/${customerId}/corner-details`, payload)
        toast.success('Köşebent detayı eklendi')
      }
      onClose(true)
    } catch (error) {
      toast.error(isEdit ? 'Güncelleme başarısız' : 'Kayıt başarısız')
    } finally {
      setLoading(false)
    }
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-2xl">
        <h2 className="text-lg font-semibold mb-4">{isEdit ? 'Köşebent Detayı Düzenle' : 'Yeni Köşebent Detayı'}</h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Kanat 1 (mm) *</label>
              <input
                type="number"
                step="0.1"
                value={formData.kanat1Mm}
                onChange={(e) => setFormData({...formData, kanat1Mm: e.target.value})}
                className="w-full border rounded px-3 py-2"
                placeholder="örn: 40"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Kanat 2 (mm) *</label>
              <input
                type="number"
                step="0.1"
                value={formData.kanat2Mm}
                onChange={(e) => setFormData({...formData, kanat2Mm: e.target.value})}
                className="w-full border rounded px-3 py-2"
                placeholder="örn: 40"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Et Kalınlığı (mm) *</label>
              <input
                type="number"
                step="0.1"
                value={formData.etKalinligiMm}
                onChange={(e) => setFormData({...formData, etKalinligiMm: e.target.value})}
                className="w-full border rounded px-3 py-2"
                placeholder="örn: 2.5"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Boy (mm) *</label>
              <input
                type="number"
                step="0.1"
                value={formData.boyMm}
                onChange={(e) => setFormData({...formData, boyMm: e.target.value})}
                className="w-full border rounded px-3 py-2"
                placeholder="örn: 6000"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Adet *</label>
              <input
                type="number"
                value={formData.adet}
                onChange={(e) => setFormData({...formData, adet: e.target.value})}
                className="w-full border rounded px-3 py-2"
                placeholder="örn: 100"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Hedef Fiyat (TL)</label>
              <input
                type="number"
                step="0.01"
                value={formData.hedefFiyatTl}
                onChange={(e) => setFormData({...formData, hedefFiyatTl: e.target.value})}
                className="w-full border rounded px-3 py-2"
                placeholder="örn: 15.50"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Gramaj</label>
            <input
              type="number"
              step="0.1"
              value={formData.gramaji}
              onChange={(e) => setFormData({...formData, gramaji: e.target.value})}
              className="w-full border rounded px-3 py-2"
              placeholder="örn: 250.5"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium">Özellikler</label>
            <div className="flex gap-4">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.baskiliMi}
                  onChange={(e) => setFormData({...formData, baskiliMi: e.target.checked})}
                  className="mr-2"
                />
                Baskılı Mı?
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.centikliMi}
                  onChange={(e) => setFormData({...formData, centikliMi: e.target.checked})}
                  className="mr-2"
                />
                Çentikli Mi?
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.kilitliMi}
                  onChange={(e) => setFormData({...formData, kilitliMi: e.target.checked})}
                  className="mr-2"
                />
                Kilitli Mi?
              </label>
            </div>
          </div>
          
          <div className="flex justify-end gap-2 pt-4">
            <button
              type="button"
              onClick={() => onClose(false)}
              className="px-4 py-2 border rounded hover:bg-gray-50"
            >
              İptal
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 bg-primary text-white rounded hover:opacity-90 disabled:opacity-60"
            >
              {loading ? (isEdit ? 'Güncelleniyor...' : 'Kaydediliyor...') : (isEdit ? 'Güncelle' : 'Kaydet')}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
