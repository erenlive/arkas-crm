import { useQuery } from '@tanstack/react-query'
import api from '../api/client'

export default function Stats() {
  const statsQ = useQuery({
    queryKey: ['stats'],
    queryFn: async () => (await api.get('/dashboard/widgets')).data
  })

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">İstatistikler</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Toplam Lead" value={statsQ.data?.totals?.leadCount ?? '...'} />
        <StatCard title="Toplam Ciro" value={`₺ ${formatNumber(statsQ.data?.totals?.totalAvgRevenue ?? 0)}`} />
        <StatCard title="Son 30 Gün Ziyaret" value={statsQ.data?.totals?.visitCount ?? '...'} />
        <StatCard title="Son 30 Gün Mail" value={statsQ.data?.totals?.sentMailCount ?? '...'} />
      </div>

      <div className="bg-white rounded border p-4">
        <div className="font-medium mb-4">Detaylı İstatistikler</div>
        <div className="text-sm text-gray-500">
          Bu sayfa geliştirilme aşamasındadır. Yakında daha detaylı istatistikler eklenecektir.
        </div>
      </div>
    </div>
  )
}

function StatCard({ title, value }) {
  return (
    <div className="bg-white rounded border p-4">
      <div className="text-sm text-gray-500">{title}</div>
      <div className="text-2xl font-semibold">{value}</div>
    </div>
  )
}

function formatNumber(v) {
  if (v == null) return '0'
  return new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 0 }).format(v)
}
