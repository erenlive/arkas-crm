import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import api from '../api/client'
import VisitReportForm from '../components/VisitReportForm'
import VisitReportViewModal from '../components/VisitReportViewModal'
import toast from 'react-hot-toast'

export default function VisitReports() {
  const [filters, setFilters] = useState({ entityType: '', userId: '' })
  const [formOpen, setFormOpen] = useState(false)
  const [editReport, setEditReport] = useState(null)
  const [viewReport, setViewReport] = useState(null)

  const currentUser = JSON.parse(localStorage.getItem('user') || '{}')

  const usersQ = useQuery({ queryKey: ['users'], queryFn: async () => (await api.get('/users')).data })

  const reportsQ = useQuery({
    queryKey: ['visit-reports', filters],
    queryFn: async () => (await api.get('/visit-reports', { params: clean(filters) })).data
  })

  function update(name, value) { setFilters((f) => ({ ...f, [name]: value })) }

  async function deleteReport(id, title) {
    if (!confirm(`"${title}" adlı ziyaret raporunu silmek istediğinizden emin misiniz?`)) {
      return
    }
    
    try {
      await api.delete(`/visit-reports/${id}`)
      toast.success('Ziyaret raporu silindi')
      reportsQ.refetch()
    } catch (e) {
      toast.error(e.response?.data?.error || 'Silme işlemi başarısız')
    }
  }

  function getEntityLink(report) {
    if (report.entityType === 'lead') {
      return `/leads/${report.entityId}`
    } else {
      return `/customers/${report.entityId}`
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">Ziyaret Raporları</h1>
        <button
          className="bg-primary text-white px-4 py-2 rounded hover:opacity-90"
          onClick={() => setFormOpen(true)}
        >
          Yeni Rapor
        </button>
      </div>

      <div className="bg-white border rounded p-4 grid grid-cols-1 md:grid-cols-4 gap-3">
        <select className="border rounded px-3 py-2" value={filters.entityType} onChange={(e) => update('entityType', e.target.value)}>
          <option value="">Tür (Tümü)</option>
          <option value="lead">Lead</option>
          <option value="customer">Müşteri</option>
        </select>
        <select className="border rounded px-3 py-2" value={filters.userId} onChange={(e) => update('userId', e.target.value)}>
          <option value="">Kullanıcı (Tümü)</option>
          {(usersQ.data || []).map((u) => (
            <option key={u.id} value={u.id}>{u.name}</option>
          ))}
        </select>
        <button className="bg-primary text-white rounded px-4" onClick={() => reportsQ.refetch()}>Uygula</button>
      </div>

      <div className="bg-white border rounded">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <Th>Firma</Th>
                <Th>Başlık</Th>
                <Th>Tarih</Th>
                <Th>Tür</Th>
                <Th>Sonuç</Th>
                <Th>Kullanıcı</Th>
                <Th>İşlemler</Th>
              </tr>
            </thead>
            <tbody>
              {(reportsQ.data || []).map((r) => (
                <tr key={r.id} className="border-t hover:bg-gray-50">
                  <Td><span className="font-medium">{r.company || '-'}</span></Td>
                  <Td>{r.title}</Td>
                  <Td>{new Date(r.date).toLocaleDateString('tr-TR')}</Td>
                  <Td>
                    <span className={`text-xs px-2 py-1 rounded ${r.entityType === 'lead' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'}`}>
                      {r.entityType === 'lead' ? 'Lead' : 'Müşteri'}
                    </span>
                  </Td>
                  <Td>{r.outcome || '-'}</Td>
                  <Td>{r.user?.name || '-'}</Td>
                  <Td>
                    <div className="flex gap-1">
                      <button
                        className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200"
                        onClick={() => setViewReport(r)}
                        title="Oku"
                      >
                        👁️
                      </button>
                      <button
                        className="text-xs px-2 py-1 bg-yellow-100 text-yellow-700 rounded hover:bg-yellow-200"
                        onClick={() => { setEditReport(r); setFormOpen(true); }}
                        title="Düzenle"
                      >
                        ✏️
                      </button>
                      <Link
                        to={getEntityLink(r)}
                        className="text-xs px-2 py-1 bg-green-100 text-green-700 rounded hover:bg-green-200"
                        title={r.entityType === 'lead' ? 'Lead Kartına Git' : 'Müşteri Kartına Git'}
                      >
                        📋
                      </Link>
                      {currentUser.role === 'ADMIN' && (
                        <button
                          className="text-xs px-2 py-1 bg-red-100 text-red-700 rounded hover:bg-red-200"
                          onClick={() => deleteReport(r.id, r.title)}
                          title="Sil"
                        >
                          🗑️
                        </button>
                      )}
                    </div>
                  </Td>
                </tr>
              ))}
              {reportsQ.data && reportsQ.data.length === 0 && (
                <tr><td className="p-4 text-sm text-gray-500" colSpan={7}>Kayıt yok</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      <VisitReportForm
        open={formOpen}
        report={editReport}
        onClose={(success) => {
          setFormOpen(false)
          setEditReport(null)
          if (success) reportsQ.refetch()
        }}
      />
      <VisitReportViewModal
        open={!!viewReport}
        report={viewReport}
        onClose={() => setViewReport(null)}
      />
    </div>
  )
}

function Th({ children }) { return <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider px-4 py-2">{children}</th> }
function Td({ children }) { return <td className="px-4 py-2 text-sm">{children}</td> }
function clean(obj) { const o = {}; Object.keys(obj).forEach(k => { if (obj[k] !== '' && obj[k] != null) o[k] = obj[k] }); return o }
