import { useForm } from 'react-hook-form'
import { useState } from 'react'
import toast from 'react-hot-toast'
import api from '../api/client'

export default function Login() {
  const { register, handleSubmit, formState: { isSubmitting } } = useForm()
  const [remember, setRemember] = useState(true)

  const onSubmit = async (values) => {
    try {
      const { data } = await api.post('/auth/login', { email: values.email, password: values.password })
      localStorage.setItem('token', data.token)
      localStorage.setItem('user', JSON.stringify(data.user))
      if (!remember) {
        // Session only: mimic by storing timestamp and clear on unload (simple approach)
        window.addEventListener('beforeunload', () => {
          localStorage.removeItem('token');
          localStorage.removeItem('user');
        })
      }
      toast.success('Giriş başarılı')
      window.location.href = '/'
    } catch (e) {
      toast.error(e.response?.data?.error || 'Giriş başarısız')
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-white to-blue-50">
      <div className="w-full max-w-md bg-white shadow rounded-lg p-8">
        <div className="text-center mb-6">
          <div className="text-2xl font-semibold text-primary">Arkas Ambalaj CRM</div>
          <div className="text-sm text-gray-500 mt-1">Demo: admin@arkas.com / 123456</div>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">E-posta</label>
            <input type="email" className="w-full border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary" placeholder="you@company.com" {...register('email', { required: true })} />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Şifre</label>
            <input type="password" className="w-full border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary" placeholder="••••••" {...register('password', { required: true })} />
          </div>
          <div className="flex items-center justify-between">
            <label className="inline-flex items-center gap-2 text-sm">
              <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
              Beni hatırla
            </label>
          </div>
          <button disabled={isSubmitting} className="w-full bg-primary text-white py-2 rounded hover:opacity-90 disabled:opacity-60">
            {isSubmitting ? 'Giriş yapılıyor...' : 'Giriş Yap'}
          </button>
        </form>
      </div>
    </div>
  )
}
