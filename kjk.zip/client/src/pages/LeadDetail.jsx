import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useState, useEffect } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import api from '../api/client'
import toast from 'react-hot-toast'
import MailModal from '../components/MailModal.jsx'
import VisitReportForm from '../components/VisitReportForm.jsx'

function numberFormat(v) {
  if (v == null) return '-'
  return new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 0 }).format(v)
}

export default function LeadDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const qc = useQueryClient()
  const q = useQuery({
    queryKey: ['lead', id],
    queryFn: async () => (await api.get(`/leads/${id}`)).data
  })

  const lead = q.data
  const [mailOpen, setMailOpen] = useState(false)
  const [visitFormOpen, setVisitFormOpen] = useState(false)
  const [showCornerForm, setShowCornerForm] = useState(false)
  const [editingCorner, setEditingCorner] = useState(null)

  // Köşebent detaylarını getir
  const cornerDetailsQ = useQuery({
    queryKey: ['lead-corner-details', id],
    queryFn: async () => (await api.get(`/leads/${id}/corner-details`)).data,
    enabled: !!id
  })

  async function deleteLead(id, company) {
    if (!confirm(`"${company}" adlı lead'i silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.`)) {
      return
    }
    
    try {
      await api.delete(`/leads/${id}`)
      toast.success('Lead silindi')
      navigate('/leads')
    } catch (e) {
      toast.error(e.response?.data?.error || 'Silme işlemi başarısız')
    }
  }

  async function editCornerDetail(detail) {
    setEditingCorner(detail)
    setShowCornerForm(true)
  }

  async function deleteCornerDetail(detailId) {
    if (!confirm('Bu köşebent detayını silmek istediğinizden emin misiniz?')) {
      return
    }
    
    try {
      await api.delete(`/customers/corner-details/${detailId}`)
      toast.success('Köşebent detayı silindi')
      cornerDetailsQ.refetch()
    } catch (e) {
      toast.error(e.response?.data?.error || 'Silme işlemi başarısız')
    }
  }

  if (q.isLoading) return <div>Yükleniyor...</div>
  if (q.error) return <div>Yüklenirken hata oluştu</div>
  if (!lead) return <div>Kayıt bulunamadı</div>

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">{lead.company}</h1>
        <div className="flex items-center gap-4">
          {JSON.parse(localStorage.getItem('user') || '{}').role === 'ADMIN' && (
            <button
              className="text-sm text-red-600 hover:underline"
              onClick={() => deleteLead(id, lead.company)}
            >
              Lead'i Sil
            </button>
          )}
          <Link className="text-sm text-primary hover:underline" to="/leads">← Listeye Dön</Link>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <section className="bg-white border rounded p-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <Info label="Yetkili" value={lead.contactName} />
              <Info label="Telefon" value={lead.phone || '-'} />
              <Info label="E-posta" value={lead.email || '-'} />
              <Info label="Şehir" value={lead.region?.name || '-'} />
              <Info label="Ortalama Ciro" value={`₺ ${numberFormat(lead.avgRevenue)}`} />
              <Info label="Durum" value={<StatusBadge status={lead.status} />} />
              <Info label="Rakip" value={lead.competitor || '-'} />
              <Info label="Ödeme/Vade" value={lead.paymentTerms || '-'} />
            </div>
            {lead.notes && (
              <div className="mt-4">
                <div className="text-sm text-gray-500 mb-1">Notlar</div>
                <div className="text-sm">{lead.notes}</div>
              </div>
            )}
          </section>


          {/* Köşebent Detayları */}
          <section className="bg-white border rounded p-4">
            <div className="flex items-center justify-between mb-4">
              <div className="font-medium">Köşebent Detayları</div>
              <button
                className="bg-primary text-white px-3 py-1 rounded text-sm hover:opacity-90"
                onClick={() => setShowCornerForm(true)}
              >
                Yeni Köşebent
              </button>
            </div>
            
            <div className="overflow-x-auto border rounded">
              <table className="w-full table-auto">
                <thead className="bg-gray-50">
                  <tr>
                    <Th className="min-w-[80px]">Kanat 1</Th>
                    <Th className="min-w-[80px]">Kanat 2</Th>
                    <Th className="min-w-[100px]">Et Kalınlığı</Th>
                    <Th className="min-w-[80px]">Boy</Th>
                    <Th className="min-w-[60px]">Adet</Th>
                    <Th className="min-w-[100px]">Hedef Fiyat</Th>
                    <Th className="min-w-[120px]">Özellikler</Th>
                    <Th className="min-w-[80px]">Gramaj</Th>
                    <Th className="min-w-[120px]">İşlemler</Th>
                  </tr>
                </thead>
                <tbody>
                  {(cornerDetailsQ.data || []).map((detail) => (
                    <tr key={detail.id} className="border-t hover:bg-gray-50">
                      <Td>{detail.kanat1Mm}mm</Td>
                      <Td>{detail.kanat2Mm}mm</Td>
                      <Td>{detail.etKalinligiMm}mm</Td>
                      <Td>{detail.boyMm}mm</Td>
                      <Td>{detail.adet}</Td>
                      <Td>{detail.hedefFiyatTl ? `₺${numberFormat(detail.hedefFiyatTl)}` : '-'}</Td>
                      <Td>
                        <div className="text-xs space-y-1">
                          {detail.baskiliMi && <div className="bg-blue-100 text-blue-700 px-1 rounded">Baskılı</div>}
                          {detail.centikliMi && <div className="bg-green-100 text-green-700 px-1 rounded">Çentikli</div>}
                          {detail.kilitliMi && <div className="bg-purple-100 text-purple-700 px-1 rounded">Kilitli</div>}
                        </div>
                      </Td>
                      <Td>{detail.gramaji ? `${detail.gramaji}g` : '-'}</Td>
                      <Td>
                        <div className="flex gap-1">
                          <button
                            className="text-xs px-2 py-1 bg-yellow-100 text-yellow-700 rounded hover:bg-yellow-200"
                            onClick={() => editCornerDetail(detail)}
                          >
                            Düzenle
                          </button>
                          <button
                            className="text-xs px-2 py-1 bg-red-100 text-red-700 rounded hover:bg-red-200"
                            onClick={() => deleteCornerDetail(detail.id)}
                          >
                            Sil
                          </button>
                        </div>
                      </Td>
                    </tr>
                  ))}
                  {cornerDetailsQ.data && cornerDetailsQ.data.length === 0 && (
                    <tr><td className="p-4 text-sm text-gray-500" colSpan={9}>Henüz köşebent detayı eklenmemiş</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </section>

          <section className="bg-white border rounded p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="font-medium">Ziyaret Raporları</div>
              <button
                className="text-sm bg-primary text-white px-3 py-1 rounded hover:opacity-90"
                onClick={() => setVisitFormOpen(true)}
              >
                Rapor Ekle
              </button>
            </div>
            <div className="divide-y">
              {(lead.visitReports || []).map((r) => (
                <div key={r.id} className="py-2">
                  <div className="font-medium">{r.title}</div>
                  <div className="text-sm text-gray-500">{new Date(r.date).toLocaleDateString('tr-TR')} {r.outcome ? ` • ${r.outcome}` : ''}</div>
                  {r.notes && <div className="text-sm mt-1">{r.notes}</div>}
                </div>
              ))}
              {lead.visitReports && lead.visitReports.length === 0 && <div className="text-sm text-gray-500">Kayıt yok</div>}
            </div>
          </section>
        </div>

        <div className="space-y-6">
          <section className="bg-white border rounded p-4 space-y-3">
            <div className="font-medium">Durum</div>
            <div className="flex items-center gap-2">
              <StatusBadge status={lead.status} />
            </div>
            <div className="flex flex-wrap gap-2">
              <ActionButton label="Mail Atıldı" onClick={() => changeStatus(id, 'EMAIL_SENT', qc)} />
              <ActionButton label="Ziyaret Bekliyor" onClick={() => changeStatus(id, 'VISIT_WAITING', qc)} />
              <ActionButton label="Numune Alındı" onClick={() => changeStatus(id, 'SAMPLE_TAKEN', qc)} />
              <ActionButton label="Fiyat Verildi" onClick={() => changeStatus(id, 'PRICE_GIVEN', qc)} />
              <ActionButton label="Kazanıldı" onClick={() => changeStatus(id, 'WON', qc)} />
              <ActionButton label="Fiyat Tutmadı" onClick={() => changeStatus(id, 'PRICE_REJECTED', qc)} />
              <ActionButton label="Mail Gönder" onClick={() => setMailOpen(true)} />
              <ActionButton label="Teklif Ver" onClick={() => navigate(`/quotes/new?leadId=${id}`)} />
              <ActionButton label="Köşebent Ekle" onClick={() => setShowCornerForm(true)} />
            </div>
            <NextAction id={id} current={lead.nextActionDate} qc={qc} />
            <QuickNote id={id} qc={qc} />
            <ConvertButton id={id} />
          </section>

          <section className="bg-white border rounded p-4">
            <div className="font-medium mb-3">Aktiviteler</div>
            <div className="divide-y">
              {(lead.activities || []).map((a) => (
                <div key={a.id} className="py-2 text-sm">
                  <div className="font-medium">{a.activityType}</div>
                  {a.note && <div className="text-gray-600">{a.note}</div>}
                  <div className="text-gray-400">{new Date(a.createdAt).toLocaleString('tr-TR')}</div>
                </div>
              ))}
              {lead.activities && lead.activities.length === 0 && <div className="text-sm text-gray-500">Kayıt yok</div>}
            </div>
          </section>

          <section className="bg-white border rounded p-4">
            <div className="font-medium mb-3">Gönderilen Mailler</div>
            <div className="divide-y">
              {(lead.sentEmails || []).map((m) => (
                <div key={m.id} className="py-2 text-sm">
                  <div className="font-medium">{m.subject}</div>
                  <div className="text-gray-500">{new Date(m.sentAt).toLocaleString('tr-TR')}</div>
                </div>
              ))}
              {lead.sentEmails && lead.sentEmails.length === 0 && <div className="text-sm text-gray-500">Kayıt yok</div>}
            </div>
          </section>
        </div>
      </div>
      <MailModal
        open={mailOpen}
        onClose={async (sent) => {
          setMailOpen(false)
          if (sent) {
            await qc.invalidateQueries({ queryKey: ['lead', id] })
          }
        }}
        lead={lead}
      />
      <VisitReportForm
        open={visitFormOpen}
        leadId={id}
        onClose={(success) => {
          setVisitFormOpen(false)
          if (success) q.refetch()
        }}
      />

      {showCornerForm && (
        <LeadCornerDetailForm
          open={showCornerForm}
          leadId={id}
          detail={editingCorner}
          onClose={(success) => {
            setShowCornerForm(false)
            setEditingCorner(null)
            if (success) cornerDetailsQ.refetch()
          }}
        />
      )}
    </div>
  )
}

function Info({ label, value }) {
  return (
    <div>
      <div className="text-sm text-gray-500">{label}</div>
      <div className="text-sm">{value}</div>
    </div>
  )
}

function Th({ children, className = "" }) {
  return <th className={`text-left text-xs font-medium text-gray-500 uppercase tracking-wider px-3 py-2 ${className}`}>{children}</th>
}

function Td({ children }) {
  return <td className="px-3 py-2 text-sm">{children}</td>
}

function StatusBadge({ status }) {
  const map = {
    TO_CALL: { label: 'Aranacak', color: 'bg-purple-100 text-purple-700' },
    EMAIL_SENT: { label: 'Mail Atıldı, Takipte', color: 'bg-yellow-100 text-yellow-700' },
    VISIT_WAITING: { label: 'Ziyaret Bekliyor', color: 'bg-blue-100 text-blue-700' },
    SAMPLE_TAKEN: { label: 'Numune Alındı', color: 'bg-indigo-100 text-indigo-700' },
    PRICE_GIVEN: { label: 'Fiyat Verildi', color: 'bg-cyan-100 text-cyan-700' },
    WON: { label: 'Müşteri Kazanıldı', color: 'bg-green-100 text-green-700' },
    PRICE_REJECTED: { label: 'Fiyat Tutmadı', color: 'bg-red-100 text-red-700' },
    PAYMENT_ISSUE: { label: 'Ödeme sorunlu', color: 'bg-orange-100 text-orange-700' },
  }
  const s = map[status] || { label: status, color: 'bg-gray-100 text-gray-700' }
  return <span className={`text-xs px-2 py-1 rounded ${s.color}`}>{s.label}</span>
}

async function changeStatus(id, status, qc) {
  try {
    await api.patch(`/leads/${id}/status`, { status })
    toast.success('Durum güncellendi')
    await qc.invalidateQueries({ queryKey: ['lead', id] })
  } catch (e) {
    toast.error(e.response?.data?.error || 'Durum güncelleme hatası')
  }
}

function NextAction({ id, current, qc }) {
  const [value, setValue] = useState(current ? new Date(current).toISOString().slice(0, 10) : '')
  const save = async () => {
    try {
      await api.patch(`/leads/${id}/next-action`, { nextActionDate: value || null })
      toast.success('Sonraki aksiyon kaydedildi')
      await qc.invalidateQueries({ queryKey: ['lead', id] })
    } catch (e) {
      toast.error(e.response?.data?.error || 'Kayıt sırasında hata')
    }
  }
  return (
    <div className="flex items-center gap-2">
      <input type="date" className="border rounded px-2 py-1" value={value} onChange={(e) => setValue(e.target.value)} />
      <ActionButton label="Kaydet" onClick={save} />
    </div>
  )
}

function QuickNote({ id, qc }) {
  const [note, setNote] = useState('')
  const save = async () => {
    if (!note.trim()) return
    try {
      await api.post(`/leads/${id}/activities`, { activityType: 'NOTE', note })
      setNote('')
      toast.success('Not eklendi')
      await qc.invalidateQueries({ queryKey: ['lead', id] })
    } catch (e) {
      toast.error(e.response?.data?.error || 'Not eklenemedi')
    }
  }
  return (
    <div>
      <div className="text-sm text-gray-500 mb-1">Hızlı Not</div>
      <div className="flex gap-2">
        <input className="border rounded px-2 py-1 flex-1" placeholder="Not yazın..." value={note} onChange={(e) => setNote(e.target.value)} />
        <ActionButton label="Ekle" onClick={save} />
      </div>
    </div>
  )
}

function ConvertButton({ id }) {
  const onClick = async () => {
    try {
      const { data } = await api.post(`/leads/${id}/convert-to-customer`)
      toast.success('Müşteriye dönüştürüldü')
    } catch (e) {
      toast.error(e.response?.data?.error || 'Dönüştürme hatası')
    }
  }
  return (
    <button onClick={onClick} className="text-sm px-3 py-2 rounded border border-primary text-primary hover:bg-blue-50">
      Müşteriye Dönüştür
    </button>
  )
}

function ActionButton({ label, onClick }) {
  return (
    <button onClick={onClick} className="text-sm px-3 py-2 rounded bg-primary text-white hover:opacity-90">
      {label}
    </button>
  )
}

// Lead Köşebent Detay Formu
function LeadCornerDetailForm({ open, leadId, detail, onClose }) {
  const isEdit = !!detail
  const [formData, setFormData] = useState({
    kanat1Mm: detail?.kanat1Mm || '',
    kanat2Mm: detail?.kanat2Mm || '',
    etKalinligiMm: detail?.etKalinligiMm || '',
    boyMm: detail?.boyMm || '',
    adet: detail?.adet || '',
    hedefFiyatTl: detail?.hedefFiyatTl || '',
    baskiliMi: detail?.baskiliMi || false,
    centikliMi: detail?.centikliMi || false,
    kilitliMi: detail?.kilitliMi || false,
    gramaji: detail?.gramaji || ''
  })
  const [loading, setLoading] = useState(false)

  // Form verilerini detail değiştiğinde güncelle
  useEffect(() => {
    if (detail) {
      setFormData({
        kanat1Mm: detail.kanat1Mm || '',
        kanat2Mm: detail.kanat2Mm || '',
        etKalinligiMm: detail.etKalinligiMm || '',
        boyMm: detail.boyMm || '',
        adet: detail.adet || '',
        hedefFiyatTl: detail.hedefFiyatTl || '',
        baskiliMi: detail.baskiliMi || false,
        centikliMi: detail.centikliMi || false,
        kilitliMi: detail.kilitliMi || false,
        gramaji: detail.gramaji || ''
      })
    } else {
      setFormData({
        kanat1Mm: '',
        kanat2Mm: '',
        etKalinligiMm: '',
        boyMm: '',
        adet: '',
        hedefFiyatTl: '',
        baskiliMi: false,
        centikliMi: false,
        kilitliMi: false,
        gramaji: ''
      })
    }
  }, [detail])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    
    try {
      const payload = {
        kanat1Mm: parseFloat(formData.kanat1Mm),
        kanat2Mm: parseFloat(formData.kanat2Mm),
        etKalinligiMm: parseFloat(formData.etKalinligiMm),
        boyMm: parseFloat(formData.boyMm),
        adet: parseInt(formData.adet),
        hedefFiyatTl: formData.hedefFiyatTl ? parseFloat(formData.hedefFiyatTl) : null,
        baskiliMi: formData.baskiliMi,
        centikliMi: formData.centikliMi,
        kilitliMi: formData.kilitliMi,
        gramaji: formData.gramaji ? parseFloat(formData.gramaji) : null
      }

      if (isEdit) {
        await api.put(`/customers/corner-details/${detail.id}`, payload)
        toast.success('Köşebent detayı güncellendi')
      } else {
        await api.post(`/leads/${leadId}/corner-details`, payload)
        toast.success('Köşebent detayı eklendi')
      }
      onClose(true)
    } catch (error) {
      toast.error(isEdit ? 'Güncelleme başarısız' : 'Kayıt başarısız')
    } finally {
      setLoading(false)
    }
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-2xl">
        <h2 className="text-lg font-semibold mb-4">{isEdit ? 'Köşebent Detayı Düzenle' : 'Yeni Köşebent Detayı'}</h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Kanat 1 (mm) *</label>
              <input
                type="number"
                step="0.1"
                value={formData.kanat1Mm}
                onChange={(e) => setFormData({...formData, kanat1Mm: e.target.value})}
                className="w-full border rounded px-3 py-2"
                placeholder="örn: 40"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Kanat 2 (mm) *</label>
              <input
                type="number"
                step="0.1"
                value={formData.kanat2Mm}
                onChange={(e) => setFormData({...formData, kanat2Mm: e.target.value})}
                className="w-full border rounded px-3 py-2"
                placeholder="örn: 40"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Et Kalınlığı (mm) *</label>
              <input
                type="number"
                step="0.1"
                value={formData.etKalinligiMm}
                onChange={(e) => setFormData({...formData, etKalinligiMm: e.target.value})}
                className="w-full border rounded px-3 py-2"
                placeholder="örn: 2.5"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Boy (mm) *</label>
              <input
                type="number"
                step="0.1"
                value={formData.boyMm}
                onChange={(e) => setFormData({...formData, boyMm: e.target.value})}
                className="w-full border rounded px-3 py-2"
                placeholder="örn: 6000"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Adet *</label>
              <input
                type="number"
                value={formData.adet}
                onChange={(e) => setFormData({...formData, adet: e.target.value})}
                className="w-full border rounded px-3 py-2"
                placeholder="örn: 100"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Hedef Fiyat (TL)</label>
              <input
                type="number"
                step="0.01"
                value={formData.hedefFiyatTl}
                onChange={(e) => setFormData({...formData, hedefFiyatTl: e.target.value})}
                className="w-full border rounded px-3 py-2"
                placeholder="örn: 15.50"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Gramaj</label>
            <input
              type="number"
              step="0.1"
              value={formData.gramaji}
              onChange={(e) => setFormData({...formData, gramaji: e.target.value})}
              className="w-full border rounded px-3 py-2"
              placeholder="örn: 250.5"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium">Özellikler</label>
            <div className="flex gap-4">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.baskiliMi}
                  onChange={(e) => setFormData({...formData, baskiliMi: e.target.checked})}
                  className="mr-2"
                />
                Baskılı Mı?
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.centikliMi}
                  onChange={(e) => setFormData({...formData, centikliMi: e.target.checked})}
                  className="mr-2"
                />
                Çentikli Mi?
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.kilitliMi}
                  onChange={(e) => setFormData({...formData, kilitliMi: e.target.checked})}
                  className="mr-2"
                />
                Kilitli Mi?
              </label>
            </div>
          </div>
          
          <div className="flex justify-end gap-2 pt-4">
            <button
              type="button"
              onClick={() => onClose(false)}
              className="px-4 py-2 border rounded hover:bg-gray-50"
            >
              İptal
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 bg-primary text-white rounded hover:opacity-90 disabled:opacity-60"
            >
              {loading ? (isEdit ? 'Güncelleniyor...' : 'Kaydediliyor...') : (isEdit ? 'Güncelle' : 'Kaydet')}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
