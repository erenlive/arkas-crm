import { useQuery } from '@tanstack/react-query'
import { useParams } from 'react-router-dom'
import api from '../api/client'

function numberFormat(v) {
  if (v == null) return '-'
  return new Intl.NumberFormat('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(v)
}

function formatDate(date) {
  return new Date(date).toLocaleDateString('tr-TR')
}

export default function QuotePDF() {
  const { id } = useParams()
  
  const q = useQuery({
    queryKey: ['quote', id],
    queryFn: async () => (await api.get(`/quotes/${id}`)).data
  })

  if (q.isLoading) return <div className="p-8">Yükleniyor...</div>
  if (q.error) return <div className="p-8">Hata: {q.error.message}</div>
  if (!q.data) return <div className="p-8">Teklif bulunamadı</div>

  const quote = q.data
  const customer = quote.customer || quote.lead
  
  if (!customer) {
    return <div className="p-8">Müşteri/Lead bilgisi bulunamadı</div>
  }
  const totalAmount = quote.items.reduce((sum, item) => sum + item.totalPrice, 0)
  const vatAmount = totalAmount * 0.20
  const totalWithVat = totalAmount + vatAmount

  const handlePrint = async () => {
    try {
      // Mark quote as downloaded
      await api.patch(`/quotes/${id}/download`)
    } catch (error) {
      console.error('Download tracking failed:', error)
    }
    window.print()
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Print Button - Hidden in print */}
      <div className="no-print p-4 bg-gray-100 border-b">
        <div className="max-w-4xl mx-auto flex justify-between items-center">
          <h1 className="text-xl font-bold">Fiyat Teklifi - {quote.quoteNumber}</h1>
          <button
            onClick={handlePrint}
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
          >
            🖨️ Yazdır / PDF İndir
          </button>
        </div>
      </div>

      {/* PDF Content */}
      <div className="max-w-4xl mx-auto p-8 print:p-6">
        {/* Header */}
        <div className="flex justify-between items-start mb-6">
          {/* Customer Info - Left */}
          <div className="w-1/2">
            <div className="text-base font-medium mb-1">{customer.company}</div>
            <div className="text-lg mb-2">Sayın {customer.contactName || customer.company}</div>
          </div>

          {/* Company Logo and Info - Right */}
          <div className="w-1/2 text-right">
            <img 
              src="http://arkasambalaj.com/images/arkas_logo.png" 
              alt="Arkas Ambalaj Logo"
              className="w-36 h-auto ml-auto mb-3"
              onError={(e) => {e.target.style.display = 'none'}}
            />
            <div className="text-xs space-y-1">
              <div className="font-bold">Arkas Ambalaj San. ve Tic. Ltd. Şti.</div>
              
              {/* Fabrikalar Yan Yana */}
              <div className="grid grid-cols-2 gap-3 mt-2">
                <div>
                  <div className="font-semibold">Gebze Fabrika</div>
                  <div>Tavşanlı, 4506 Sk No:17</div>
                  <div>41400 Gebze/Kocaeli</div>
                  <div>info@arkasambalaj.com</div>
                  <div>+90 262 255 56 54</div>
                  <div>+90 506 346 45 56</div>
                </div>
                
                <div>
                  <div className="font-semibold">Bursa Fabrika</div>
                  <div>Nilüferköy, Nilüfer Cd.</div>
                  <div>No:143/3, 16265 Osmangazi</div>
                  <div>info@arkasambalaj.com</div>
                  <div>+90 262 255 56 54</div>
                  <div>+90 530 766 10 17</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Quote Introduction */}
        <div className="mb-3">
          <div className="text-base">
            Sizler için hazırlamış olduğumuz fiyat teklifimiz aşağıdaki gibidir;
          </div>
        </div>

        {/* Products Table */}
        <div className="mb-4">
          <table className="w-full border-collapse border border-gray-300">
            <thead>
              <tr className="bg-gray-50">
                <th colSpan="4" className="border border-gray-300 px-2 py-1 text-center text-xs font-semibold bg-blue-100">Ürün Ebatları (mm)</th>
                <th rowSpan="2" className="border border-gray-300 px-2 py-1 text-left text-xs font-medium">Köşebent Tipi</th>
                <th rowSpan="2" className="border border-gray-300 px-2 py-1 text-left text-xs font-medium">Baskı</th>
                <th rowSpan="2" className="border border-gray-300 px-2 py-1 text-left text-xs font-medium">Adet</th>
                <th rowSpan="2" className="border border-gray-300 px-2 py-1 text-left text-xs font-medium">Birim Fiyat (TL/Adet)</th>
                <th rowSpan="2" className="border border-gray-300 px-2 py-1 text-left text-xs font-medium">Toplam (TL)</th>
              </tr>
              <tr className="bg-gray-100">
                <th className="border border-gray-300 px-2 py-1 text-left text-xs font-medium">Kanat 1</th>
                <th className="border border-gray-300 px-2 py-1 text-left text-xs font-medium">Kanat 2</th>
                <th className="border border-gray-300 px-2 py-1 text-left text-xs font-medium">Et Kalınlığı</th>
                <th className="border border-gray-300 px-2 py-1 text-left text-xs font-medium">Uzunluk</th>
              </tr>
            </thead>
            <tbody>
              {quote.items.map((item, index) => (
                <tr key={index}>
                  <td className="border border-gray-300 px-2 py-1 text-sm">{item.kanat1Mm}</td>
                  <td className="border border-gray-300 px-2 py-1 text-sm">{item.kanat2Mm}</td>
                  <td className="border border-gray-300 px-2 py-1 text-sm">{item.etKalinligiMm}</td>
                  <td className="border border-gray-300 px-2 py-1 text-sm">{item.boyMm}</td>
                  <td className="border border-gray-300 px-2 py-1 text-sm">{item.cornerType}</td>
                  <td className="border border-gray-300 px-2 py-1 text-sm">{item.hasPrint ? 'Var' : 'Yok'}</td>
                  <td className="border border-gray-300 px-2 py-1 text-sm">{numberFormat(item.quantity)}</td>
                  <td className="border border-gray-300 px-2 py-1 text-sm">₺{numberFormat(item.unitPrice)}</td>
                  <td className="border border-gray-300 px-2 py-1 text-sm font-medium">₺{numberFormat(item.totalPrice)}</td>
                </tr>
              ))}
              <tr className="bg-gray-50">
                <td colSpan="8" className="border border-gray-300 px-2 py-1 text-sm font-bold text-right">KDV Hariç Toplam:</td>
                <td className="border border-gray-300 px-2 py-1 text-sm font-bold">₺{numberFormat(totalAmount)}</td>
              </tr>
              <tr className="bg-gray-50">
                <td colSpan="8" className="border border-gray-300 px-2 py-1 text-sm font-bold text-right">%20 KDV:</td>
                <td className="border border-gray-300 px-2 py-1 text-sm font-bold">₺{numberFormat(vatAmount)}</td>
              </tr>
              <tr className="bg-gray-100">
                <td colSpan="8" className="border border-gray-300 px-2 py-1 text-sm font-bold text-right">KDV Dahil Toplam:</td>
                <td className="border border-gray-300 px-2 py-1 text-sm font-bold">₺{numberFormat(totalWithVat)}</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Footer Info */}
        <div className="flex justify-between items-end mb-4">
          <div className="w-2/3">
            <div className="text-sm font-bold mb-2">Teklif Koşulları</div>
            <div className="text-xs space-y-1 leading-relaxed">
              <div>◉ Fiyatlarımıza KDV Dahil değildir.</div>
              <div>◉ Fiyatlarımızda nakliye bedeli {quote.shippingIncluded ? 'dahildir' : 'dahil değildir'}.</div>
              <div>◉ Ödeme: Fatura tarihi itibariyle {quote.paymentTerms} - {quote.paymentMethod}dir.</div>
              <div>◉ Termin: Belirtilmemesi halinde 10 iş günüdür.</div>
              <div>◉ Vadesinde gerçekleşmeyen ödemeler için aylık %5 vade farkı uygulanır.</div>
              <div>◉ Firmamızdan teyit alınmadan kesilen iade faturaları kabul edilmez.</div>
              <div>◉ Hammadde, nakliye ve döviz kurlarında öngörülemeyen artışlarda teklifimiz geçersizdir.</div>
              <div>◉ Sipariş veren müşterilerimiz fiyat teklifinde yer alan şartları kabul etmiş olur.</div>
            </div>
          </div>

          <div className="w-1/3 text-right">
            <div className="text-sm mb-4">
              <div><strong>Teklif Tarihi:</strong> {formatDate(quote.createdAt)}</div>
              <div><strong>Geçerlilik:</strong> {formatDate(quote.validUntil)}</div>
            </div>
            <div className="text-sm">
              <div className="mb-2">Saygılarımızla,</div>
              <div className="font-medium">{quote.creator.name}</div>
              {quote.creator.position && (
                <div className="text-xs text-gray-600">{quote.creator.position}</div>
              )}
              <div className="text-xs">{quote.creator.email}</div>
              {quote.creator.phone && (
                <div className="text-xs">{quote.creator.phone}</div>
              )}
            </div>
          </div>
        </div>

        {/* Sustainability Message */}
        <div className="mb-3">
          <div className="text-xs">
            Arkas Ambalaj Ürünleri; Birleşmiş Milletler Sürdürülebilir Kalkınma Amaçları (SDG) ve Avrupa Birliği Yeşil Mutabakatı ile uyumludur.
          </div>
        </div>


        {/* Bottom Footer */}
        <div className="flex justify-between items-center text-xs text-gray-600 border-t pt-4">
          <div>Arkas Ambalaj San ve Tic Ltd Şti.</div>
          <div>Teklif Form: 1.03</div>
        </div>
      </div>

      <style jsx>{`
        @media print {
          .no-print {
            display: none !important;
          }
          
          * {
            visibility: hidden;
          }
          
          .max-w-4xl, .max-w-4xl * {
            visibility: visible;
          }
          
          .max-w-4xl {
            position: absolute;
            left: 0;
            top: 0;
            width: 100% !important;
            max-width: none !important;
            margin: 0 !important;
            padding: 20mm !important;
          }
          
          @page {
            size: A4;
            margin: 0;
          }
          
          body {
            margin: 0;
            padding: 0;
            font-size: 12pt;
          }
          
          table {
            page-break-inside: auto;
            font-size: 9pt;
          }
          
          tr {
            page-break-inside: avoid;
            line-height: 1.2;
          }
          
          tbody tr {
            height: auto;
          }
          
          .text-xs {
            font-size: 8pt !important;
          }
          
          .text-sm {
            font-size: 10pt !important;
          }
          
          .text-base {
            font-size: 12pt !important;
          }
          
          .text-lg {
            font-size: 14pt !important;
          }
        }
      `}</style>
    </div>
  )
}
