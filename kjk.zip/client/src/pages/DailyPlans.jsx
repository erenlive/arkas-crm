import { useState, useEffect } from 'react'
import api from '../api/client'
import toast from 'react-hot-toast'
import PlanModal from '../components/PlanModal'

const HOURS = [9, 10, 11, 12, 13, 14, 15, 16, 17]
const DAYS = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar']

export default function DailyPlans() {
  const [currentWeek, setCurrentWeek] = useState(new Date())
  const [plans, setPlans] = useState([])
  const [loading, setLoading] = useState(false)
  const [modalOpen, setModalOpen] = useState(false)
  const [selectedSlot, setSelectedSlot] = useState(null)
  const [editingPlan, setEditingPlan] = useState(null)

  // Get Monday of current week
  const getMonday = (date) => {
    const d = new Date(date)
    const day = d.getDay()
    const diff = d.getDate() - day + (day === 0 ? -6 : 1)
    return new Date(d.setDate(diff))
  }

  // Get week dates
  const getWeekDates = () => {
    const monday = getMonday(currentWeek)
    const dates = []
    for (let i = 0; i < 7; i++) {
      const date = new Date(monday)
      date.setDate(monday.getDate() + i)
      dates.push(date)
    }
    return dates
  }

  // Format date for API
  const formatDate = (date) => {
    return date.toISOString().split('T')[0]
  }

  // Format date for display
  const formatDisplayDate = (date) => {
    return date.toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit' })
  }

  // Load plans for current week
  const loadPlans = async () => {
    setLoading(true)
    try {
      const monday = getMonday(currentWeek)
      const { data } = await api.get(`/daily-plans/week/${formatDate(monday)}`)
      setPlans(data)
    } catch (error) {
      toast.error('Planlar yüklenirken hata oluştu')
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadPlans()
  }, [currentWeek])

  // Navigate weeks
  const goToPreviousWeek = () => {
    const newWeek = new Date(currentWeek)
    newWeek.setDate(currentWeek.getDate() - 7)
    setCurrentWeek(newWeek)
  }

  const goToNextWeek = () => {
    const newWeek = new Date(currentWeek)
    newWeek.setDate(currentWeek.getDate() + 7)
    setCurrentWeek(newWeek)
  }

  const goToCurrentWeek = () => {
    setCurrentWeek(new Date())
  }

  // Get plan for specific date and hour
  const getPlan = (date, hour) => {
    return plans.find(plan => {
      const planDate = new Date(plan.date).toDateString()
      const slotDate = date.toDateString()
      return planDate === slotDate && plan.hour === hour
    })
  }

  // Handle slot click
  const handleSlotClick = (date, hour) => {
    const existingPlan = getPlan(date, hour)
    if (existingPlan) {
      setEditingPlan(existingPlan)
    } else {
      setSelectedSlot({ date, hour })
    }
    setModalOpen(true)
  }

  // Handle plan save
  const handlePlanSave = () => {
    setModalOpen(false)
    setSelectedSlot(null)
    setEditingPlan(null)
    loadPlans()
  }

  // Handle plan delete
  const handlePlanDelete = () => {
    setModalOpen(false)
    setEditingPlan(null)
    loadPlans()
  }

  const weekDates = getWeekDates()

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Günlük Planlama</h1>
        
        <div className="flex items-center gap-4">
          <button
            onClick={goToPreviousWeek}
            className="px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
          >
            ← Önceki Hafta
          </button>
          
          <button
            onClick={goToCurrentWeek}
            className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
          >
            Bu Hafta
          </button>
          
          <button
            onClick={goToNextWeek}
            className="px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
          >
            Sonraki Hafta →
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          {/* Header with days */}
          <div className="grid grid-cols-8 bg-gray-50 border-b">
            <div className="p-3 font-medium text-gray-700 border-r">Saat</div>
            {weekDates.map((date, index) => (
              <div key={index} className="p-3 text-center border-r last:border-r-0">
                <div className="font-medium text-gray-700">{DAYS[index]}</div>
                <div className="text-sm text-gray-500">{formatDisplayDate(date)}</div>
              </div>
            ))}
          </div>

          {/* Time slots */}
          {HOURS.map(hour => (
            <div key={hour} className="grid grid-cols-8 border-b last:border-b-0">
              <div className="p-3 font-medium text-gray-600 border-r bg-gray-50">
                {hour}:00
              </div>
              {weekDates.map((date, dayIndex) => {
                const plan = getPlan(date, hour)
                const isToday = date.toDateString() === new Date().toDateString()
                const isPast = date < new Date() && hour < new Date().getHours()
                
                return (
                  <div
                    key={`${dayIndex}-${hour}`}
                    onClick={() => !isPast && handleSlotClick(date, hour)}
                    className={`
                      p-2 border-r last:border-r-0 min-h-[60px] cursor-pointer transition-colors
                      ${isToday ? 'bg-blue-50' : 'bg-white'}
                      ${isPast ? 'bg-gray-100 cursor-not-allowed opacity-60' : 'hover:bg-gray-50'}
                      ${plan ? 'bg-green-50 hover:bg-green-100' : ''}
                    `}
                  >
                    {plan && (
                      <div className="text-xs">
                        <div className="font-medium text-gray-800 mb-1 truncate">
                          {plan.title}
                        </div>
                        <div className="text-gray-600 truncate">
                          {plan.customerName && (
                            <span className="text-blue-600">{plan.customerName}</span>
                          )}
                        </div>
                        <div className="flex items-center gap-1 mt-1">
                          <span className={`
                            inline-block w-2 h-2 rounded-full
                            ${plan.type === 'MEETING' ? 'bg-blue-400' : ''}
                            ${plan.type === 'CALL' ? 'bg-green-400' : ''}
                            ${plan.type === 'VISIT' ? 'bg-purple-400' : ''}
                            ${plan.type === 'NOTE' ? 'bg-yellow-400' : ''}
                          `}></span>
                          {plan.completed && (
                            <span className="text-green-600 text-xs">✓</span>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          ))}
        </div>
      )}

      {/* Legend */}
      <div className="mt-4 flex flex-wrap gap-4 text-sm text-gray-600">
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 bg-blue-400 rounded-full"></span>
          <span>Toplantı</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 bg-green-400 rounded-full"></span>
          <span>Arama</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 bg-purple-400 rounded-full"></span>
          <span>Ziyaret</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 bg-yellow-400 rounded-full"></span>
          <span>Not</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-green-600">✓</span>
          <span>Tamamlandı</span>
        </div>
      </div>

      {/* Plan Modal */}
      <PlanModal
        open={modalOpen}
        onClose={() => {
          setModalOpen(false)
          setSelectedSlot(null)
          setEditingPlan(null)
        }}
        selectedSlot={selectedSlot}
        editingPlan={editingPlan}
        onSave={handlePlanSave}
        onDelete={handlePlanDelete}
      />
    </div>
  )
}
