import { useEffect, useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import api from '../api/client'
import LeadForm from '../components/LeadForm'
import toast from 'react-hot-toast'

const STATUSES = [
  { value: '', label: 'Tümü' },
  { value: 'TO_CALL', label: 'Aranacak' },
  { value: 'EMAIL_SENT', label: 'Mail Atıldı, Takipte' },
  { value: 'VISIT_WAITING', label: 'Ziyaret Bekliyor' },
  { value: 'SAMPLE_TAKEN', label: 'Numune Alındı, Fiyat verilecek' },
  { value: 'PRICE_GIVEN', label: 'Fiyat Verildi Takipte' },
  { value: 'WON', label: 'Müşteri Kazanıldı' },
  { value: 'PRICE_REJECTED', label: 'Fiyat Tutmadı' },
  { value: 'PAYMENT_ISSUE', label: 'Ödeme sorunlu' },
]

export default function Leads() {
  const [filters, setFilters] = useState({ q: '', status: '', regionId: '', ownerUserId: '' })
  const [formOpen, setFormOpen] = useState(false)
  const [editLead, setEditLead] = useState(null)

  const regionsQ = useQuery({
    queryKey: ['regions'],
    queryFn: async () => (await api.get('/regions')).data
  })
  const usersQ = useQuery({
    queryKey: ['users'],
    queryFn: async () => (await api.get('/users')).data
  })

  const leadsQ = useQuery({
    queryKey: ['leads', filters],
    queryFn: async () => (await api.get('/leads', { params: clean(filters) })).data
  })

  function update(name, value) {
    setFilters((f) => ({ ...f, [name]: value }))
  }

  async function deleteLead(id, company) {
    if (!confirm(`"${company}" adlı lead'i silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.`)) {
      return
    }
    
    try {
      await api.delete(`/leads/${id}`)
      toast.success('Lead silindi')
      leadsQ.refetch()
    } catch (e) {
      toast.error(e.response?.data?.error || 'Silme işlemi başarısız')
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">Leads</h1>
        <button
          className="bg-primary text-white px-4 py-2 rounded hover:opacity-90"
          onClick={() => { setEditLead(null); setFormOpen(true); }}
        >
          Yeni Lead
        </button>
      </div>

      <div className="bg-white border rounded p-4 grid grid-cols-1 md:grid-cols-5 gap-3">
        <input
          className="border rounded px-3 py-2"
          placeholder="Firma, yetkili, e-posta"
          value={filters.q}
          onChange={(e) => update('q', e.target.value)}
        />
        <select className="border rounded px-3 py-2" value={filters.status} onChange={(e) => update('status', e.target.value)}>
          {STATUSES.map((s) => (
            <option key={s.value} value={s.value}>{s.label}</option>
          ))}
        </select>
        <select className="border rounded px-3 py-2" value={filters.regionId} onChange={(e) => update('regionId', e.target.value)}>
          <option value="">Şehir (Tümü)</option>
          {(regionsQ.data || []).map((r) => (
            <option key={r.id} value={r.id}>{r.name}</option>
          ))}
        </select>
        <select className="border rounded px-3 py-2" value={filters.ownerUserId} onChange={(e) => update('ownerUserId', e.target.value)}>
          <option value="">Sahip (Tümü)</option>
          {(usersQ.data || []).map((u) => (
            <option key={u.id} value={u.id}>{u.name}</option>
          ))}
        </select>
        <button className="bg-primary text-white rounded px-4" onClick={() => leadsQ.refetch()}>
          Uygula
        </button>
      </div>

      <div className="bg-white border rounded">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <Th>Firma</Th>
                <Th>Yetkili</Th>
                <Th>Şehir</Th>
                <Th>Durum</Th>
                <Th>Ortalama Ciro</Th>
                <Th>Sahip</Th>
                <Th>İşlemler</Th>
              </tr>
            </thead>
            <tbody>
              {(leadsQ.data || []).map((l) => (
                <tr key={l.id} className="border-t hover:bg-gray-50">
                  <Td><a className="text-primary hover:underline" href={`/leads/${l.id}`}>{l.company}</a></Td>
                  <Td>{l.contactName}</Td>
                  <Td>{l.region?.name || '-'}</Td>
                  <Td><StatusBadge status={l.status} /></Td>
                  <Td>₺ {formatNumber(l.avgRevenue)}</Td>
                  <Td>{l.owner?.name || '-'}</Td>
                  <Td>
                    <div className="flex gap-2">
                      <button
                        className="text-sm text-primary hover:underline"
                        onClick={() => { setEditLead(l); setFormOpen(true); }}
                      >
                        Düzenle
                      </button>
                      {JSON.parse(localStorage.getItem('user') || '{}').role === 'ADMIN' && (
                        <button
                          className="text-sm text-red-600 hover:underline"
                          onClick={() => deleteLead(l.id, l.company)}
                        >
                          Sil
                        </button>
                      )}
                    </div>
                  </Td>
                </tr>
              ))}
              {leadsQ.data && leadsQ.data.length === 0 && (
                <tr><td className="p-4 text-sm text-gray-500" colSpan={7}>Kayıt bulunamadı</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      <LeadForm
        open={formOpen}
        lead={editLead}
        onClose={(success) => {
          setFormOpen(false)
          setEditLead(null)
          if (success) leadsQ.refetch()
        }}
      />
    </div>
  )
}

function Th({ children }) {
  return <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider px-4 py-2">{children}</th>
}

function Td({ children }) {
  return <td className="px-4 py-2 text-sm">{children}</td>
}

function StatusBadge({ status }) {
  const map = {
    TO_CALL: { label: 'Aranacak', color: 'bg-purple-100 text-purple-700' },
    EMAIL_SENT: { label: 'Mail Atıldı, Takipte', color: 'bg-yellow-100 text-yellow-700' },
    VISIT_WAITING: { label: 'Ziyaret Bekliyor', color: 'bg-blue-100 text-blue-700' },
    SAMPLE_TAKEN: { label: 'Numune Alındı', color: 'bg-indigo-100 text-indigo-700' },
    PRICE_GIVEN: { label: 'Fiyat Verildi', color: 'bg-cyan-100 text-cyan-700' },
    WON: { label: 'Müşteri Kazanıldı', color: 'bg-green-100 text-green-700' },
    PRICE_REJECTED: { label: 'Fiyat Tutmadı', color: 'bg-red-100 text-red-700' },
    PAYMENT_ISSUE: { label: 'Ödeme sorunlu', color: 'bg-orange-100 text-orange-700' },
  }
  const s = map[status] || { label: status, color: 'bg-gray-100 text-gray-700' }
  return <span className={`text-xs px-2 py-1 rounded ${s.color}`}>{s.label}</span>
}

function clean(obj) {
  const o = {}
  Object.keys(obj).forEach((k) => {
    if (obj[k] !== '' && obj[k] != null) o[k] = obj[k]
  })
  return o
}

function formatNumber(v) {
  if (v == null) return '-'
  try { return new Intl.NumberFormat('tr-TR').format(v) } catch { return v }
}
