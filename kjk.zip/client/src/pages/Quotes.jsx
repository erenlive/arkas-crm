import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { Link } from 'react-router-dom'
import api from '../api/client'
import toast from 'react-hot-toast'

function numberFormat(v) {
  if (v == null) return '-'
  return new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 2 }).format(v)
}

function formatDate(date) {
  return new Date(date).toLocaleDateString('tr-TR')
}

const STATUS_LABELS = {
  'DRAFT': 'Taslak',
  'SENT': 'Gönderildi'
}

const RESULT_LABELS = {
  'PENDING': 'Beklemede',
  'ACCEPTED': 'Sipariş Alındı',
  'REJECTED': 'Kabul Edilmedi'
}

const STATUS_COLORS = {
  'DRAFT': 'bg-gray-100 text-gray-700',
  'SENT': 'bg-blue-100 text-blue-700'
}

const RESULT_COLORS = {
  'PENDING': 'bg-yellow-100 text-yellow-700',
  'ACCEPTED': 'bg-green-100 text-green-700',
  'REJECTED': 'bg-red-100 text-red-700'
}

export default function Quotes() {
  const qc = useQueryClient()
  const [selectedQuote, setSelectedQuote] = useState(null)
  const [showStatusModal, setShowStatusModal] = useState(false)

  const q = useQuery({
    queryKey: ['quotes'],
    queryFn: async () => (await api.get('/quotes')).data
  })

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status, result }) => {
      return api.patch(`/quotes/${id}/status`, { status, result })
    },
    onSuccess: () => {
      toast.success('Teklif durumu güncellendi')
      qc.invalidateQueries(['quotes'])
      setShowStatusModal(false)
    },
    onError: (error) => {
      toast.error('Güncelleme başarısız: ' + error.response?.data?.error)
    }
  })

  const deleteMutation = useMutation({
    mutationFn: async (id) => {
      return api.delete(`/quotes/${id}`)
    },
    onSuccess: () => {
      toast.success('Teklif silindi')
      qc.invalidateQueries(['quotes'])
    },
    onError: (error) => {
      toast.error('Silme başarısız: ' + error.response?.data?.error)
    }
  })

  const handleStatusUpdate = (quote) => {
    setSelectedQuote(quote)
    setShowStatusModal(true)
  }

  const handleDelete = (quote) => {
    const companyName = quote.customer?.company || quote.lead?.company || 'Bilinmeyen Firma'
    if (window.confirm(`"${companyName}" firmasının teklifini silmek istediğinizden emin misiniz?`)) {
      deleteMutation.mutate(quote.id)
    }
  }

  const submitStatusUpdate = (e) => {
    e.preventDefault()
    const formData = new FormData(e.target)
    updateStatusMutation.mutate({
      id: selectedQuote.id,
      status: formData.get('status'),
      result: formData.get('result')
    })
  }

  // Check if user is admin
  const user = JSON.parse(localStorage.getItem('user') || '{}')
  const isAdmin = user.role === 'ADMIN'

  if (q.isLoading) return <div>Yükleniyor...</div>
  if (q.error) return <div>Hata: {q.error.message}</div>

  const quotes = q.data || []

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold">Teklifler</h1>
      </div>

      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Firma Adı
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Teklif Durumu
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Teklif Sonucu
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Teklif Cirosu
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Teklifi Gönderen
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Tarih
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  İşlemler
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {quotes.map((quote) => {
                const totalAmount = quote.items?.reduce((sum, item) => sum + item.totalPrice, 0) || quote.totalAmount || 0
                return (
                  <tr key={quote.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {quote.customer?.company || quote.lead?.company || 'Bilinmeyen Firma'}
                        {quote.lead && (
                          <span className="ml-2 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                            Lead
                          </span>
                        )}
                      </div>
                      {(quote.customer?.contactName || quote.lead?.contactName) && (
                        <div className="text-sm text-gray-500">
                          {quote.customer?.contactName || quote.lead?.contactName}
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${STATUS_COLORS[quote.status]}`}>
                        {STATUS_LABELS[quote.status]}
                      </span>
                      {quote.downloadedAt && (
                        <div className="text-xs text-gray-500 mt-1">
                          PDF İndirildi: {formatDate(quote.downloadedAt)}
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${RESULT_COLORS[quote.result]}`}>
                        {RESULT_LABELS[quote.result]}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      ₺{numberFormat(totalAmount)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {quote.creator.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {formatDate(quote.createdAt)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                      <Link
                        to={`/quote-pdf/${quote.id}`}
                        className="text-blue-600 hover:text-blue-900"
                        target="_blank"
                      >
                        İncele
                      </Link>
                      <button
                        onClick={() => handleStatusUpdate(quote)}
                        className="text-green-600 hover:text-green-900"
                      >
                        Durum
                      </button>
                      {isAdmin && (
                        <button
                          onClick={() => handleDelete(quote)}
                          className="text-red-600 hover:text-red-900"
                          disabled={deleteMutation.isLoading}
                        >
                          {deleteMutation.isLoading ? 'Siliniyor...' : 'Sil'}
                        </button>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        {quotes.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-500">Henüz teklif bulunmuyor</div>
          </div>
        )}
      </div>

      {/* Status Update Modal */}
      {showStatusModal && selectedQuote && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-medium mb-4">Teklif Durumunu Güncelle</h3>
            <form onSubmit={submitStatusUpdate} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Teklif Durumu</label>
                <select
                  name="status"
                  defaultValue={selectedQuote.status}
                  className="w-full border rounded px-3 py-2"
                  required
                >
                  <option value="DRAFT">Taslak</option>
                  <option value="SENT">Gönderildi</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Teklif Sonucu</label>
                <select
                  name="result"
                  defaultValue={selectedQuote.result}
                  className="w-full border rounded px-3 py-2"
                  required
                >
                  <option value="PENDING">Beklemede</option>
                  <option value="ACCEPTED">Sipariş Alındı</option>
                  <option value="REJECTED">Kabul Edilmedi</option>
                </select>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowStatusModal(false)}
                  className="px-4 py-2 border rounded hover:bg-gray-50"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  disabled={updateStatusMutation.isLoading}
                  className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-60"
                >
                  {updateStatusMutation.isLoading ? 'Güncelleniyor...' : 'Güncelle'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
