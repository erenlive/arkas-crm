import { useState, useEffect } from 'react'
import { useSearchParams, useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import api from '../api/client'
import QuoteForm from '../components/QuoteForm'

export default function NewQuote() {
  const [searchParams] = useSearchParams()
  const navigate = useNavigate()
  const leadId = searchParams.get('leadId')
  const customerId = searchParams.get('customerId')

  // Lead bilgisini getir (eğer leadId varsa)
  const leadQuery = useQuery({
    queryKey: ['lead', leadId],
    queryFn: async () => (await api.get(`/leads/${leadId}`)).data,
    enabled: !!leadId
  })

  // Customer bilgisini getir (eğer customerId varsa)
  const customerQuery = useQuery({
    queryKey: ['customer', customerId],
    queryFn: async () => (await api.get(`/customers/${customerId}`)).data,
    enabled: !!customerId
  })

  const handleClose = (success, quote) => {
    if (success && quote) {
      // Teklif başarıyla oluşturuldu, PDF sayfasına yönlendir
      navigate(`/quote-pdf/${quote.id}`)
    } else {
      // İptal edildi, geri git
      navigate(-1)
    }
  }

  const entity = leadQuery.data || customerQuery.data
  const entityType = leadId ? 'Lead' : 'Müşteri'

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Yeni Teklif</h1>
          {entity && (
            <p className="text-gray-600 mt-1">
              {entityType}: <span className="font-medium">{entity.company}</span>
              {entity.contactName && (
                <span className="text-gray-500"> - {entity.contactName}</span>
              )}
            </p>
          )}
        </div>
        <button
          onClick={() => navigate(-1)}
          className="px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
        >
          ← Geri
        </button>
      </div>

      <QuoteForm
        open={true}
        customerId={customerId}
        leadId={leadId}
        onClose={handleClose}
        isModal={false}
      />
    </div>
  )
}
