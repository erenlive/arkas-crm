import { useState, useEffect } from 'react'
import api from '../api/client'
import toast from 'react-hot-toast'

const HOURS = [9, 10, 11, 12, 13, 14, 15, 16, 17]
const DAYS = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar']

export default function AdminPlans() {
  const [currentWeek, setCurrentWeek] = useState(new Date())
  const [plans, setPlans] = useState([])
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(false)
  const [selectedUser, setSelectedUser] = useState('all')

  // Get Monday of current week
  const getMonday = (date) => {
    const d = new Date(date)
    const day = d.getDay()
    const diff = d.getDate() - day + (day === 0 ? -6 : 1)
    return new Date(d.setDate(diff))
  }

  // Get week dates
  const getWeekDates = () => {
    const monday = getMonday(currentWeek)
    const dates = []
    for (let i = 0; i < 7; i++) {
      const date = new Date(monday)
      date.setDate(monday.getDate() + i)
      dates.push(date)
    }
    return dates
  }

  // Format date for API
  const formatDate = (date) => {
    return date.toISOString().split('T')[0]
  }

  // Format date for display
  const formatDisplayDate = (date) => {
    return date.toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit' })
  }

  // Load users
  const loadUsers = async () => {
    try {
      const { data } = await api.get('/users')
      setUsers(data)
    } catch (error) {
      toast.error('Kullanıcılar yüklenirken hata oluştu')
    }
  }

  // Load plans for current week
  const loadPlans = async () => {
    setLoading(true)
    try {
      const monday = getMonday(currentWeek)
      const { data } = await api.get(`/daily-plans/admin/week/${formatDate(monday)}`)
      setPlans(data)
    } catch (error) {
      toast.error('Planlar yüklenirken hata oluştu')
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadUsers()
  }, [])

  useEffect(() => {
    loadPlans()
  }, [currentWeek])

  // Navigate weeks
  const goToPreviousWeek = () => {
    const newWeek = new Date(currentWeek)
    newWeek.setDate(currentWeek.getDate() - 7)
    setCurrentWeek(newWeek)
  }

  const goToNextWeek = () => {
    const newWeek = new Date(currentWeek)
    newWeek.setDate(currentWeek.getDate() + 7)
    setCurrentWeek(newWeek)
  }

  const goToCurrentWeek = () => {
    setCurrentWeek(new Date())
  }

  // Filter plans by user
  const filteredPlans = selectedUser === 'all' 
    ? plans 
    : plans.filter(plan => plan.userId === selectedUser)

  // Get plans for specific date and hour
  const getPlansForSlot = (date, hour) => {
    return filteredPlans.filter(plan => {
      const planDate = new Date(plan.date).toDateString()
      const slotDate = date.toDateString()
      return planDate === slotDate && plan.hour === hour
    })
  }

  const weekDates = getWeekDates()

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Admin - Tüm Planlar</h1>
        
        <div className="flex items-center gap-4">
          {/* User Filter */}
          <select
            value={selectedUser}
            onChange={(e) => setSelectedUser(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">Tüm Kullanıcılar</option>
            {users.map(user => (
              <option key={user.id} value={user.id}>{user.name}</option>
            ))}
          </select>

          <button
            onClick={goToPreviousWeek}
            className="px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
          >
            ← Önceki Hafta
          </button>
          
          <button
            onClick={goToCurrentWeek}
            className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
          >
            Bu Hafta
          </button>
          
          <button
            onClick={goToNextWeek}
            className="px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
          >
            Sonraki Hafta →
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          {/* Header with days */}
          <div className="grid grid-cols-8 bg-gray-50 border-b">
            <div className="p-3 font-medium text-gray-700 border-r">Saat</div>
            {weekDates.map((date, index) => (
              <div key={index} className="p-3 text-center border-r last:border-r-0">
                <div className="font-medium text-gray-700">{DAYS[index]}</div>
                <div className="text-sm text-gray-500">{formatDisplayDate(date)}</div>
              </div>
            ))}
          </div>

          {/* Time slots */}
          {HOURS.map(hour => (
            <div key={hour} className="grid grid-cols-8 border-b last:border-b-0">
              <div className="p-3 font-medium text-gray-600 border-r bg-gray-50">
                {hour}:00
              </div>
              {weekDates.map((date, dayIndex) => {
                const slotPlans = getPlansForSlot(date, hour)
                const isToday = date.toDateString() === new Date().toDateString()
                
                return (
                  <div
                    key={`${dayIndex}-${hour}`}
                    className={`
                      p-2 border-r last:border-r-0 min-h-[80px]
                      ${isToday ? 'bg-blue-50' : 'bg-white'}
                    `}
                  >
                    {slotPlans.map((plan, planIndex) => (
                      <div key={plan.id} className={`text-xs mb-2 p-2 rounded border-l-2 ${planIndex > 0 ? 'mt-1' : ''}`}
                           style={{
                             borderLeftColor: 
                               plan.type === 'MEETING' ? '#3b82f6' :
                               plan.type === 'CALL' ? '#10b981' :
                               plan.type === 'VISIT' ? '#8b5cf6' : '#f59e0b'
                           }}>
                        <div className="font-medium text-gray-800 truncate">
                          {plan.title}
                        </div>
                        <div className="text-blue-600 text-xs truncate">
                          👤 {plan.user.name}
                        </div>
                        {plan.customerName && (
                          <div className="text-gray-600 text-xs truncate">
                            🏢 {plan.customerName}
                          </div>
                        )}
                        {plan.location && (
                          <div className="text-gray-500 text-xs truncate">
                            📍 {plan.location}
                          </div>
                        )}
                        <div className="flex items-center gap-1 mt-1">
                          <span className={`
                            inline-block w-2 h-2 rounded-full
                            ${plan.type === 'MEETING' ? 'bg-blue-400' : ''}
                            ${plan.type === 'CALL' ? 'bg-green-400' : ''}
                            ${plan.type === 'VISIT' ? 'bg-purple-400' : ''}
                            ${plan.type === 'NOTE' ? 'bg-yellow-400' : ''}
                          `}></span>
                          {plan.completed && (
                            <span className="text-green-600 text-xs">✓</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )
              })}
            </div>
          ))}
        </div>
      )}

      {/* Legend */}
      <div className="mt-4 flex flex-wrap gap-4 text-sm text-gray-600">
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 bg-blue-400 rounded-full"></span>
          <span>Toplantı</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 bg-green-400 rounded-full"></span>
          <span>Arama</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 bg-purple-400 rounded-full"></span>
          <span>Ziyaret</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 bg-yellow-400 rounded-full"></span>
          <span>Not</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-green-600">✓</span>
          <span>Tamamlandı</span>
        </div>
      </div>
    </div>
  )
}
