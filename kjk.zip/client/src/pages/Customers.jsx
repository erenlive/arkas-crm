import { useQuery } from '@tanstack/react-query'
import api from '../api/client'

export default function Customers() {
  const q = useQuery({
    queryKey: ['customers'],
    queryFn: async () => (await api.get('/customers')).data
  })

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">Müşteriler</h1>
      <div className="bg-white border rounded">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <Th>Firma</Th>
                <Th>Yetkili</Th>
                <Th>Şehir</Th>
                <Th>Ortalama Ciro</Th>
              </tr>
            </thead>
            <tbody>
              {(q.data || []).map((c) => (
                <tr key={c.id} className="border-t hover:bg-gray-50">
                  <Td><a className="text-primary hover:underline" href={`/customers/${c.id}`}>{c.company}</a></Td>
                  <Td>{c.contactName || '-'}</Td>
                  <Td>{c.region?.name || '-'}</Td>
                  <Td>{c.avgRevenue != null ? new Intl.NumberFormat('tr-TR').format(c.avgRevenue) : '-'}</Td>
                </tr>
              ))}
              {q.data && q.data.length === 0 && (
                <tr><td className="p-4 text-sm text-gray-500" colSpan={4}>Kayıt yok</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

function Th({ children }) {
  return <th className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider px-4 py-2">{children}</th>
}

function Td({ children }) {
  return <td className="px-4 py-2 text-sm">{children}</td>
}
