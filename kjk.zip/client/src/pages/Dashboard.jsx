import { useQuery } from '@tanstack/react-query'
import api from '../api/client'
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts'

const COLORS = ['#3b82f6', '#f59e0b', '#ef4444', '#22c55e', '#a855f7', '#06b6d4', '#f97316', '#84cc16']

const STATUS_LABELS = {
  'TO_CALL': 'Aranacak',
  'EMAIL_SENT': 'Mail Atıldı, Takipte',
  'VISIT_WAITING': 'Ziyaret Bekliyor',
  'SAMPLE_TAKEN': 'Numune Alındı',
  'PRICE_GIVEN': 'Fiyat Verildi',
  'WON': 'Müşteri Kazanıldı',
  'PRICE_REJECTED': 'Fiyat Tutmadı',
  'PAYMENT_ISSUE': 'Ödeme Sorunlu'
}

function numberFormat(v) {
  if (v == null) return '-'
  return new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 0 }).format(v)
}

export default function Dashboard() {
  const widgets = useQuery({
    queryKey: ['widgets'],
    queryFn: async () => (await api.get('/dashboard/widgets')).data
  })

  const statusChart = useQuery({
    queryKey: ['lead-status'],
    queryFn: async () => (await api.get('/dashboard/charts/lead-status')).data
  })

  const regionChart = useQuery({
    queryKey: ['region-distribution'],
    queryFn: async () => (await api.get('/dashboard/charts/region-distribution')).data
  })

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard title="Toplam Lead" value={widgets.data?.totals?.leadCount ?? '...'} className="border-primary" />
        <StatCard title="Potansiyel Ciro" value={`₺ ${numberFormat(widgets.data?.totals?.totalAvgRevenue ?? 0)}`} className="border-success" />
        <StatCard title="Son 30 Gün Ziyaret" value={widgets.data?.totals?.visitCount ?? '...'} className="border-warning" />
        <StatCard title="Son 30 Gün Mail" value={widgets.data?.totals?.sentMailCount ?? '...'} className="border-danger" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded border p-4">
          <div className="font-medium mb-2">Lead Durum Dağılımı</div>
          <div className="h-64">
            <ResponsiveContainer>
              <PieChart>
                <Pie
                  data={(statusChart.data || []).map(item => ({
                    ...item,
                    name: STATUS_LABELS[item.status] || item.status
                  }))}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="count"
                  label={({ name, value }) => `${name}: ${value}`}
                >
                  {(statusChart.data || []).map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value, name) => [value, name]} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded border p-4">
          <div className="font-medium mb-2">Şehir Dağılımı</div>
          <div className="h-64">
            <ResponsiveContainer>
              <BarChart data={regionChart.data || []}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="region" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded border p-4 lg:col-span-2">
          <div className="font-medium mb-3">Son Ziyaretler</div>
          <SimpleList
            items={(widgets.data?.lists?.recentVisits || []).map(v => ({
              title: v.title,
              subtitle: new Date(v.date).toLocaleDateString('tr-TR'),
            }))}
          />
        </div>
        <div className="bg-white rounded border p-4">
          <div className="font-medium mb-3">Aranacak Leadler</div>
          <div className="divide-y">
            {(widgets.data?.lists?.toCallToday || []).length === 0 && (
              <div className="text-sm text-gray-500">Kayıt yok</div>
            )}
            {(widgets.data?.lists?.toCallToday || []).map((lead) => (
              <div key={lead.id} className="py-2">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-sm">{lead.company}</div>
                    <div className="text-xs text-gray-500">
                      {lead.contactName} • {lead.region?.name || '-'}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`text-xs px-2 py-1 rounded ${
                      lead.status === 'TO_CALL' 
                        ? 'bg-purple-100 text-purple-700' 
                        : 'bg-orange-100 text-orange-700'
                    }`}>
                      {lead.status === 'TO_CALL' ? 'Aranacak' : 'Gecikmiş'}
                    </div>
                    {lead.nextActionDate && (
                      <div className="text-xs text-gray-400 mt-1">
                        {new Date(lead.nextActionDate).toLocaleDateString('tr-TR')}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

function StatCard({ title, value, className }) {
  return (
    <div className={`bg-white rounded border ${className} p-4`}>
      <div className="text-sm text-gray-500">{title}</div>
      <div className="text-2xl font-semibold mt-1">{value}</div>
    </div>
  )
}

function SimpleList({ items }) {
  return (
    <div className="divide-y">
      {items.length === 0 && <div className="text-sm text-gray-500">Kayıt yok</div>}
      {items.map((it, idx) => (
        <div key={idx} className="py-2">
          <div className="font-medium">{it.title}</div>
          {it.subtitle && <div className="text-sm text-gray-500">{it.subtitle}</div>}
        </div>
      ))}
    </div>
  )
}
