import { useState, useEffect } from 'react'
import Modal from './Modal'
import api from '../api/client'
import toast from 'react-hot-toast'

export default function UserModal({ open, onClose, editingUser, onSave }) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    role: 'USER',
    position: '',
    phone: ''
  })
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (editingUser) {
      setFormData({
        name: editingUser.name || '',
        email: editingUser.email || '',
        password: '', // Don't show existing password
        role: editingUser.role || 'USER',
        position: editingUser.position || '',
        phone: editingUser.phone || ''
      })
    } else {
      setFormData({
        name: '',
        email: '',
        password: '',
        role: 'USER',
        position: '',
        phone: ''
      })
    }
  }, [editingUser, open])

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!formData.name.trim() || !formData.email.trim()) {
      toast.error('Ad ve email gerekli')
      return
    }

    if (!editingUser && !formData.password.trim()) {
      toast.error('Yeni kullanıcı için şifre gerekli')
      return
    }

    setLoading(true)
    try {
      const submitData = { ...formData }
      
      // Don't send empty password for updates
      if (editingUser && !submitData.password.trim()) {
        delete submitData.password
      }

      if (editingUser) {
        // Update existing user
        await api.put(`/users/${editingUser.id}`, submitData)
        toast.success('Kullanıcı güncellendi')
      } else {
        // Create new user
        await api.post('/users', submitData)
        toast.success('Kullanıcı oluşturuldu')
      }
      
      onSave()
    } catch (error) {
      toast.error(error.response?.data?.error || 'Bir hata oluştu')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Modal 
      open={open} 
      onClose={onClose} 
      title={editingUser ? 'Kullanıcı Düzenle' : 'Yeni Kullanıcı'}
      size="medium"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Name */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Ad Soyad *
          </label>
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Örn: Ahmet Yılmaz"
            required
          />
        </div>

        {/* Email */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Email *
          </label>
          <input
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="ornek@arkasambalaj.com"
            required
          />
        </div>

        {/* Password */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Şifre {!editingUser && '*'}
          </label>
          <input
            type="password"
            value={formData.password}
            onChange={(e) => setFormData({ ...formData, password: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder={editingUser ? "Değiştirmek için yeni şifre girin" : "Şifre"}
            required={!editingUser}
          />
          {editingUser && (
            <p className="text-xs text-gray-500 mt-1">
              Boş bırakırsanız mevcut şifre korunur
            </p>
          )}
        </div>

        {/* Position */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Görev/Pozisyon
          </label>
          <input
            type="text"
            value={formData.position}
            onChange={(e) => setFormData({ ...formData, position: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Örn: Satış Temsilcisi"
          />
        </div>

        {/* Phone */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Telefon
          </label>
          <input
            type="tel"
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Örn: +90 555 123 45 67"
          />
        </div>

        {/* Role */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Rol
          </label>
          <select
            value={formData.role}
            onChange={(e) => setFormData({ ...formData, role: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="USER">Kullanıcı</option>
            <option value="ADMIN">Admin</option>
          </select>
        </div>

        {/* Buttons */}
        <div className="flex justify-end gap-2 pt-4">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            İptal
          </button>
          <button
            type="submit"
            disabled={loading}
            className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors disabled:opacity-50"
          >
            {loading ? 'Kaydediliyor...' : (editingUser ? 'Güncelle' : 'Oluştur')}
          </button>
        </div>
      </form>
    </Modal>
  )
}
