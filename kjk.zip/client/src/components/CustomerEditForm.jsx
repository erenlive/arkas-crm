import { useState, useEffect } from 'react'
import { useQuery } from '@tanstack/react-query'
import api from '../api/client'
import toast from 'react-hot-toast'

function CustomerEditForm({ open, customer, onClose }) {
  const [formData, setFormData] = useState({
    company: '',
    contactName: '',
    phone: '',
    email: '',
    regionId: '',
    avgRevenue: '',
    competitor: '',
    paymentTerms: '',
    productsUsed: '',
    notes: ''
  })
  const [loading, setLoading] = useState(false)

  // Bölgeleri getir
  const regionsQ = useQuery({
    queryKey: ['regions'],
    queryFn: async () => (await api.get('/regions')).data
  })

  useEffect(() => {
    if (customer) {
      setFormData({
        company: customer.company || '',
        contactName: customer.contactName || '',
        phone: customer.phone || '',
        email: customer.email || '',
        regionId: customer.regionId || '',
        avgRevenue: customer.avgRevenue || '',
        competitor: customer.competitor || '',
        paymentTerms: customer.paymentTerms || '',
        productsUsed: customer.productsUsed || '',
        notes: customer.notes || ''
      })
    }
  }, [customer])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      const payload = {
        ...formData,
        avgRevenue: formData.avgRevenue ? parseFloat(formData.avgRevenue) : null
      }

      await api.put(`/customers/${customer.id}`, payload)
      toast.success('Müşteri bilgileri güncellendi')
      onClose(true)
    } catch (error) {
      console.error('Customer update error:', error)
      toast.error('Güncelleme başarısız')
    } finally {
      setLoading(false)
    }
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b">
          <h2 className="text-xl font-semibold">Müşteri Düzenle</h2>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Firma Adı *</label>
              <input
                type="text"
                value={formData.company}
                onChange={(e) => setFormData({...formData, company: e.target.value})}
                className="w-full border rounded px-3 py-2"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Yetkili Kişi</label>
              <input
                type="text"
                value={formData.contactName}
                onChange={(e) => setFormData({...formData, contactName: e.target.value})}
                className="w-full border rounded px-3 py-2"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Telefon</label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({...formData, phone: e.target.value})}
                className="w-full border rounded px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">E-posta</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                className="w-full border rounded px-3 py-2"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Şehir</label>
              <select
                value={formData.regionId}
                onChange={(e) => setFormData({...formData, regionId: e.target.value})}
                className="w-full border rounded px-3 py-2"
              >
                <option value="">Şehir seçin</option>
                {(regionsQ.data || []).map(region => (
                  <option key={region.id} value={region.id}>{region.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Ortalama Ciro (TL)</label>
              <input
                type="number"
                step="0.01"
                value={formData.avgRevenue}
                onChange={(e) => setFormData({...formData, avgRevenue: e.target.value})}
                className="w-full border rounded px-3 py-2"
                placeholder="örn: 50000"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Rakip Firma</label>
              <input
                type="text"
                value={formData.competitor}
                onChange={(e) => setFormData({...formData, competitor: e.target.value})}
                className="w-full border rounded px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Ödeme/Vade</label>
              <input
                type="text"
                value={formData.paymentTerms}
                onChange={(e) => setFormData({...formData, paymentTerms: e.target.value})}
                className="w-full border rounded px-3 py-2"
                placeholder="örn: 30 gün vade"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Kullandığı Ürünler</label>
            <input
              type="text"
              value={formData.productsUsed}
              onChange={(e) => setFormData({...formData, productsUsed: e.target.value})}
              className="w-full border rounded px-3 py-2"
              placeholder="örn: L profil, köşebent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Notlar</label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
              className="w-full border rounded px-3 py-2"
              rows={3}
              placeholder="Müşteri hakkında notlar..."
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <button
              type="button"
              onClick={() => onClose(false)}
              className="px-4 py-2 border rounded hover:bg-gray-50"
            >
              İptal
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-60"
            >
              {loading ? 'Güncelleniyor...' : 'Güncelle'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default CustomerEditForm
