import { useState, useEffect } from 'react'
import { useForm } from 'react-hook-form'
import Modal from './Modal'
import api from '../api/client'
import toast from 'react-hot-toast'

export default function LeadForm({ open, onClose, lead = null }) {
  const [regions, setRegions] = useState([])
  const [loading, setLoading] = useState(false)
  const isEdit = !!lead

  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    defaultValues: lead || {}
  })

  useEffect(() => {
    if (!open) return
    ;(async () => {
      try {
        const { data } = await api.get('/regions')
        setRegions(data)
      } catch {
        setRegions([])
      }
    })()
  }, [open])

  useEffect(() => {
    if (lead) {
      const formData = { ...lead }
      // nextActionDate'i form için date formatına çevir
      if (formData.nextActionDate) {
        formData.nextActionDate = new Date(formData.nextActionDate).toISOString().slice(0, 10)
      }
      reset(formData)
    }
  }, [lead, reset])

  const onSubmit = async (data) => {
    try {
      setLoading(true)
      
      // Sadece güncellenebilir alanları al
      const updateData = {
        company: data.company,
        contactName: data.contactName,
        phone: data.phone,
        email: data.email,
        regionId: data.regionId,
        avgRevenue: data.avgRevenue,
        competitor: data.competitor,
        paymentTerms: data.paymentTerms,
        productsUsed: data.productsUsed,
        nextActionDate: data.nextActionDate ? new Date(data.nextActionDate).toISOString() : null,
        notes: data.notes
      }
      
      if (isEdit) {
        await api.put(`/leads/${lead.id}`, updateData)
        toast.success('Lead güncellendi')
      } else {
        // Yeni lead için ownerUserId backend'de otomatik atanır
        await api.post('/leads', updateData)
        toast.success('Lead oluşturuldu')
      }
      onClose(true)
    } catch (e) {
      toast.error(e.response?.data?.error || 'İşlem başarısız')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Modal open={open} title={isEdit ? 'Lead Düzenle' : 'Yeni Lead'} onClose={() => onClose(false)}>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">Firma Adı *</label>
            <input
              {...register('company', { required: 'Firma adı zorunlu' })}
              className="w-full border rounded px-3 py-2"
              placeholder="ABC Şirketi"
            />
            {errors.company && <div className="text-red-500 text-sm">{errors.company.message}</div>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Yetkili Ad Soyad *</label>
            <input
              {...register('contactName', { required: 'Yetkili adı zorunlu' })}
              className="w-full border rounded px-3 py-2"
              placeholder="Ahmet Yılmaz"
            />
            {errors.contactName && <div className="text-red-500 text-sm">{errors.contactName.message}</div>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Telefon</label>
            <input
              {...register('phone')}
              className="w-full border rounded px-3 py-2"
              placeholder="555-123-4567"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">E-posta</label>
            <input
              type="email"
              {...register('email')}
              className="w-full border rounded px-3 py-2"
              placeholder="ahmet@abc.com"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Şehir *</label>
            <select
              {...register('regionId', { required: 'Şehir seçimi zorunlu' })}
              className="w-full border rounded px-3 py-2"
            >
              <option value="">Şehir seçin</option>
              {regions.map(r => (
                <option key={r.id} value={r.id}>{r.name}</option>
              ))}
            </select>
            {errors.regionId && <div className="text-red-500 text-sm">{errors.regionId.message}</div>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Ortalama Ciro (TL)</label>
            <input
              type="number"
              {...register('avgRevenue', { valueAsNumber: true })}
              className="w-full border rounded px-3 py-2"
              placeholder="150000"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Rakip</label>
            <input
              {...register('competitor')}
              className="w-full border rounded px-3 py-2"
              placeholder="XYZ Ambalaj"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Ödeme Şekli/Vade</label>
            <input
              {...register('paymentTerms')}
              className="w-full border rounded px-3 py-2"
              placeholder="30 gün vade"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Kullanılan Ürünler</label>
          <input
            {...register('productsUsed')}
            className="w-full border rounded px-3 py-2"
            placeholder="Köşebent, Mukavva, Streç Film"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Sonraki Aksiyon Tarihi</label>
          <input
            type="date"
            {...register('nextActionDate')}
            className="w-full border rounded px-3 py-2"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Notlar</label>
          <textarea
            {...register('notes')}
            className="w-full border rounded px-3 py-2 h-20"
            placeholder="Ek notlar..."
          />
        </div>

        <div className="flex justify-end gap-2 pt-4">
          <button
            type="button"
            onClick={() => onClose(false)}
            className="px-4 py-2 border rounded hover:bg-gray-50"
          >
            İptal
          </button>
          <button
            type="submit"
            disabled={loading}
            className="px-4 py-2 bg-primary text-white rounded hover:opacity-90 disabled:opacity-60"
          >
            {loading ? 'Kaydediliyor...' : (isEdit ? 'Güncelle' : 'Oluştur')}
          </button>
        </div>
      </form>
    </Modal>
  )
}
