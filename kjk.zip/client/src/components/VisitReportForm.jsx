import { useState, useEffect } from 'react'
import { useForm } from 'react-hook-form'
import Modal from './Modal'
import api from '../api/client'
import toast from 'react-hot-toast'

const OUTCOMES = [
  'Numune Verildi',
  'Teklif İletildi', 
  'Kazanıldı',
  'Kazanılmadı - Fiyat',
  'Kazanılmadı - İhtiyaç Yok',
  'Randevu Alındı',
  'Katalog Bırakıldı'
]

export default function VisitReportForm({ open, onClose, leadId = null, customerId = null, report = null }) {
  const [leads, setLeads] = useState([])
  const [customers, setCustomers] = useState([])
  const [loading, setLoading] = useState(false)
  const isEdit = !!report

  const { register, handleSubmit, reset, watch, formState: { errors } } = useForm({
    defaultValues: report || {
      entityType: leadId ? 'lead' : customerId ? 'customer' : 'lead',
      entityId: leadId || customerId || '',
      date: new Date().toISOString().slice(0, 10),
      title: '',
      notes: '',
      outcome: ''
    }
  })

  const entityType = watch('entityType')

  useEffect(() => {
    if (!open) return
    ;(async () => {
      try {
        const [leadsRes, customersRes] = await Promise.all([
          api.get('/leads'),
          api.get('/customers')
        ])
        setLeads(leadsRes.data)
        setCustomers(customersRes.data)
      } catch {
        setLeads([])
        setCustomers([])
      }
    })()
  }, [open])

  useEffect(() => {
    if (report) {
      const formData = { ...report }
      if (formData.date) {
        formData.date = new Date(formData.date).toISOString().slice(0, 10)
      }
      reset(formData)
    }
  }, [report, reset])

  const onSubmit = async (data) => {
    try {
      setLoading(true)
      
      // Sadece güncellenebilir alanları al
      const updateData = {
        entityType: data.entityType,
        entityId: data.entityId,
        date: data.date ? new Date(data.date).toISOString() : null,
        title: data.title,
        notes: data.notes,
        outcome: data.outcome,
        attachments: data.attachments
      }
      
      if (isEdit) {
        await api.put(`/visit-reports/${report.id}`, updateData)
        toast.success('Ziyaret raporu güncellendi')
      } else {
        await api.post('/visit-reports', updateData)
        toast.success('Ziyaret raporu kaydedildi')
      }
      onClose(true)
    } catch (e) {
      toast.error(e.response?.data?.error || 'Kayıt başarısız')
    } finally {
      setLoading(false)
    }
  }

  const entityOptions = entityType === 'lead' ? leads : customers

  return (
    <Modal open={open} title={isEdit ? "Ziyaret Raporu Düzenle" : "Yeni Ziyaret Raporu"} onClose={() => onClose(false)}>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">Tür *</label>
            <select
              {...register('entityType', { required: 'Tür seçimi zorunlu' })}
              className="w-full border rounded px-3 py-2"
              disabled={leadId || customerId}
            >
              <option value="lead">Lead</option>
              <option value="customer">Müşteri</option>
            </select>
            {errors.entityType && <div className="text-red-500 text-sm">{errors.entityType.message}</div>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">
              {entityType === 'lead' ? 'Lead' : 'Müşteri'} *
            </label>
            <select
              {...register('entityId', { required: 'Seçim zorunlu' })}
              className="w-full border rounded px-3 py-2"
              disabled={leadId || customerId}
            >
              <option value="">Seçin</option>
              {entityOptions.map(item => (
                <option key={item.id} value={item.id}>{item.company}</option>
              ))}
            </select>
            {errors.entityId && <div className="text-red-500 text-sm">{errors.entityId.message}</div>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Ziyaret Tarihi *</label>
            <input
              type="date"
              {...register('date', { required: 'Tarih zorunlu' })}
              className="w-full border rounded px-3 py-2"
            />
            {errors.date && <div className="text-red-500 text-sm">{errors.date.message}</div>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Sonuç</label>
            <select
              {...register('outcome')}
              className="w-full border rounded px-3 py-2"
            >
              <option value="">Sonuç seçin</option>
              {OUTCOMES.map(outcome => (
                <option key={outcome} value={outcome}>{outcome}</option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Başlık *</label>
          <input
            {...register('title', { required: 'Başlık zorunlu' })}
            className="w-full border rounded px-3 py-2"
            placeholder="Ziyaret başlığı"
          />
          {errors.title && <div className="text-red-500 text-sm">{errors.title.message}</div>}
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Detay Notlar</label>
          <textarea
            {...register('notes')}
            className="w-full border rounded px-3 py-2 h-24"
            placeholder="Ziyaret detayları..."
          />
        </div>

        <div className="flex justify-end gap-2 pt-4">
          <button
            type="button"
            onClick={() => onClose(false)}
            className="px-4 py-2 border rounded hover:bg-gray-50"
          >
            İptal
          </button>
          <button
            type="submit"
            disabled={loading}
            className="px-4 py-2 bg-primary text-white rounded hover:opacity-90 disabled:opacity-60"
          >
            {loading ? (isEdit ? 'Güncelleniyor...' : 'Kaydediliyor...') : (isEdit ? 'Güncelle' : 'Kaydet')}
          </button>
        </div>
      </form>
    </Modal>
  )
}
