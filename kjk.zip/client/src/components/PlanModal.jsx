import { useState, useEffect } from 'react'
import Modal from './Modal'
import api from '../api/client'
import toast from 'react-hot-toast'

const PLAN_TYPES = [
  { value: 'MEETING', label: 'Toplantı', color: 'bg-blue-400' },
  { value: 'CALL', label: 'Arama', color: 'bg-green-400' },
  { value: 'VISIT', label: 'Ziyaret', color: 'bg-purple-400' },
  { value: 'NOTE', label: 'Not', color: 'bg-yellow-400' }
]

export default function PlanModal({ open, onClose, selectedSlot, editingPlan, onSave, onDelete }) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    type: 'MEETING',
    customerName: '',
    location: '',
    completed: false
  })
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (editingPlan) {
      setFormData({
        title: editingPlan.title || '',
        description: editingPlan.description || '',
        type: editingPlan.type || 'MEETING',
        customerName: editingPlan.customerName || '',
        location: editingPlan.location || '',
        completed: editingPlan.completed || false
      })
    } else {
      setFormData({
        title: '',
        description: '',
        type: 'MEETING',
        customerName: '',
        location: '',
        completed: false
      })
    }
  }, [editingPlan, open])

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!formData.title.trim()) {
      toast.error('Plan başlığı gerekli')
      return
    }

    setLoading(true)
    try {
      if (editingPlan) {
        // Update existing plan
        await api.put(`/daily-plans/${editingPlan.id}`, formData)
        toast.success('Plan güncellendi')
      } else {
        // Create new plan
        const planData = {
          ...formData,
          date: selectedSlot.date.toISOString().split('T')[0],
          hour: selectedSlot.hour
        }
        await api.post('/daily-plans', planData)
        toast.success('Plan oluşturuldu')
      }
      onSave()
    } catch (error) {
      toast.error(error.response?.data?.error || 'Bir hata oluştu')
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async () => {
    if (!editingPlan) return
    
    if (!confirm('Bu planı silmek istediğinizden emin misiniz?')) return

    setLoading(true)
    try {
      await api.delete(`/daily-plans/${editingPlan.id}`)
      toast.success('Plan silindi')
      onDelete()
    } catch (error) {
      toast.error(error.response?.data?.error || 'Silme işlemi başarısız')
    } finally {
      setLoading(false)
    }
  }

  const formatDate = (date) => {
    return date?.toLocaleDateString('tr-TR', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    })
  }

  const formatHour = (hour) => {
    return `${hour}:00 - ${hour + 1}:00`
  }

  return (
    <Modal 
      open={open} 
      onClose={onClose} 
      title={editingPlan ? 'Planı Düzenle' : 'Yeni Plan Oluştur'}
      size="medium"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Date and Time Info */}
        <div className="bg-gray-50 p-3 rounded-lg">
          <div className="text-sm text-gray-600">
            {selectedSlot && (
              <>
                <div className="font-medium">{formatDate(selectedSlot.date)}</div>
                <div>{formatHour(selectedSlot.hour)}</div>
              </>
            )}
            {editingPlan && (
              <>
                <div className="font-medium">{formatDate(new Date(editingPlan.date))}</div>
                <div>{formatHour(editingPlan.hour)}</div>
              </>
            )}
          </div>
        </div>

        {/* Plan Type */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Plan Türü
          </label>
          <div className="grid grid-cols-2 gap-2">
            {PLAN_TYPES.map(type => (
              <button
                key={type.value}
                type="button"
                onClick={() => setFormData({ ...formData, type: type.value })}
                className={`
                  p-3 rounded-lg border-2 transition-all flex items-center gap-2
                  ${formData.type === type.value 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-gray-200 hover:border-gray-300'
                  }
                `}
              >
                <span className={`w-3 h-3 rounded-full ${type.color}`}></span>
                <span className="text-sm font-medium">{type.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Title */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Plan Başlığı *
          </label>
          <input
            type="text"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Örn: ABC Şirketi ile toplantı"
            required
          />
        </div>

        {/* Customer Name */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Müşteri Adı
          </label>
          <input
            type="text"
            value={formData.customerName}
            onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Müşteri veya şirket adı"
          />
        </div>

        {/* Location */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Lokasyon
          </label>
          <input
            type="text"
            value={formData.location}
            onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Adres veya toplantı yeri"
          />
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Açıklama
          </label>
          <textarea
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Plan detayları ve notlar..."
          />
        </div>

        {/* Completed checkbox (only for editing) */}
        {editingPlan && (
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="completed"
              checked={formData.completed}
              onChange={(e) => setFormData({ ...formData, completed: e.target.checked })}
              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
            />
            <label htmlFor="completed" className="text-sm font-medium text-gray-700">
              Tamamlandı olarak işaretle
            </label>
          </div>
        )}

        {/* Buttons */}
        <div className="flex justify-between pt-4">
          <div>
            {editingPlan && (
              <button
                type="button"
                onClick={handleDelete}
                disabled={loading}
                className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors disabled:opacity-50"
              >
                Sil
              </button>
            )}
          </div>
          
          <div className="flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              İptal
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors disabled:opacity-50"
            >
              {loading ? 'Kaydediliyor...' : (editingPlan ? 'Güncelle' : 'Oluştur')}
            </button>
          </div>
        </div>
      </form>
    </Modal>
  )
}
