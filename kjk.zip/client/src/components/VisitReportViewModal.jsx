import Modal from './Modal'

export default function VisitReportViewModal({ open, onClose, report }) {
  if (!report) return null

  return (
    <Modal open={open} title="Ziyaret Raporu Detayı" onClose={onClose}>
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">Firma</label>
            <div className="text-sm font-medium">{report.company || '-'}</div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">Tür</label>
            <span className={`text-xs px-2 py-1 rounded ${report.entityType === 'lead' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'}`}>
              {report.entityType === 'lead' ? 'Lead' : 'Müşteri'}
            </span>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">Ziyaret Tarihi</label>
            <div className="text-sm">{new Date(report.date).toLocaleDateString('tr-TR')}</div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">Kullanıcı</label>
            <div className="text-sm">{report.user?.name || '-'}</div>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-600 mb-1">Başlık</label>
          <div className="text-sm font-medium">{report.title}</div>
        </div>

        {report.outcome && (
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">Sonuç</label>
            <div className="text-sm">{report.outcome}</div>
          </div>
        )}

        {report.notes && (
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">Detay Notlar</label>
            <div className="text-sm bg-gray-50 p-3 rounded border whitespace-pre-wrap">{report.notes}</div>
          </div>
        )}

        <div className="flex justify-end pt-4">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-500 text-white rounded hover:opacity-90"
          >
            Kapat
          </button>
        </div>
      </div>
    </Modal>
  )
}
