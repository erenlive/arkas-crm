import { useEffect, useMemo, useState } from 'react'
import ReactQuill from 'react-quill'
import 'react-quill/dist/quill.snow.css'
import Modal from './Modal'
import api from '../api/client'
import toast from 'react-hot-toast'

export default function MailModal({ open, onClose, lead }) {
  const [templates, setTemplates] = useState([])
  const [selectedTemplate, setSelectedTemplate] = useState('')
  const [to, setTo] = useState(lead?.email || '')
  const [subject, setSubject] = useState('')
  const [html, setHtml] = useState('')

  // Default imza HTML'i
  const getDefaultSignature = () => {
    const user = JSON.parse(localStorage.getItem('user') || 'null')
    const senderName = user?.name || 'Zeynep Başaran'
    const senderEmail = user?.email || 'zeynep@arkasambalaj.com'
    
    return `<br><br><p>Saygılarımla,</p><br>
<table style="width: 590px; border-collapse: collapse;">
<tbody>
<tr>
<td style="padding: 10px; border: 1px solid #ebebeb;">
<img src="http://arkasambalaj.com/images/arkas_logo.png" width="215" height="60" style="float: right;" />
<table style="border-collapse: collapse;">
<tbody>
<tr><td><strong style="color: #2c363a; font-size: 18px;">${senderName}</strong></td></tr>
<tr><td style="color: #2c363a;">SATIŞ YÖNETİCİSİ/ SALES EXECUTIVE</td></tr>
<tr><td><strong style="color: #2c363a;">Arkas Ambalaj San. ve Tic. Ltd. Şti.</strong></td></tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td style="padding: 10px; border: 1px solid #ebebeb;">
<table style="width: 100%; border-collapse: collapse;">
<tbody>
<tr>
<td style="width: 15%; color: #666;"><strong>Phone</strong></td>
<td style="width: 35%; color: #666;">: +90 262 255 56 54</td>
<td style="width: 50%; color: #666;"><strong>Gebze Fabrika:</strong> Tavşanlı, 4506 Sk No:17 41400 Gebze/Kocaeli</td>
</tr>
<tr>
<td style="color: #666;"><strong>Fax</strong></td>
<td style="color: #666;">: +90 262 255 56 54</td>
<td rowspan="2" style="color: #666;"><strong>Bursa Fabrika:</strong> Nilüferköy, Nilüfer Cd. No:143/3, 16265 Osmangazi/Bursa</td>
</tr>
<tr>
<td style="color: #666;"><strong>Mobile</strong></td>
<td style="color: #666;">: +90 506 346 45 56</td>
</tr>
<tr>
<td style="color: #666;"><strong>E-Mail</strong></td>
<td style="color: #666;">: <a href="mailto:${senderEmail}" style="color: #666;">${senderEmail}</a></td>
<td></td>
</tr>
<tr>
<td style="color: #666;"><strong>Web</strong></td>
<td style="color: #666;">: <a href="http://arkasambalaj.com" style="color: #666;">http://arkasambalaj.com</a></td>
<td></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>`
  }
  const [file, setFile] = useState(null)
  const [loading, setLoading] = useState(false)

  // Quill editör konfigürasyonu
  const quillModules = {
    toolbar: [
      [{ 'header': [1, 2, 3, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      [{ 'color': [] }, { 'background': [] }],
      [{ 'list': 'ordered'}, { 'list': 'bullet' }],
      [{ 'align': [] }],
      ['link'],
      ['clean']
    ],
  }

  const quillFormats = [
    'header', 'bold', 'italic', 'underline', 'strike',
    'color', 'background', 'list', 'bullet', 'align', 'link'
  ]

  useEffect(() => {
    if (!open) return
    ;(async () => {
      try {
        const { data } = await api.get('/emails/templates')
        setTemplates(data)
      } catch {
        setTemplates([])
      }
    })()
    
    // Modal açıldığında default imzayı ekle
    if (html === '') {
      setHtml(getDefaultSignature())
    }
  }, [open])

  useEffect(() => {
    if (lead?.email) setTo(lead.email)
  }, [lead])

  function applyTemplate(id) {
    const tpl = templates.find(t => t.id === id)
    setSelectedTemplate(id)
    if (!tpl) return
    const vars = buildVars(lead)
    setSubject(replaceVars(tpl.subjectTemplate, vars))
    const templateContent = replaceVars(tpl.bodyTemplate, vars)
    // Template içeriği + imza
    setHtml(templateContent + getDefaultSignature())
  }

  async function send() {
    if (!to || !subject || !html) {
      toast.error('Alıcı, konu ve içerik zorunlu')
      return
    }
    try {
      setLoading(true)
      const fd = new FormData()
      fd.append('leadId', lead.id)
      fd.append('to', to)
      fd.append('subject', subject)
      fd.append('html', html)
      if (file) fd.append('attachment', file)
      const { data } = await api.post('/emails/send', fd, { headers: { 'Content-Type': 'multipart/form-data' } })
      toast.success('Mail gönderildi')
      handleClose(true)
    } catch (e) {
      toast.error(e.response?.data?.error || 'Gönderim hatası')
    } finally {
      setLoading(false)
    }
  }

  const handleClose = (success) => {
    if (!success) {
      // Modal kapatıldığında içeriği temizle
      setHtml('')
      setSubject('')
      setSelectedTemplate('')
      setFile(null)
    }
    onClose(success)
  }

  return (
    <Modal open={open} title="Mail Gönder" onClose={() => handleClose(false)} size="large">
      <div className="space-y-3">
        <div>
          <label className="block text-sm text-gray-600 mb-1">Şablon</label>
          <select className="border rounded w-full px-3 py-2" value={selectedTemplate} onChange={(e) => applyTemplate(e.target.value)}>
            <option value="">Şablon seçin</option>
            {templates.map(t => (
              <option key={t.id} value={t.id}>{t.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm text-gray-600 mb-1">Alıcılar (virgülle ayırın)</label>
          <input className="border rounded w-full px-3 py-2" value={to} onChange={(e) => setTo(e.target.value)} placeholder="ornek@firma.com, baska@firma.com" />
        </div>
        <div>
          <label className="block text-sm text-gray-600 mb-1">Konu</label>
          <input className="border rounded w-full px-3 py-2" value={subject} onChange={(e) => setSubject(e.target.value)} />
        </div>
        <div>
          <label className="block text-sm text-gray-600 mb-1">İçerik</label>
          <div className="border rounded">
            <ReactQuill
              theme="snow"
              value={html}
              onChange={setHtml}
              modules={quillModules}
              formats={quillFormats}
              style={{ height: '200px', marginBottom: '42px' }}
              placeholder="Mail içeriğinizi buraya yazın..."
            />
          </div>
        </div>
        <div>
          <label className="block text-sm text-gray-600 mb-1">Ek (tek dosya)</label>
          <input type="file" onChange={(e) => setFile(e.target.files?.[0] || null)} />
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <button className="px-4 py-2 rounded border" onClick={() => handleClose(false)}>İptal</button>
          <button disabled={true} className="px-4 py-2 rounded bg-gray-400 text-white opacity-60 cursor-not-allowed" title="Mail gönderme şu anda devre dışı">Gönder (Devre Dışı)</button>
        </div>
      </div>
    </Modal>
  )
}

function buildVars(lead) {
  const user = JSON.parse(localStorage.getItem('user') || 'null')
  const tarih = new Date()
  const tarihOn = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000)
  const tarihOnerileri = `${tarih.toLocaleDateString('tr-TR')} / ${tarihOn.toLocaleDateString('tr-TR')}`
  return {
    firma: lead?.company || '',
    yetkili: lead?.contactName || '',
    gonderen_ad: user?.name || '',
    tarih_önerileri: tarihOnerileri,
    tarih_onerileri: tarihOnerileri,
  }
}

function replaceVars(text, vars) {
  let out = text || ''
  for (const [k, v] of Object.entries(vars)) {
    const re = new RegExp(`{{\\s*${k}\\s*}}`, 'gi')
    out = out.replace(re, v)
  }
  return out
}
