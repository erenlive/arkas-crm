import { useState, useEffect } from 'react'
import { useQuery } from '@tanstack/react-query'
import api from '../api/client'
import toast from 'react-hot-toast'

function QuoteForm({ open = true, customerId, leadId, onClose, isModal = true }) {
  const [formData, setFormData] = useState({
    paymentTerms: 'Sipariş Öncesi Peşin',
    paymentMethod: 'Hesaba havale',
    shippingIncluded: true,
    validUntil: '',
    notes: ''
  })
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(false)

  // Müşteri köşebent detaylarını getir
  const cornerDetailsQ = useQuery({
    queryKey: ['corner-details', customerId],
    queryFn: async () => (await api.get(`/customers/${customerId}/corner-details`)).data,
    enabled: !!customerId && open
  })

  // Lead köşebent detaylarını getir
  const leadCornerDetailsQ = useQuery({
    queryKey: ['lead-corner-details', leadId],
    queryFn: async () => (await api.get(`/leads/${leadId}/corner-details`)).data,
    enabled: !!leadId && open
  })

  useEffect(() => {
    const cornerData = cornerDetailsQ.data || leadCornerDetailsQ.data
    
    if (cornerData) {
      // Mevcut köşebent detaylarını form itemları olarak ayarla
      const formItems = cornerData.map(detail => ({
        id: detail.id,
        kanat1Mm: detail.kanat1Mm,
        kanat2Mm: detail.kanat2Mm,
        etKalinligiMm: detail.etKalinligiMm,
        boyMm: detail.boyMm,
        cornerType: detail.baskiliMi ? 'Baskılı' : detail.centikliMi ? 'Çentikli' : detail.kilitliMi ? 'Kilitli' : 'Standart',
        hasPrint: detail.baskiliMi,
        quantity: detail.adet,
        unitPrice: detail.hedefFiyatTl || 0,
        selected: true
      }))
      setItems(formItems)
    }

    // Varsayılan geçerlilik tarihi (7 gün sonra)
    const validDate = new Date()
    validDate.setDate(validDate.getDate() + 7)
    setFormData(prev => ({
      ...prev,
      validUntil: validDate.toISOString().split('T')[0]
    }))
  }, [cornerDetailsQ.data, leadCornerDetailsQ.data])

  const handleItemChange = (index, field, value) => {
    const newItems = [...items]
    newItems[index] = { ...newItems[index], [field]: value }
    setItems(newItems)
  }

  const toggleItemSelection = (index) => {
    const newItems = [...items]
    newItems[index].selected = !newItems[index].selected
    setItems(newItems)
  }

  const addNewItem = () => {
    setItems([...items, {
      kanat1Mm: '',
      kanat2Mm: '',
      etKalinligiMm: '',
      boyMm: '',
      cornerType: 'Standart',
      hasPrint: false,
      quantity: '',
      unitPrice: '',
      selected: true
    }])
  }

  const removeItem = (index) => {
    setItems(items.filter((_, i) => i !== index))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      const selectedItems = items.filter(item => item.selected)
      if (selectedItems.length === 0) {
        toast.error('En az bir ürün seçmelisiniz')
        return
      }

      const payload = {
        customerId: customerId || null,
        leadId: leadId || null,
        ...formData,
        items: selectedItems.map(item => ({
          kanat1Mm: parseFloat(item.kanat1Mm),
          kanat2Mm: parseFloat(item.kanat2Mm),
          etKalinligiMm: parseFloat(item.etKalinligiMm),
          boyMm: parseFloat(item.boyMm),
          cornerType: item.cornerType,
          hasPrint: item.hasPrint,
          quantity: parseInt(item.quantity),
          unitPrice: parseFloat(item.unitPrice)
        }))
      }

      const response = await api.post('/quotes', payload)
      toast.success('Teklif oluşturuldu')
      onClose(true, response.data)
    } catch (error) {
      console.error('Quote creation error:', error)
      toast.error('Teklif oluşturulamadı')
    } finally {
      setLoading(false)
    }
  }

  if (!open) return null

  const containerClass = isModal 
    ? "fixed inset-0 bg-gradient-to-br from-black/60 to-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4"
    : "w-full"
    
  const formClass = isModal
    ? "bg-white rounded-2xl shadow-2xl w-full max-w-6xl max-h-[90vh] overflow-y-auto border border-gray-200/50"
    : "bg-white rounded-2xl shadow-lg w-full border border-gray-200/50"

  return (
    <div className={containerClass}>
      <div className={formClass}>
        <div className="p-6 border-b border-gray-100 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-t-2xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
              <span className="text-white text-lg">📄</span>
            </div>
            <h2 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              Fiyat Teklifi Oluştur
            </h2>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-8">
          {/* Teklif Bilgileri */}
          <div className="bg-gradient-to-r from-gray-50 to-blue-50/30 rounded-xl p-6 border border-gray-100">
            <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
              <span className="w-6 h-6 bg-blue-500 rounded-lg flex items-center justify-center text-white text-sm">⚙️</span>
              Teklif Ayarları
            </h3>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Ödeme Vadesi</label>
                <select
                  value={formData.paymentTerms}
                  onChange={(e) => setFormData({...formData, paymentTerms: e.target.value})}
                  className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200 bg-white shadow-sm"
                  required
                >
                <option value="Sipariş Öncesi Peşin">Sipariş Öncesi Peşin</option>
                <option value="15 gün">15 gün</option>
                <option value="30 gün">30 gün</option>
                <option value="45 gün">45 gün</option>
                <option value="60 gün">60 gün</option>
                <option value="90 gün">90 gün</option>
                <option value="120 gün">120 gün</option>
                <option value="150 gün">150 gün</option>
              </select>
            </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Ödeme Şekli</label>
                <select
                  value={formData.paymentMethod}
                  onChange={(e) => setFormData({...formData, paymentMethod: e.target.value})}
                  className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200 bg-white shadow-sm"
                  required
                >
                  <option value="Hesaba havale">Hesaba havale</option>
                  <option value="Müşteri Çeki">Müşteri Çeki</option>
                  <option value="Kredi Kartı">Kredi Kartı</option>
                  <option value="Nakit">Nakit</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Geçerlilik Tarihi</label>
                <input
                  type="date"
                  value={formData.validUntil}
                  onChange={(e) => setFormData({...formData, validUntil: e.target.value})}
                  className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200 bg-white shadow-sm"
                  required
                />
              </div>

              <div className="flex items-center">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.shippingIncluded}
                    onChange={(e) => setFormData({...formData, shippingIncluded: e.target.checked})}
                    className="w-5 h-5 text-blue-600 border-2 border-gray-300 rounded focus:ring-blue-500 focus:ring-2"
                  />
                  <span className="text-sm font-medium text-gray-700">Nakliye Dahil</span>
                </label>
              </div>
            </div>

            <div className="col-span-2">
              <label className="block text-sm font-semibold text-gray-700 mb-2">Notlar</label>
              <textarea
                value={formData.notes}
                onChange={(e) => setFormData({...formData, notes: e.target.value})}
                className="w-full border-2 border-gray-200 rounded-xl px-4 py-3 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all duration-200 bg-white shadow-sm resize-none"
                rows={3}
                placeholder="Ek notlar ve özel koşullar..."
              />
            </div>
          </div>

          {/* Ürün Listesi */}
          <div className="bg-gradient-to-r from-green-50 to-emerald-50/30 rounded-xl p-6 border border-gray-100">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
                <span className="w-6 h-6 bg-green-500 rounded-lg flex items-center justify-center text-white text-sm">📦</span>
                Ürün Listesi
              </h3>
              <button
                type="button"
                onClick={addNewItem}
                className="bg-gradient-to-r from-green-500 to-emerald-600 text-white px-4 py-2 rounded-xl text-sm font-medium hover:from-green-600 hover:to-emerald-700 transition-all duration-200 shadow-md hover:shadow-lg flex items-center gap-2"
              >
                <span className="text-lg">+</span>
                Yeni Ürün
              </button>
            </div>

            <div className="overflow-x-auto border-2 border-gray-200 rounded-xl shadow-sm">
              <table className="w-full">
                <thead className="bg-gradient-to-r from-gray-50 to-blue-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Seç</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Kanat 1</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Kanat 2</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Et Kalınlığı</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Boy</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Tip</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Baskı</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Adet</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Birim Fiyat</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">İşlem</th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((item, index) => (
                    <tr key={index} className={`border-t ${!item.selected ? 'opacity-50' : ''}`}>
                      <td className="px-3 py-2">
                        <input
                          type="checkbox"
                          checked={item.selected}
                          onChange={() => toggleItemSelection(index)}
                        />
                      </td>
                      <td className="px-3 py-2">
                        <input
                          type="number"
                          step="0.1"
                          value={item.kanat1Mm}
                          onChange={(e) => handleItemChange(index, 'kanat1Mm', e.target.value)}
                          className="w-20 border rounded px-2 py-1 text-sm"
                          placeholder="40"
                        />
                      </td>
                      <td className="px-3 py-2">
                        <input
                          type="number"
                          step="0.1"
                          value={item.kanat2Mm}
                          onChange={(e) => handleItemChange(index, 'kanat2Mm', e.target.value)}
                          className="w-20 border rounded px-2 py-1 text-sm"
                          placeholder="40"
                        />
                      </td>
                      <td className="px-3 py-2">
                        <input
                          type="number"
                          step="0.1"
                          value={item.etKalinligiMm}
                          onChange={(e) => handleItemChange(index, 'etKalinligiMm', e.target.value)}
                          className="w-20 border rounded px-2 py-1 text-sm"
                          placeholder="2.5"
                        />
                      </td>
                      <td className="px-3 py-2">
                        <input
                          type="number"
                          step="0.1"
                          value={item.boyMm}
                          onChange={(e) => handleItemChange(index, 'boyMm', e.target.value)}
                          className="w-24 border rounded px-2 py-1 text-sm"
                          placeholder="6000"
                        />
                      </td>
                      <td className="px-3 py-2">
                        <select
                          value={item.cornerType}
                          onChange={(e) => handleItemChange(index, 'cornerType', e.target.value)}
                          className="border rounded px-2 py-1 text-sm"
                        >
                          <option value="Standart">Standart</option>
                          <option value="Çentikli">Çentikli</option>
                          <option value="Kilitli">Kilitli</option>
                        </select>
                      </td>
                      <td className="px-3 py-2">
                        <input
                          type="checkbox"
                          checked={item.hasPrint}
                          onChange={(e) => handleItemChange(index, 'hasPrint', e.target.checked)}
                        />
                      </td>
                      <td className="px-3 py-2">
                        <input
                          type="number"
                          value={item.quantity}
                          onChange={(e) => handleItemChange(index, 'quantity', e.target.value)}
                          className="w-20 border rounded px-2 py-1 text-sm"
                          placeholder="100"
                        />
                      </td>
                      <td className="px-3 py-2">
                        <input
                          type="number"
                          step="0.01"
                          value={item.unitPrice}
                          onChange={(e) => handleItemChange(index, 'unitPrice', e.target.value)}
                          className="w-24 border rounded px-2 py-1 text-sm"
                          placeholder="15.50"
                        />
                      </td>
                      <td className="px-3 py-2">
                        <button
                          type="button"
                          onClick={() => removeItem(index)}
                          className="text-red-600 hover:text-red-800 text-sm"
                        >
                          Sil
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Butonlar */}
          <div className="flex justify-end gap-4 pt-6 border-t-2 border-gray-100">
            <button
              type="button"
              onClick={() => onClose(false)}
              className="px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-xl font-medium hover:bg-gray-50 hover:border-gray-400 transition-all duration-200"
            >
              İptal
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-8 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-xl font-medium hover:from-green-600 hover:to-emerald-700 disabled:opacity-60 disabled:cursor-not-allowed transition-all duration-200 shadow-lg hover:shadow-xl flex items-center gap-2"
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Oluşturuluyor...
                </>
              ) : (
                <>
                  <span className="text-lg">📄</span>
                  Teklif Oluştur
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default QuoteForm
