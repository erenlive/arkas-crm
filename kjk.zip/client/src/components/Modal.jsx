export default function Modal({ open, title, children, onClose, size = "default" }) {
  if (!open) return null
  
  const sizeClasses = {
    default: "max-w-2xl",
    large: "max-w-4xl",
    small: "max-w-md"
  }
  
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className={`relative bg-white rounded shadow-lg w-full ${sizeClasses[size]} mx-4`}>
        <div className="border-b px-4 py-3 flex items-center justify-between">
          <div className="font-semibold">{title}</div>
          <button className="text-gray-500 hover:text-black" onClick={onClose}>✕</button>
        </div>
        <div className="p-4">
          {children}
        </div>
      </div>
    </div>
  )
}
