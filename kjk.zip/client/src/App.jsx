import { Routes, Route, Navigate, Link, NavLink, Outlet } from 'react-router-dom'
import Login from './pages/Login.jsx'
import Dashboard from './pages/Dashboard.jsx'
import Leads from './pages/Leads.jsx'
import LeadDetail from './pages/LeadDetail.jsx'
import Customers from './pages/Customers'
import CustomerDetail from './pages/CustomerDetail.jsx'
import QuotePDF from './pages/QuotePDF.jsx'
import Quotes from './pages/Quotes.jsx'
import VisitReports from './pages/VisitReports'
import Stats from './pages/Stats'
import DailyPlans from './pages/DailyPlans.jsx'
import AdminPlans from './pages/AdminPlans.jsx'
import UserManagement from './pages/UserManagement.jsx'
import NewQuote from './pages/NewQuote.jsx'
import ProtectedRoute from './components/ProtectedRoute.jsx'

function App() {
  return (
    <div className="min-h-screen">
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route
          path="/"
          element={
            <ProtectedRoute>
              <MainLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<Dashboard />} />
          <Route path="leads" element={<Leads />} />
          <Route path="leads/:id" element={<LeadDetail />} />
          <Route path="customers" element={<Customers />} />
          <Route path="customers/:id" element={<CustomerDetail />} />
          <Route path="quotes" element={<Quotes />} />
          <Route path="quotes/new" element={<NewQuote />} />
          <Route path="quote-pdf/:id" element={<QuotePDF />} />
          <Route path="visit-reports" element={<VisitReports />} />
          <Route path="stats" element={<Stats />} />
          <Route path="daily-plans" element={<DailyPlans />} />
          <Route path="admin-plans" element={<AdminPlans />} />
          <Route path="user-management" element={<UserManagement />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </div>
  )
}

function MainLayout() {
  const user = JSON.parse(localStorage.getItem('user') || 'null')
  return (
    <div className="flex min-h-screen">
      <aside className="w-60 bg-white border-r">
        <div className="p-4 relative">
          <img 
            src="http://arkasambalaj.com/images/arkas_logo.png" 
            alt="Arkas Ambalaj Logo"
            className="w-50 h-auto"
            onError={(e) => {e.target.style.display = 'none'}}
          />
          <div className="text-xs text-gray-500 mt-2 text-right">CRM Sistemi</div>
        </div>
        <nav className="px-2 space-y-1">
          <Link className="block px-3 py-2 rounded hover:bg-gray-100" to="/">🏠 Dashboard</Link>
          <Link className="block px-3 py-2 rounded hover:bg-gray-100" to="/leads">🎯 Leads</Link>
          <Link className="block px-3 py-2 rounded hover:bg-gray-100" to="/customers">👥 Müşteriler</Link>
          <Link className="block px-3 py-2 rounded hover:bg-gray-100" to="/quotes">📄 Teklifler</Link>
          <Link className="block px-3 py-2 rounded hover:bg-gray-100" to="/daily-plans">📅 Günlük Planlama</Link>
          {user?.role === 'ADMIN' && (
            <Link className="block px-3 py-2 rounded hover:bg-gray-100" to="/admin-plans">👨‍💼 Admin Planları</Link>
          )}
          {user?.role === 'ADMIN' && (
            <Link className="block px-3 py-2 rounded hover:bg-gray-100" to="/user-management">👥 Kullanıcı Yönetimi</Link>
          )}
          <Link className="block px-3 py-2 rounded hover:bg-gray-100" to="/visit-reports">📋 Ziyaret Raporları</Link>
          <Link className="block px-3 py-2 rounded hover:bg-gray-100" to="/stats">📊 İstatistikler</Link>
        </nav>
      </aside>
      <main className="flex-1">
        <header className="bg-white border-b p-4 flex items-center justify-between">
          <div className="font-semibold">Hoş geldiniz{user ? `, ${user.name}` : ''}</div>
          <button
            className="text-sm text-danger"
            onClick={() => {
              localStorage.removeItem('token')
              localStorage.removeItem('user')
              window.location.href = '/login'
            }}
          >
            Çıkış
          </button>
        </header>
        <div className="p-6">
          <Outlet />
        </div>
      </main>
    </div>
  )
}

export default App
