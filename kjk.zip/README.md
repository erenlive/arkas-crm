# Arkas Ambalaj CRM Sistemi

Modern, tam özellikli CRM sistemi - Lead yönetiminden müşteri kazanımına kadar.

## 🚀 Özellikler

- **Lead Yönetimi** - Potansiyel müşteri takibi
- **Müşteri Yönetimi** - Mevcut müşteri portföyü
- **Teklif Sistemi** - PDF teklif oluşturma ve takip
- **Günlük Planlama** - Takvim ve otomatik mail bildirimleri
- **Kullanıcı Yönetimi** - Admin paneli ve rol yönetimi
- **İstatistikler** - Satış performans raporları

## 🛠️ Teknolojiler

### Frontend
- React 18
- Vite
- Tailwind CSS
- React Router
- React Query

### Backend
- Node.js
- Express.js
- Prisma ORM
- PostgreSQL
- JWT Authentication
- Nodemailer

## 📦 Kurulum

### Geliştirme Ortamı

1. **Repository'yi klonlayın:**
```bash
git clone https://github.com/yourusername/arkas-crm.git
cd arkas-crm
```

2. **Backend kurulumu:**
```bash
cd server
npm install
cp .env.example .env
# .env dosyasını düzenleyin
npx prisma migrate dev
npm run prisma:seed
npm run dev
```

3. **Frontend kurulumu:**
```bash
cd ../client
npm install
npm run dev
```

## 🌐 Production Deployment

Bu proje Render.com üzerinde deploy edilmek üzere yapılandırılmıştır.

### Render.com Deployment

1. GitHub'a push edin
2. Render.com'da hesap oluşturun
3. "New Web Service" ile repository'yi bağlayın
4. Environment variables'ları ayarlayın
5. Deploy edin

### Environment Variables

```env
DATABASE_URL=postgresql://username:password@host:port/database
JWT_SECRET=your-super-secret-jwt-key-here
SMTP_HOST=your-smtp-host
SMTP_PORT=587
SMTP_USER=your-email@domain.com
SMTP_PASS=your-email-password
SMTP_FROM="Your Company <your-email@domain.com>"
```

## 👥 Varsayılan Kullanıcılar

- **Admin:** admin@arkas.com / 123456
- **Satış:** satis1@arkas.com / 123456

## 📄 Lisans

Bu proje Arkas Ambalaj için özel olarak geliştirilmiştir.
