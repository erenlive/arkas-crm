import dotenv from 'dotenv';
dotenv.config();

import http from 'http';
import app from './app.js';
import { startScheduler, stopScheduler } from './services/scheduler.js';

const PORT = process.env.PORT || 3001;

const server = http.createServer(app);
server.listen(PORT, () => {
  console.log(`CRM server listening on http://localhost:${PORT}`);
  
  // Start scheduler
  startScheduler();
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully...');
  stopScheduler();
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully...');
  stopScheduler();
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});
