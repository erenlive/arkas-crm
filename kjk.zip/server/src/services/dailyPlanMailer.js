import nodemailer from 'nodemailer'
import { prisma } from '../utils/prisma.js'

// Daily plan mailer service
// Bu dosya günlük planları mail olarak gönderecek

// Create transporter
const createTransporter = () => {
  return nodemailer.createTransporter({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT),
    secure: process.env.SMTP_SECURE === 'true',
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  })
}

export const sendDailyPlanEmails = async () => {
  try {
    console.log('Starting daily plan email sending...')
    
    // Get all users
    const users = await prisma.user.findMany({
      select: {
        id: true,
        name: true,
        email: true,
        role: true
      }
    })

    const today = new Date()
    today.setHours(0, 0, 0, 0)
    
    const tomorrow = new Date(today)
    tomorrow.setDate(today.getDate() + 1)

    const transporter = createTransporter()
    let emailsSent = 0
    let emailsFailed = 0

    for (const user of users) {
      try {
        // Get user's plans for today
        const plans = await prisma.dailyPlan.findMany({
          where: {
            userId: user.id,
            date: {
              gte: today,
              lt: tomorrow
            }
          },
          orderBy: { hour: 'asc' }
        })

        // Generate email content
        const htmlContent = generateDailyPlanEmail(user, plans)
        
        // Send email
        await transporter.sendMail({
          from: process.env.SMTP_FROM,
          to: user.email,
          subject: `Günlük Plan Özeti - ${today.toLocaleDateString('tr-TR')}`,
          html: htmlContent
        })

        console.log(`✅ Email sent to ${user.name} (${user.email}) - ${plans.length} plans`)
        emailsSent++
        
      } catch (error) {
        console.error(`❌ Failed to send email to ${user.name} (${user.email}):`, error.message)
        emailsFailed++
      }
    }

    console.log(`📧 Daily plan emails completed: ${emailsSent} sent, ${emailsFailed} failed`)
    return { sent: emailsSent, failed: emailsFailed }
    
  } catch (error) {
    console.error('❌ Error in sendDailyPlanEmails:', error)
    throw error
  }
}

export const generateDailyPlanEmail = (user, plans) => {
  const today = new Date().toLocaleDateString('tr-TR', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  })

  let plansList = ''
  
  if (plans.length === 0) {
    plansList = '<p style="color: #666; font-style: italic;">Bugün için planlanmış bir aktivite bulunmuyor.</p>'
  } else {
    plansList = plans.map(plan => {
      const typeIcon = {
        'MEETING': '🤝',
        'CALL': '📞',
        'VISIT': '🚗',
        'NOTE': '📝'
      }[plan.type] || '📋'

      const typeText = {
        'MEETING': 'Toplantı',
        'CALL': 'Arama',
        'VISIT': 'Ziyaret',
        'NOTE': 'Not'
      }[plan.type] || 'Plan'

      return `
        <div style="border-left: 3px solid #3b82f6; padding: 12px; margin: 8px 0; background: #f8fafc;">
          <div style="font-weight: bold; color: #1f2937; margin-bottom: 4px;">
            ${typeIcon} ${plan.hour}:00 - ${typeText}
          </div>
          <div style="font-size: 16px; color: #374151; margin-bottom: 4px;">
            ${plan.title}
          </div>
          ${plan.customerName ? `<div style="color: #6b7280; font-size: 14px;">👤 Müşteri: ${plan.customerName}</div>` : ''}
          ${plan.location ? `<div style="color: #6b7280; font-size: 14px;">📍 Lokasyon: ${plan.location}</div>` : ''}
          ${plan.description ? `<div style="color: #6b7280; font-size: 14px; margin-top: 4px;">${plan.description}</div>` : ''}
        </div>
      `
    }).join('')
  }

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Günlük Plan Özeti</title>
    </head>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
      <div style="text-align: center; margin-bottom: 30px;">
        <img src="http://arkasambalaj.com/images/arkas_logo.png" alt="Arkas Ambalaj" style="max-width: 200px; height: auto;">
        <h1 style="color: #2c363a; margin: 20px 0;">Günlük Plan Özeti</h1>
      </div>
      
      <div style="background: #e3f2fd; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
        <h2 style="margin: 0; color: #1565c0;">Merhaba ${user.name}!</h2>
        <p style="margin: 8px 0 0 0; color: #1976d2;">${today} tarihli günlük planlarınız aşağıda yer almaktadır.</p>
      </div>
      
      <div style="margin: 20px 0;">
        ${plansList}
      </div>
      
      <div style="margin-top: 30px; padding: 15px; background: #f5f5f5; border-radius: 8px; text-align: center;">
        <p style="margin: 0; color: #666; font-size: 14px;">
          Bu mail otomatik olarak gönderilmiştir. Planlarınızı güncellemek için CRM sistemine giriş yapabilirsiniz.
        </p>
      </div>
      
      <div style="margin-top: 20px; text-align: center; color: #999; font-size: 12px;">
        <p>Arkas Ambalaj San. ve Tic. Ltd. Şti.</p>
        <p>📧 zeynep@arkasambalaj.com | 📞 +90 262 255 56 54</p>
      </div>
    </body>
    </html>
  `
}
