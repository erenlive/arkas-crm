import cron from 'node-cron'
import { sendDailyPlanEmails } from './dailyPlanMailer.js'

// Scheduler service for automated tasks
// Bu dosya zamanlanmış görevleri yönetecek

let scheduledTasks = []

export const startScheduler = () => {
  console.log('🕐 Starting scheduler...')
  
  // Daily plan emails - Her gün sabah 8:30'da çalışır
  const dailyPlanTask = cron.schedule('30 8 * * *', async () => {
    console.log('🕐 Running daily plan email task at', new Date().toLocaleString('tr-TR'))
    try {
      const result = await sendDailyPlanEmails()
      console.log(`📧 Daily plan emails sent: ${result.sent} successful, ${result.failed} failed`)
    } catch (error) {
      console.error('❌ Error in daily plan email task:', error)
    }
  }, {
    scheduled: false,
    timezone: "Europe/Istanbul"
  })

  // Test task - Her dakika çalışır (sadece development için)
  const testTask = cron.schedule('* * * * *', () => {
    if (process.env.NODE_ENV === 'development') {
      console.log('🔄 Test scheduler running at', new Date().toLocaleString('tr-TR'))
    }
  }, {
    scheduled: false,
    timezone: "Europe/Istanbul"
  })

  // Start tasks
  dailyPlanTask.start()
  
  if (process.env.NODE_ENV === 'development') {
    // testTask.start() // Test için açabilirsiniz
  }

  // Store tasks for cleanup
  scheduledTasks.push(dailyPlanTask, testTask)
  
  console.log('✅ Scheduler started successfully')
  console.log('📧 Daily plan emails scheduled for 08:30 every day')
}

export const stopScheduler = () => {
  console.log('🛑 Stopping scheduler...')
  
  // Stop all scheduled tasks
  scheduledTasks.forEach(task => {
    if (task) {
      task.stop()
      task.destroy()
    }
  })
  
  // Clear tasks array
  scheduledTasks = []
  
  console.log('✅ Scheduler stopped successfully')
}

// Manual trigger function for testing
export const triggerDailyPlanEmails = async () => {
  console.log('🔧 Manually triggering daily plan emails...')
  try {
    const result = await sendDailyPlanEmails()
    console.log(`📧 Manual daily plan emails sent: ${result.sent} successful, ${result.failed} failed`)
    return result
  } catch (error) {
    console.error('❌ Error in manual daily plan email trigger:', error)
    throw error
  }
}
