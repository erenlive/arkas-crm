import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import path from 'path';
import { fileURLToPath } from 'url';
import { authRouter } from './routes/auth.js';
import leadsRouter from './routes/leads.js';
import customersRouter from './routes/customers.js';
import { visitReportsRouter } from './routes/visitReports.js';
import { emailsRouter } from './routes/emails.js';
import { dashboardRouter } from './routes/dashboard.js';
import { statsRouter } from './routes/stats.js';
import { csvRouter } from './routes/csv.js';
import { regionsRouter } from './routes/regions.js';
import { usersRouter } from './routes/users.js';
import quotesRouter from './routes/quotes.js';
import dailyPlansRouter from './routes/dailyPlans.js';
import schedulerRouter from './routes/scheduler.js';
import { errorHandler } from './middleware/errorHandler.js';

const app = express();

app.use(cors());
app.use(helmet());
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev'));

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

app.get('/api/health', (req, res) => {
  res.json({ ok: true, env: process.env.NODE_ENV || 'development' });
});

app.use('/api/auth', authRouter);
app.use('/api/leads', leadsRouter);
app.use('/api/customers', customersRouter);
app.use('/api/visit-reports', visitReportsRouter);
app.use('/api/emails', emailsRouter);
app.use('/api/dashboard', dashboardRouter);
app.use('/api/stats', statsRouter);
app.use('/api/csv', csvRouter);
app.use('/api/regions', regionsRouter);
app.use('/api/users', usersRouter);
app.use('/api/quotes', quotesRouter);
app.use('/api/daily-plans', dailyPlansRouter);
app.use('/api/scheduler', schedulerRouter);

app.use(errorHandler);

export default app;
