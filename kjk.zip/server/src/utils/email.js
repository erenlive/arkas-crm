import nodemailer from 'nodemailer';

let transporter = null;

export function getTransporter() {
  if (transporter) return transporter;
  const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_SECURE } = process.env;
  if (!SMTP_HOST || !SMTP_PORT || !SMTP_USER || !SMTP_PASS) {
    console.warn('SMTP not fully configured. Emails will be simulated in dev.');
    return null;
  }
  const port = Number(SMTP_PORT);
  const secure = SMTP_SECURE === 'true' || port === 465; // implicit TLS
  transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port,
    secure,
    auth: { user: SMTP_USER, pass: SMTP_PASS }
  });
  return transporter;
}

export async function sendEmail({ to, subject, html, attachments = [] }) {
  const from = process.env.SMTP_FROM || process.env.SMTP_USER;
  const tx = getTransporter();
  if (!tx) {
    console.log('[DEV EMAIL SIMULATED]', { to, subject });
    return { messageId: `sim-${Date.now()}`, response: 'Simulated in dev' };
  }
  return tx.sendMail({ from, to, subject, html, attachments });
}
