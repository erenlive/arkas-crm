import { Router } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import csv from 'csv-parser';
import { createObjectCsvWriter } from 'csv-writer';
import { prisma } from '../utils/prisma.js';
import { requireAuth } from '../middleware/auth.js';

const uploadDir = process.env.UPLOAD_DIR || path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const upload = multer({ dest: uploadDir, limits: { fileSize: Number(process.env.MAX_FILE_SIZE || 10 * 1024 * 1024) } });

export const csvRouter = Router();

// CSV template for leads
csvRouter.get('/template/leads', requireAuth, async (req, res) => {
  const headers = [
    'Firma Adı','Yetkili Ad Soyad','Telefon','E-posta','Bölge','Ortalama Ciro','Rakip','Ödeme Şekli/Vade','Kullanılan Ürünler','Durum','Sonraki Aksiyon Tarihi','Notlar'
  ];
  const filename = path.join(uploadDir, `lead_template_${Date.now()}.csv`);
  const csvWriter = createObjectCsvWriter({ path: filename, header: headers.map(h => ({ id: h, title: h })) });
  await csvWriter.writeRecords([]);
  res.download(filename, 'lead_template.csv', (err) => {
    try { fs.unlinkSync(filename); } catch {}
  });
});

// Import leads from CSV
csvRouter.post('/import/leads', requireAuth, upload.single('file'), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'CSV file required' });

    const regions = await prisma.region.findMany();
    const regionMap = new Map(regions.map(r => [r.name.toLowerCase(), r.id]));

    const results = [];
    const errors = [];

    await new Promise((resolve, reject) => {
      fs.createReadStream(req.file.path)
        .pipe(csv())
        .on('data', (row) => results.push(row))
        .on('end', resolve)
        .on('error', reject);
    });

    let success = 0;
    for (let i = 0; i < results.length; i++) {
      const r = results[i];
      try {
        const company = r['Firma Adı']?.trim();
        const contactName = r['Yetkili Ad Soyad']?.trim();
        const regionName = r['Bölge']?.trim();
        if (!company || !contactName || !regionName) throw new Error('Zorunlu alan eksik (Firma, Yetkili, Bölge)');
        let regionId = regionMap.get(regionName.toLowerCase());
        if (!regionId) {
          const region = await prisma.region.upsert({ where: { name: regionName }, update: {}, create: { name: regionName } });
          regionId = region.id;
          regionMap.set(regionName.toLowerCase(), regionId);
        }
        const payload = {
          company,
          contactName,
          phone: r['Telefon'] || null,
          email: r['E-posta'] || null,
          regionId,
          avgRevenue: r['Ortalama Ciro'] ? Number(r['Ortalama Ciro']) : null,
          competitor: r['Rakip'] || null,
          paymentTerms: r['Ödeme Şekli/Vade'] || null,
          productsUsed: r['Kullanılan Ürünler'] || null,
          status: r['Durum'] || 'TARGET',
          ownerUserId: req.user.id,
          nextActionDate: r['Sonraki Aksiyon Tarihi'] ? new Date(r['Sonraki Aksiyon Tarihi']) : null,
          notes: r['Notlar'] || null
        };
        await prisma.lead.create({ data: payload });
        success++;
      } catch (e) {
        errors.push({ row: i + 1, error: e.message });
      }
    }

    try { fs.unlinkSync(req.file.path); } catch {}
    res.json({ imported: success, failed: errors.length, errors });
  } catch (err) { next(err); }
});

// Export leads
csvRouter.get('/export/leads', requireAuth, async (req, res, next) => {
  try {
    const leads = await prisma.lead.findMany({ include: { region: true, owner: true }, orderBy: { createdAt: 'desc' } });
    const filename = path.join(uploadDir, `leads_${Date.now()}.csv`);
    const header = [
      { id: 'company', title: 'Firma Adı' },
      { id: 'contactName', title: 'Yetkili Ad Soyad' },
      { id: 'phone', title: 'Telefon' },
      { id: 'email', title: 'E-posta' },
      { id: 'region', title: 'Bölge' },
      { id: 'avgRevenue', title: 'Ortalama Ciro' },
      { id: 'competitor', title: 'Rakip' },
      { id: 'paymentTerms', title: 'Ödeme Şekli/Vade' },
      { id: 'productsUsed', title: 'Kullanılan Ürünler' },
      { id: 'status', title: 'Durum' },
      { id: 'nextActionDate', title: 'Sonraki Aksiyon Tarihi' },
      { id: 'notes', title: 'Notlar' }
    ];
    const csvWriter = createObjectCsvWriter({ path: filename, header });
    await csvWriter.writeRecords(leads.map(l => ({
      company: l.company,
      contactName: l.contactName,
      phone: l.phone || '',
      email: l.email || '',
      region: l.region?.name || '',
      avgRevenue: l.avgRevenue ?? '',
      competitor: l.competitor || '',
      paymentTerms: l.paymentTerms || '',
      productsUsed: l.productsUsed || '',
      status: l.status,
      nextActionDate: l.nextActionDate ? new Date(l.nextActionDate).toISOString().slice(0,10) : '',
      notes: l.notes || ''
    })));
    res.download(filename, 'leads_export.csv', (err) => {
      try { fs.unlinkSync(filename); } catch {}
    });
  } catch (err) { next(err); }
});

// Export customers
csvRouter.get('/export/customers', requireAuth, async (req, res, next) => {
  try {
    const customers = await prisma.customer.findMany({ include: { region: true, owner: true }, orderBy: { createdAt: 'desc' } });
    const filename = path.join(uploadDir, `customers_${Date.now()}.csv`);
    const header = [
      { id: 'company', title: 'Firma Adı' },
      { id: 'contactName', title: 'Yetkili Ad Soyad' },
      { id: 'phone', title: 'Telefon' },
      { id: 'email', title: 'E-posta' },
      { id: 'region', title: 'Bölge' },
      { id: 'avgRevenue', title: 'Ortalama Ciro' },
      { id: 'competitor', title: 'Rakip' },
      { id: 'paymentTerms', title: 'Ödeme Şekli/Vade' },
      { id: 'productsUsed', title: 'Kullanılan Ürünler' },
      { id: 'notes', title: 'Notlar' }
    ];
    const csvWriter = createObjectCsvWriter({ path: filename, header });
    await csvWriter.writeRecords(customers.map(c => ({
      company: c.company,
      contactName: c.contactName || '',
      phone: c.phone || '',
      email: c.email || '',
      region: c.region?.name || '',
      avgRevenue: c.avgRevenue ?? '',
      competitor: c.competitor || '',
      paymentTerms: c.paymentTerms || '',
      productsUsed: c.productsUsed || '',
      notes: c.notes || ''
    })));
    res.download(filename, 'customers_export.csv', (err) => {
      try { fs.unlinkSync(filename); } catch {}
    });
  } catch (err) { next(err); }
});
