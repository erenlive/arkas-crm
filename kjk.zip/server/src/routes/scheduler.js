import express from 'express'
import { requireAuth, requireRole } from '../middleware/auth.js'
import { triggerDailyPlanEmails } from '../services/scheduler.js'

const schedulerRouter = express.Router()

// Manual trigger for daily plan emails (Admin only)
schedulerRouter.post('/trigger-daily-emails', requireAuth, requireRole('ADMIN'), async (req, res, next) => {
  try {
    console.log(`Admin ${req.user.name} manually triggered daily plan emails`)
    const result = await triggerDailyPlanEmails()
    res.json({
      success: true,
      message: 'Daily plan emails triggered successfully',
      result
    })
  } catch (error) {
    next(error)
  }
})

export default schedulerRouter
