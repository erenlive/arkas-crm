import express from 'express'
import { prisma } from '../utils/prisma.js'
import { requireAuth } from '../middleware/auth.js'
const dailyPlansRouter = express.Router()

// Get daily plans for a specific week
dailyPlansRouter.get('/week/:date', requireAuth, async (req, res, next) => {
  try {
    const { date } = req.params
    const startDate = new Date(date)
    const endDate = new Date(startDate)
    endDate.setDate(startDate.getDate() + 6) // 7 gün

    const plans = await prisma.dailyPlan.findMany({
      where: {
        userId: req.user.id,
        date: {
          gte: startDate,
          lte: endDate
        }
      },
      orderBy: [
        { date: 'asc' },
        { hour: 'asc' }
      ]
    })

    res.json(plans)
  } catch (error) {
    next(error)
  }
})

// Get all users' plans for admin (specific week)
dailyPlansRouter.get('/admin/week/:date', requireAuth, async (req, res, next) => {
  try {
    // Check if user is admin
    if (req.user.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Admin yetkisi gerekli' })
    }

    const { date } = req.params
    const startDate = new Date(date)
    const endDate = new Date(startDate)
    endDate.setDate(startDate.getDate() + 6)

    const plans = await prisma.dailyPlan.findMany({
      where: {
        date: {
          gte: startDate,
          lte: endDate
        }
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true
          }
        }
      },
      orderBy: [
        { date: 'asc' },
        { hour: 'asc' }
      ]
    })

    res.json(plans)
  } catch (error) {
    next(error)
  }
})

// Create new daily plan
dailyPlansRouter.post('/', requireAuth, async (req, res, next) => {
  try {
    const { date, hour, title, description, type, customerName, location } = req.body

    // Debug logs
    console.log('Creating plan for user:', req.user.id)
    console.log('Request body:', req.body)

    // Validate hour (9-17)
    if (hour < 9 || hour > 17) {
      return res.status(400).json({ error: 'Saat 9-17 arasında olmalıdır' })
    }

    // Check if user exists
    const user = await prisma.user.findUnique({
      where: { id: req.user.id }
    })
    
    if (!user) {
      console.log('User not found:', req.user.id)
      return res.status(404).json({ error: 'Kullanıcı bulunamadı' })
    }

    console.log('User found:', user.name)

    const plan = await prisma.dailyPlan.create({
      data: {
        userId: req.user.id,
        date: new Date(date),
        hour,
        title,
        description,
        type: type || 'MEETING',
        customerName,
        location
      }
    })

    res.status(201).json(plan)
  } catch (error) {
    if (error.code === 'P2002') {
      return res.status(400).json({ error: 'Bu saat için zaten bir plan var' })
    }
    next(error)
  }
})

// Update daily plan
dailyPlansRouter.put('/:id', requireAuth, async (req, res, next) => {
  try {
    const { id } = req.params
    const { title, description, type, customerName, location, completed } = req.body

    // Check if plan belongs to user
    const existingPlan = await prisma.dailyPlan.findUnique({
      where: { id }
    })

    if (!existingPlan) {
      return res.status(404).json({ error: 'Plan bulunamadı' })
    }

    if (existingPlan.userId !== req.user.id && req.user.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Bu planı düzenleme yetkiniz yok' })
    }

    const plan = await prisma.dailyPlan.update({
      where: { id },
      data: {
        title,
        description,
        type,
        customerName,
        location,
        completed
      }
    })

    res.json(plan)
  } catch (error) {
    next(error)
  }
})

// Delete daily plan
dailyPlansRouter.delete('/:id', requireAuth, async (req, res, next) => {
  try {
    const { id } = req.params

    // Check if plan belongs to user
    const existingPlan = await prisma.dailyPlan.findUnique({
      where: { id }
    })

    if (!existingPlan) {
      return res.status(404).json({ error: 'Plan bulunamadı' })
    }

    if (existingPlan.userId !== req.user.id && req.user.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Bu planı silme yetkiniz yok' })
    }

    await prisma.dailyPlan.delete({
      where: { id }
    })

    res.json({ message: 'Plan silindi' })
  } catch (error) {
    next(error)
  }
})

// Get daily summary for email (today's plans)
dailyPlansRouter.get('/today/:userId?', requireAuth, async (req, res, next) => {
  try {
    const userId = req.params.userId || req.user.id
    
    // Only admin can get other users' plans
    if (userId !== req.user.id && req.user.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Bu kullanıcının planlarını görme yetkiniz yok' })
    }

    const today = new Date()
    today.setHours(0, 0, 0, 0)
    
    const tomorrow = new Date(today)
    tomorrow.setDate(today.getDate() + 1)

    const plans = await prisma.dailyPlan.findMany({
      where: {
        userId,
        date: {
          gte: today,
          lt: tomorrow
        }
      },
      orderBy: { hour: 'asc' }
    })

    res.json(plans)
  } catch (error) {
    next(error)
  }
})

export default dailyPlansRouter
