import { Router } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { prisma } from '../utils/prisma.js';
import { requireAuth } from '../middleware/auth.js';
import { sendEmail } from '../utils/email.js';

const uploadDir = process.env.UPLOAD_DIR || path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const upload = multer({ dest: uploadDir, limits: { fileSize: Number(process.env.MAX_FILE_SIZE || 10 * 1024 * 1024) } });

export const emailsRouter = Router();

// Send email
emailsRouter.post('/send', requireAuth, upload.single('attachment'), async (req, res, next) => {
  try {
    const { leadId, customerId, to, subject, html } = req.body;
    if (!to || !subject || !html) return res.status(400).json({ error: 'to, subject, html required' });

    let attachments = [];
    let attachmentsMeta = null;
    if (req.file) {
      attachments = [{ filename: req.file.originalname, path: req.file.path }];
      attachmentsMeta = JSON.stringify({ originalname: req.file.originalname, path: req.file.path, mimetype: req.file.mimetype, size: req.file.size });
    }

    const toList = Array.isArray(to) ? to : String(to).split(',').map((s) => s.trim()).filter(Boolean);

    const result = await sendEmail({ to: toList, subject, html, attachments });

    const record = await prisma.sentEmail.create({
      data: {
        leadId: leadId || null,
        customerId: customerId || null,
        toEmails: JSON.stringify(toList),
        subject,
        body: html,
        attachmentsMeta,
        status: 'sent',
        smtpResponse: result?.response || null,
        sentBy: req.user.id
      }
    });

    await prisma.activity.create({
      data: {
        entityType: leadId ? 'lead' : 'customer',
        entityId: leadId || customerId,
        activityType: 'MAIL',
        userId: req.user.id,
        note: subject
      }
    });

    // Optional: update lead status to EMAIL_SENT
    if (leadId) {
      await prisma.lead.update({ where: { id: leadId }, data: { status: 'EMAIL_SENT' } });
    }

    res.json({ ok: true, sentEmail: record });
  } catch (err) { next(err); }
});

// List sent emails (recent)
emailsRouter.get('/sent', requireAuth, async (req, res, next) => {
  try {
    const emails = await prisma.sentEmail.findMany({ orderBy: { sentAt: 'desc' }, take: 100 });
    res.json(emails);
  } catch (err) { next(err); }
});

// Templates
emailsRouter.get('/templates', requireAuth, async (req, res, next) => {
  try {
    const templates = await prisma.emailTemplate.findMany({ orderBy: { createdAt: 'desc' } });
    res.json(templates);
  } catch (err) { next(err); }
});

emailsRouter.post('/templates', requireAuth, async (req, res, next) => {
  try {
    const { name, subjectTemplate, bodyTemplate } = req.body;
    if (!name || !subjectTemplate || !bodyTemplate) return res.status(400).json({ error: 'Missing fields' });
    const tpl = await prisma.emailTemplate.create({ data: { name, subjectTemplate, bodyTemplate, createdBy: req.user.id } });
    res.status(201).json(tpl);
  } catch (err) { next(err); }
});
