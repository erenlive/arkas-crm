import { Router } from 'express';
import { prisma } from '../utils/prisma.js';
import { requireAuth } from '../middleware/auth.js';

export const statsRouter = Router();

// GET /api/stats - high-level aggregates
statsRouter.get('/', requireAuth, async (req, res, next) => {
  try {
    const leadCount = await prisma.lead.count();
    const sum = await prisma.lead.aggregate({ _sum: { avgRevenue: true } });
    const customerCount = await prisma.customer.count();

    res.json({
      leadCount,
      customerCount,
      totalAvgRevenue: sum._sum.avgRevenue || 0
    });
  } catch (err) { next(err); }
});

// GET /api/stats/performance - user performance summary
statsRouter.get('/performance', requireAuth, async (req, res, next) => {
  try {
    const users = await prisma.user.findMany({ select: { id: true, name: true } });

    const result = await Promise.all(users.map(async (u) => {
      const leadCount = await prisma.lead.count({ where: { ownerUserId: u.id } });
      const visitCount = await prisma.visitReport.count({ where: { userId: u.id } });
      const mailCount = await prisma.sentEmail.count({ where: { sentBy: u.id } });
      const vPerLead = leadCount ? visitCount / leadCount : 0;
      const mPerLead = leadCount ? mailCount / leadCount : 0;
      const score = (vPerLead * 0.6 + mPerLead * 0.4) * 100;
      return { userId: u.id, userName: u.name, leadCount, visitCount, mailCount, visitPerLead: vPerLead, mailPerLead: mPerLead, performanceScore: Math.round(score) };
    }));

    res.json(result);
  } catch (err) { next(err); }
});

// GET /api/stats/funnel - conversion funnel
statsRouter.get('/funnel', requireAuth, async (req, res, next) => {
  try {
    const target = await prisma.lead.count({ where: { status: 'TARGET' } });
    const emailSent = await prisma.lead.count({ where: { status: 'EMAIL_SENT' } });
    const contactedUnwon = await prisma.lead.count({ where: { status: 'CONTACTED_UNWON' } });
    const won = await prisma.lead.count({ where: { status: 'WON' } });

    res.json([
      { stage: 'TARGET', count: target },
      { stage: 'EMAIL_SENT', count: emailSent },
      { stage: 'CONTACTED_UNWON', count: contactedUnwon },
      { stage: 'WON', count: won }
    ]);
  } catch (err) { next(err); }
});
