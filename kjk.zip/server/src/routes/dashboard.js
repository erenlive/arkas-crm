import { Router } from 'express';
import { prisma } from '../utils/prisma.js';
import { requireAuth } from '../middleware/auth.js';

export const dashboardRouter = Router();

// Widgets: totals and quick stats
// GET /api/dashboard/widgets

dashboardRouter.get('/widgets', requireAuth, async (req, res, next) => {
  try {
    const [leadCount, totalAvgRevenue, visitCount, sentMailCount] = await Promise.all([
      prisma.lead.count(),
      prisma.lead.aggregate({ _sum: { avgRevenue: true } }),
      prisma.visitReport.count({
        where: {
          date: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) }
        }
      }),
      prisma.sentEmail.count({
        where: {
          sentAt: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) }
        }
      })
    ]);

    const toCallToday = await prisma.lead.findMany({
      where: { 
        OR: [
          { nextActionDate: { lte: new Date() } },
          { status: 'TO_CALL' }
        ]
      },
      orderBy: { nextActionDate: 'asc' },
      take: 20,
      include: { region: true, owner: true }
    });

    const recentVisits = await prisma.visitReport.findMany({ orderBy: { date: 'desc' }, take: 10 });
    const recentEmails = await prisma.sentEmail.findMany({ orderBy: { sentAt: 'desc' }, take: 10 });

    res.json({
      totals: {
        leadCount,
        totalAvgRevenue: totalAvgRevenue._sum.avgRevenue || 0,
        visitCount,
        sentMailCount
      },
      lists: {
        recentVisits,
        recentEmails,
        toCallToday
      }
    });
  } catch (err) { next(err); }
});

// Charts: lead status distribution
// GET /api/dashboard/charts/lead-status

dashboardRouter.get('/charts/lead-status', requireAuth, async (req, res, next) => {
  try {
    const statuses = ['TO_CALL','EMAIL_SENT','VISIT_WAITING','SAMPLE_TAKEN','PRICE_GIVEN','WON','PRICE_REJECTED','PAYMENT_ISSUE'];
    const data = await Promise.all(statuses.map(async (s) => ({
      status: s,
      count: await prisma.lead.count({ where: { status: s } })
    })));
    res.json(data);
  } catch (err) { next(err); }
});

// Charts: region distribution
// GET /api/dashboard/charts/region-distribution

dashboardRouter.get('/charts/region-distribution', requireAuth, async (req, res, next) => {
  try {
    const regions = await prisma.region.findMany({ 
      orderBy: { name: 'asc' },
      include: {
        _count: {
          select: { leads: true }
        }
      }
    });
    
    // Sadece lead'i olan şehirleri filtrele
    const data = regions
      .filter(r => r._count.leads > 0)
      .map(r => ({
        region: r.name,
        count: r._count.leads
      }));
    
    res.json(data);
  } catch (err) { next(err); }
});
