import { Router } from 'express';
import { prisma } from '../utils/prisma.js';
import { requireAuth } from '../middleware/auth.js';

export const regionsRouter = Router();

regionsRouter.get('/', requireAuth, async (req, res, next) => {
  try {
    const regions = await prisma.region.findMany({ orderBy: { name: 'asc' } });
    res.json(regions);
  } catch (err) { next(err); }
});
