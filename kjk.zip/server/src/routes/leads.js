import { Router } from 'express';
import { prisma } from '../utils/prisma.js';
import { requireAuth } from '../middleware/auth.js';

export const leadsRouter = Router();

leadsRouter.get('/', requireAuth, async (req, res, next) => {
  try {
    const { q, status, regionId, ownerUserId } = req.query;
    const where = {};
    if (q) {
      where.OR = [
        { company: { contains: q, mode: 'insensitive' } },
        { contactName: { contains: q, mode: 'insensitive' } },
        { email: { contains: q, mode: 'insensitive' } },
      ];
    }
    if (status) where.status = status;
    if (regionId) where.regionId = regionId;
    if (ownerUserId) where.ownerUserId = ownerUserId;

    const leads = await prisma.lead.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      include: { region: true, owner: true }
    });
    res.json(leads);
  } catch (err) { next(err); }
});

leadsRouter.post('/', requireAuth, async (req, res, next) => {
  try {
    const data = req.body;
    if (!data.company || !data.contactName || !data.regionId) {
      return res.status(400).json({ error: 'company, contactName, regionId are required' });
    }
    data.ownerUserId = req.user.id;
    data.status = data.status || 'TARGET';
    const lead = await prisma.lead.create({ data });
    res.status(201).json(lead);
  } catch (err) { next(err); }
});

leadsRouter.get('/:id', requireAuth, async (req, res, next) => {
  try {
    const id = req.params.id;
    const lead = await prisma.lead.findUnique({
      where: { id },
      include: {
        region: true,
        owner: true,
        cornerSpecs: true,
        sentEmails: true,
      }
    });
    if (!lead) return res.status(404).json({ error: 'Lead not found' });

    const [visitReports, activities] = await Promise.all([
      prisma.visitReport.findMany({ where: { entityType: 'lead', entityId: id }, orderBy: { date: 'desc' } }),
      prisma.activity.findMany({ where: { entityType: 'lead', entityId: id }, orderBy: { createdAt: 'desc' } }),
    ]);

    res.json({ ...lead, visitReports, activities });
  } catch (err) { next(err); }
});

leadsRouter.put('/:id', requireAuth, async (req, res, next) => {
  try {
    const updated = await prisma.lead.update({ where: { id: req.params.id }, data: req.body });
    res.json(updated);
  } catch (err) { next(err); }
});

leadsRouter.delete('/:id', requireAuth, async (req, res, next) => {
  try {
    // Sadece admin silebilir
    if (req.user.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Sadece admin lead silebilir' });
    }
    
    await prisma.lead.delete({ where: { id: req.params.id } });
    
    // Log kaydı
    await prisma.log.create({
      data: {
        userId: req.user.id,
        action: 'LEAD_DELETED',
        meta: JSON.stringify({ leadId: req.params.id })
      }
    });
    
    res.json({ ok: true });
  } catch (err) { next(err); }
});

leadsRouter.patch('/:id/status', requireAuth, async (req, res, next) => {
  try {
    const { status } = req.body;
    const updated = await prisma.lead.update({ where: { id: req.params.id }, data: { status } });
    
    // İlk mevcut user'ı kullan
    const user = await prisma.user.findFirst();
    if (user) {
      await prisma.activity.create({
        data: {
          entityType: 'lead',
          entityId: req.params.id,
          activityType: 'STATUS_CHANGE',
          userId: user.id,
          note: `Status changed to ${status}`
        }
      });
    }

    // Eğer durum "WON" (Kazanıldı) ise otomatik olarak müşteri oluştur
    if (status === 'WON') {
      const existingCustomer = await prisma.customer.findFirst({
        where: { createdFromLeadId: req.params.id }
      });

      if (!existingCustomer) {
        console.log('Creating customer from won lead:', req.params.id);
        const customer = await prisma.customer.create({
          data: {
            company: updated.company,
            contactName: updated.contactName,
            phone: updated.phone,
            email: updated.email,
            regionId: updated.regionId,
            avgRevenue: updated.avgRevenue,
            competitor: updated.competitor,
            paymentTerms: updated.paymentTerms,
            productsUsed: updated.productsUsed,
            ownerUserId: updated.ownerUserId,
            notes: updated.notes,
            createdFromLeadId: updated.id
          }
        });
        console.log('Customer created successfully:', customer.id);

        // Lead'deki köşebent detaylarını müşteriye kopyala
        const leadCornerDetails = await prisma.cornerDetail.findMany({
          where: { leadId: req.params.id }
        });

        if (leadCornerDetails.length > 0) {
          console.log(`Copying ${leadCornerDetails.length} corner details to customer`);
          for (const detail of leadCornerDetails) {
            await prisma.cornerDetail.create({
              data: {
                customerId: customer.id,
                kanat1Mm: detail.kanat1Mm,
                kanat2Mm: detail.kanat2Mm,
                etKalinligiMm: detail.etKalinligiMm,
                boyMm: detail.boyMm,
                adet: detail.adet,
                hedefFiyatTl: detail.hedefFiyatTl,
                baskiliMi: detail.baskiliMi,
                centikliMi: detail.centikliMi,
                kilitliMi: detail.kilitliMi,
                gramaji: detail.gramaji,
                createdBy: detail.createdBy
              }
            });
          }
          console.log('Corner details copied successfully');
        }
      }
    }

    res.json(updated);
  } catch (err) { next(err); }
});

// Update next action date
leadsRouter.patch('/:id/next-action', requireAuth, async (req, res, next) => {
  try {
    const { nextActionDate } = req.body;
    const updated = await prisma.lead.update({ where: { id: req.params.id }, data: { nextActionDate: nextActionDate ? new Date(nextActionDate) : null } });
    // İlk mevcut user'ı kullan
    const user = await prisma.user.findFirst();
    if (user) {
      await prisma.activity.create({
        data: {
          entityType: 'lead',
          entityId: req.params.id,
          activityType: 'NEXT_ACTION_UPDATE',
          userId: user.id,
          note: `Next action date updated`
        }
      });
    }
    res.json(updated);
  } catch (err) { next(err); }
});

// Create an activity on lead (NOTE/CALL/etc)
leadsRouter.post('/:id/activities', requireAuth, async (req, res, next) => {
  try {
    const { activityType = 'NOTE', note } = req.body;
    // İlk mevcut user'ı kullan
    const user = await prisma.user.findFirst();
    if (!user) {
      return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
    }
    
    const act = await prisma.activity.create({
      data: {
        entityType: 'lead',
        entityId: req.params.id,
        activityType,
        userId: user.id,
        note: note || null
      }
    });
    res.status(201).json(act);
  } catch (err) { next(err); }
});

// Convert lead to customer
leadsRouter.post('/:id/convert-to-customer', requireAuth, async (req, res, next) => {
  try {
    const lead = await prisma.lead.findUnique({ where: { id: req.params.id } });
    if (!lead) return res.status(404).json({ error: 'Lead not found' });

    const customer = await prisma.customer.create({
      data: {
        company: lead.company,
        contactName: lead.contactName,
        phone: lead.phone,
        email: lead.email,
        regionId: lead.regionId,
        avgRevenue: lead.avgRevenue,
        competitor: lead.competitor,
        paymentTerms: lead.paymentTerms,
        productsUsed: lead.productsUsed,
        ownerUserId: lead.ownerUserId,
        notes: lead.notes,
        createdFromLeadId: lead.id
      }
    });

    res.json(customer);
  } catch (err) { next(err); }
});

// Lead Köşebent Detayları
leadsRouter.get('/:id/corner-details', requireAuth, async (req, res, next) => {
  try {
    const details = await prisma.cornerDetail.findMany({
      where: { leadId: req.params.id },
      orderBy: { createdAt: 'desc' }
    });
    res.json(details);
  } catch (err) { next(err); }
});

leadsRouter.post('/:id/corner-details', requireAuth, async (req, res, next) => {
  try {
    console.log('Adding corner detail for lead ID:', req.params.id);
    console.log('User ID:', req.user.id);
    
    // Lead'in var olup olmadığını kontrol et
    const lead = await prisma.lead.findUnique({ where: { id: req.params.id } });
    if (!lead) {
      return res.status(404).json({ error: 'Lead bulunamadı' });
    }
    
    // User'ın var olup olmadığını kontrol et
    const user = await prisma.user.findFirst();
    if (!user) {
      return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
    }
    console.log('Using user:', user.id, user.email);
    
    const { kanat1Mm, kanat2Mm, etKalinligiMm, boyMm, adet, hedefFiyatTl, baskiliMi, centikliMi, kilitliMi, gramaji } = req.body;
    console.log('Corner detail data:', { kanat1Mm, kanat2Mm, etKalinligiMm, boyMm, adet });
    
    const detail = await prisma.cornerDetail.create({
      data: {
        leadId: req.params.id,
        kanat1Mm: parseFloat(kanat1Mm),
        kanat2Mm: parseFloat(kanat2Mm),
        etKalinligiMm: parseFloat(etKalinligiMm),
        boyMm: parseFloat(boyMm),
        adet: parseInt(adet),
        hedefFiyatTl: hedefFiyatTl ? parseFloat(hedefFiyatTl) : null,
        baskiliMi: Boolean(baskiliMi),
        centikliMi: Boolean(centikliMi),
        kilitliMi: Boolean(kilitliMi),
        gramaji: gramaji ? parseFloat(gramaji) : null,
        createdBy: user.id
      }
    });
    
    console.log('Corner detail created:', detail.id);
    res.json(detail);
  } catch (err) { 
    console.error('Corner detail creation error:', err);
    next(err); 
  }
});

export default leadsRouter;
