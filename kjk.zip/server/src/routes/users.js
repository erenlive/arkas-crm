import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { prisma } from '../utils/prisma.js';
import { requireAuth, requireRole } from '../middleware/auth.js';

export const usersRouter = Router();

// List users (for filters). Admin can see all; users see all basic info (id, name, email, role)
usersRouter.get('/', requireAuth, async (req, res, next) => {
  try {
    const users = await prisma.user.findMany({ 
      select: { 
        id: true, 
        name: true, 
        email: true, 
        role: true, 
        position: true, 
        phone: true,
        createdAt: true 
      }, 
      orderBy: { name: 'asc' } 
    });
    res.json(users);
  } catch (err) { next(err); }
});

// Get single user (Admin only)
usersRouter.get('/:id', requireAuth, requireRole('ADMIN'), async (req, res, next) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.params.id },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        position: true,
        phone: true,
        createdAt: true,
        updatedAt: true
      }
    });
    
    if (!user) {
      return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
    }
    
    res.json(user);
  } catch (err) { next(err); }
});

// Create user (Admin only)
usersRouter.post('/', requireAuth, requireRole('ADMIN'), async (req, res, next) => {
  try {
    const { name, email, password, role = 'USER', position, phone } = req.body;
    
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Ad, email ve şifre gerekli' });
    }
    
    // Check if email already exists
    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) {
      return res.status(409).json({ error: 'Bu email adresi zaten kullanılıyor' });
    }
    
    // Hash password
    const passwordHash = await bcrypt.hash(password, 10);
    
    const user = await prisma.user.create({
      data: {
        name,
        email,
        passwordHash,
        role,
        position,
        phone
      },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        position: true,
        phone: true,
        createdAt: true
      }
    });
    
    res.status(201).json(user);
  } catch (err) { next(err); }
});

// Update user (Admin only)
usersRouter.put('/:id', requireAuth, requireRole('ADMIN'), async (req, res, next) => {
  try {
    const { name, email, role, position, phone, password } = req.body;
    const userId = req.params.id;
    
    // Check if user exists
    const existingUser = await prisma.user.findUnique({ where: { id: userId } });
    if (!existingUser) {
      return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
    }
    
    // Check if email is taken by another user
    if (email && email !== existingUser.email) {
      const emailTaken = await prisma.user.findUnique({ where: { email } });
      if (emailTaken) {
        return res.status(409).json({ error: 'Bu email adresi zaten kullanılıyor' });
      }
    }
    
    const updateData = {};
    if (name) updateData.name = name;
    if (email) updateData.email = email;
    if (role) updateData.role = role;
    if (position !== undefined) updateData.position = position;
    if (phone !== undefined) updateData.phone = phone;
    
    // Hash new password if provided
    if (password) {
      updateData.passwordHash = await bcrypt.hash(password, 10);
    }
    
    const user = await prisma.user.update({
      where: { id: userId },
      data: updateData,
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        position: true,
        phone: true,
        updatedAt: true
      }
    });
    
    res.json(user);
  } catch (err) { next(err); }
});

// Delete user (Admin only)
usersRouter.delete('/:id', requireAuth, requireRole('ADMIN'), async (req, res, next) => {
  try {
    const userId = req.params.id;
    
    // Check if user exists
    const existingUser = await prisma.user.findUnique({ where: { id: userId } });
    if (!existingUser) {
      return res.status(404).json({ error: 'Kullanıcı bulunamadı' });
    }
    
    // Prevent deleting yourself
    if (userId === req.user.id) {
      return res.status(400).json({ error: 'Kendi hesabınızı silemezsiniz' });
    }
    
    await prisma.user.delete({ where: { id: userId } });
    
    res.json({ message: 'Kullanıcı silindi' });
  } catch (err) { next(err); }
});
