import { Router } from 'express';
import { prisma } from '../utils/prisma.js';
import { requireAuth } from '../middleware/auth.js';

export const customersRouter = Router();

customersRouter.get('/', requireAuth, async (req, res, next) => {
  try {
    const customers = await prisma.customer.findMany({
      orderBy: { createdAt: 'desc' },
      include: { region: true, owner: true }
    });
    res.json(customers);
  } catch (err) { next(err); }
});

customersRouter.get('/:id', requireAuth, async (req, res, next) => {
  try {
    console.log('Looking for customer with ID:', req.params.id);
    
    const customer = await prisma.customer.findUnique({ 
      where: { id: req.params.id },
      include: {
        region: { select: { name: true } }
      }
    });
    
    if (!customer) {
      console.log('Customer not found with ID:', req.params.id);
      
      // Belki bu bir lead ID'sidir, kontrol edelim
      const lead = await prisma.lead.findUnique({ where: { id: req.params.id } });
      if (lead) {
        return res.status(400).json({ 
          error: 'Bu bir lead kaydı, müşteri kaydı değil',
          leadCompany: lead.company 
        });
      }
      
      return res.status(404).json({ error: 'Müşteri bulunamadı' });
    }
    
    res.json(customer);
  } catch (err) { next(err); }
});

customersRouter.put('/:id', requireAuth, async (req, res, next) => {
  try {
    const updated = await prisma.customer.update({ where: { id: req.params.id }, data: req.body });
    res.json(updated);
  } catch (err) { next(err); }
});

customersRouter.delete('/:id', requireAuth, async (req, res, next) => {
  try {
    await prisma.customer.delete({ where: { id: req.params.id } });
    res.json({ ok: true });
  } catch (err) { next(err); }
});

// Köşebent Detayları
customersRouter.get('/:id/corner-details', requireAuth, async (req, res, next) => {
  try {
    const details = await prisma.cornerDetail.findMany({
      where: { customerId: req.params.id },
      orderBy: { createdAt: 'desc' }
    });
    res.json(details);
  } catch (err) { next(err); }
});

customersRouter.post('/:id/corner-details', requireAuth, async (req, res, next) => {
  try {
    const { kanat1Mm, kanat2Mm, etKalinligiMm, boyMm, adet, hedefFiyatTl, baskiliMi, centikliMi, kilitliMi, gramaji } = req.body;
    const detail = await prisma.cornerDetail.create({
      data: {
        customerId: req.params.id,
        kanat1Mm,
        kanat2Mm,
        etKalinligiMm,
        boyMm,
        adet,
        hedefFiyatTl,
        baskiliMi,
        centikliMi,
        kilitliMi,
        gramaji,
        createdBy: req.user.id
      }
    });
    res.json(detail);
  } catch (err) { next(err); }
});

customersRouter.put('/corner-details/:detailId', requireAuth, async (req, res, next) => {
  try {
    const updated = await prisma.cornerDetail.update({
      where: { id: req.params.detailId },
      data: req.body
    });
    res.json(updated);
  } catch (err) { next(err); }
});

customersRouter.delete('/corner-details/:detailId', requireAuth, async (req, res, next) => {
  try {
    await prisma.cornerDetail.delete({ where: { id: req.params.detailId } });
    res.json({ ok: true });
  } catch (err) { next(err); }
});

// Update customer
customersRouter.put('/:id', requireAuth, async (req, res, next) => {
  try {
    const { company, contactName, phone, email, regionId, avgRevenue, competitor, paymentTerms, productsUsed, notes } = req.body;
    
    const updated = await prisma.customer.update({
      where: { id: req.params.id },
      data: {
        company,
        contactName,
        phone,
        email,
        regionId: regionId || null,
        avgRevenue,
        competitor,
        paymentTerms,
        productsUsed,
        notes
      },
      include: {
        region: { select: { name: true } }
      }
    });
    
    res.json(updated);
  } catch (err) { next(err); }
});

// Delete customer (Admin only)
customersRouter.delete('/:id', requireAuth, async (req, res, next) => {
  try {
    // Check if user is admin
    if (req.user.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Bu işlem için admin yetkisi gerekli' });
    }
    
    await prisma.customer.delete({ where: { id: req.params.id } });
    res.json({ ok: true });
  } catch (err) { next(err); }
});

export default customersRouter;
