import { Router } from 'express';
import { prisma } from '../utils/prisma.js';
import { requireAuth } from '../middleware/auth.js';

export const visitReportsRouter = Router();

visitReportsRouter.get('/', requireAuth, async (req, res, next) => {
  try {
    const { entityType, userId, from, to } = req.query;
    const where = {};
    if (entityType) where.entityType = entityType;
    if (userId) where.userId = userId;
    if (from || to) {
      where.date = {};
      if (from) where.date.gte = new Date(from);
      if (to) where.date.lte = new Date(to);
    }
    
    const reports = await prisma.visitReport.findMany({ 
      where, 
      orderBy: { date: 'desc' },
      include: {
        user: { select: { name: true } }
      }
    });

    // Her rapor için firma bilgisini ekle
    const reportsWithCompany = await Promise.all(reports.map(async (report) => {
      let company = null;
      if (report.entityType === 'lead') {
        const lead = await prisma.lead.findUnique({ 
          where: { id: report.entityId }, 
          select: { company: true } 
        });
        company = lead?.company;
      } else if (report.entityType === 'customer') {
        const customer = await prisma.customer.findUnique({ 
          where: { id: report.entityId }, 
          select: { company: true } 
        });
        company = customer?.company;
      }
      return { ...report, company };
    }));

    res.json(reportsWithCompany);
  } catch (err) { next(err); }
});

visitReportsRouter.post('/', requireAuth, async (req, res, next) => {
  try {
    const { entityType, entityId, date, title, notes, outcome, attachments } = req.body;
    if (!entityType || !entityId || !date || !title) {
      return res.status(400).json({ error: 'entityType, entityId, date, title required' });
    }
    const report = await prisma.visitReport.create({
      data: {
        entityType,
        entityId,
        userId: req.user.id,
        date: new Date(date),
        title,
        notes,
        outcome,
        attachments
      }
    });

    // Optional automation: update lead status on specific outcomes
    if (entityType === 'lead' && outcome) {
      if (outcome.toLowerCase().startsWith('kazanılmadı')) {
        await prisma.lead.update({ where: { id: entityId }, data: { status: 'CONTACTED_UNWON' } });
      } else if (outcome.toLowerCase() === 'kazanıldı') {
        await prisma.lead.update({ where: { id: entityId }, data: { status: 'WON' } });
      }
    }

    await prisma.activity.create({
      data: {
        entityType,
        entityId,
        activityType: 'VISIT',
        userId: req.user.id,
        note: `${title}${outcome ? ` - ${outcome}` : ''}`
      }
    });

    res.status(201).json(report);
  } catch (err) { next(err); }
});

visitReportsRouter.put('/:id', requireAuth, async (req, res, next) => {
  try {
    const updated = await prisma.visitReport.update({
      where: { id: req.params.id },
      data: req.body
    });
    res.json(updated);
  } catch (err) { next(err); }
});

visitReportsRouter.delete('/:id', requireAuth, async (req, res, next) => {
  try {
    // Sadece admin silebilir
    if (req.user.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Sadece admin ziyaret raporu silebilir' });
    }
    
    await prisma.visitReport.delete({ where: { id: req.params.id } });
    
    // Log kaydı
    await prisma.log.create({
      data: {
        userId: req.user.id,
        action: 'VISIT_REPORT_DELETED',
        meta: JSON.stringify({ reportId: req.params.id })
      }
    });
    
    res.json({ ok: true });
  } catch (err) { next(err); }
});
