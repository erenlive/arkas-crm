import express from 'express';
import { PrismaClient } from '@prisma/client';
import { requireAuth } from '../middleware/auth.js';

const quotesRouter = express.Router();
const prisma = new PrismaClient();

// Get all quotes
quotesRouter.get('/', requireAuth, async (req, res, next) => {
  try {
    const quotes = await prisma.quote.findMany({
      include: {
        customer: { select: { company: true, contactName: true } },
        lead: { select: { company: true, contactName: true } },
        creator: { select: { name: true, email: true, position: true, phone: true } },
        items: true
      },
      orderBy: { createdAt: 'desc' }
    });
    res.json(quotes);
  } catch (err) { next(err); }
});

// Get quote by ID
quotesRouter.get('/:id', requireAuth, async (req, res, next) => {
  try {
    const quote = await prisma.quote.findUnique({
      where: { id: req.params.id },
      include: {
        customer: {
          include: {
            region: { select: { name: true } }
          }
        },
        lead: {
          include: {
            region: { select: { name: true } }
          }
        },
        creator: { select: { name: true, email: true, position: true, phone: true } },
        items: { orderBy: { createdAt: 'asc' } }
      }
    });
    
    if (!quote) {
      return res.status(404).json({ error: 'Teklif bulunamadı' });
    }
    
    res.json(quote);
  } catch (err) { next(err); }
});

// Create new quote
quotesRouter.post('/', requireAuth, async (req, res, next) => {
  try {
    const { customerId, leadId, paymentTerms, paymentMethod, shippingIncluded, validUntil, notes, items } = req.body;
    
    // Generate quote number
    const quoteNumber = `TKF-${Date.now()}`;
    
    // Calculate total amount
    const totalAmount = items.reduce((sum, item) => sum + item.totalPrice, 0);
    
    const quote = await prisma.quote.create({
      data: {
        customerId,
        leadId,
        quoteNumber,
        paymentTerms,
        paymentMethod,
        shippingIncluded,
        validUntil: new Date(validUntil),
        totalAmount,
        notes,
        createdBy: req.user.id,
        items: {
          create: items.map(item => ({
            kanat1Mm: parseFloat(item.kanat1Mm),
            kanat2Mm: parseFloat(item.kanat2Mm),
            etKalinligiMm: parseFloat(item.etKalinligiMm),
            boyMm: parseFloat(item.boyMm),
            cornerType: item.cornerType,
            hasPrint: Boolean(item.hasPrint),
            quantity: parseInt(item.quantity),
            unitPrice: parseFloat(item.unitPrice),
            totalPrice: parseFloat(item.unitPrice) * parseInt(item.quantity)
          }))
        }
      },
      include: {
        customer: { select: { company: true, contactName: true } },
        creator: { select: { name: true, email: true, position: true, phone: true } },
        items: true
      }
    });
    
    res.status(201).json(quote);
  } catch (err) { next(err); }
});

// Update quote status and tracking
quotesRouter.patch('/:id/status', requireAuth, async (req, res, next) => {
  try {
    const { status, result, downloadedAt, sentAt } = req.body;
    
    const updateData = {};
    if (status) updateData.status = status;
    if (result) updateData.result = result;
    if (downloadedAt) updateData.downloadedAt = new Date(downloadedAt);
    if (sentAt) updateData.sentAt = new Date(sentAt);
    
    const updated = await prisma.quote.update({
      where: { id: req.params.id },
      data: updateData,
      include: {
        customer: { select: { company: true, contactName: true } },
        creator: { select: { name: true, email: true, position: true, phone: true } },
        items: true
      }
    });
    res.json(updated);
  } catch (err) { next(err); }
});

// Mark quote as downloaded
quotesRouter.patch('/:id/download', requireAuth, async (req, res, next) => {
  try {
    const quote = await prisma.quote.update({
      where: { id: req.params.id },
      data: { 
        downloadedAt: new Date(),
        status: 'SENT'
      }
    });
    
    res.json({ success: true });
  } catch (err) { next(err); }
});

// Delete quote
quotesRouter.delete('/:id', requireAuth, async (req, res, next) => {
  try {
    await prisma.quote.delete({ where: { id: req.params.id } });
    res.json({ ok: true });
  } catch (err) { next(err); }
});

export default quotesRouter;
