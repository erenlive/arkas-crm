-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Quote" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "customerId" TEXT,
    "leadId" TEXT,
    "quoteNumber" TEXT NOT NULL,
    "paymentTerms" TEXT NOT NULL,
    "paymentMethod" TEXT NOT NULL,
    "shippingIncluded" BOOLEAN NOT NULL DEFAULT true,
    "validUntil" DATETIME NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'DRAFT',
    "result" TEXT NOT NULL DEFAULT 'PENDING',
    "downloadedAt" DATETIME,
    "sentAt" DATETIME,
    "totalAmount" REAL,
    "notes" TEXT,
    "createdBy" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "Quote_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "Customer" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "Quote_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES "Lead" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "Quote_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES "User" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_Quote" ("createdAt", "createdBy", "customerId", "downloadedAt", "id", "notes", "paymentMethod", "paymentTerms", "quoteNumber", "result", "sentAt", "shippingIncluded", "status", "totalAmount", "updatedAt", "validUntil") SELECT "createdAt", "createdBy", "customerId", "downloadedAt", "id", "notes", "paymentMethod", "paymentTerms", "quoteNumber", "result", "sentAt", "shippingIncluded", "status", "totalAmount", "updatedAt", "validUntil" FROM "Quote";
DROP TABLE "Quote";
ALTER TABLE "new_Quote" RENAME TO "Quote";
CREATE UNIQUE INDEX "Quote_quoteNumber_key" ON "Quote"("quoteNumber");
CREATE INDEX "Quote_customerId_idx" ON "Quote"("customerId");
CREATE INDEX "Quote_leadId_idx" ON "Quote"("leadId");
CREATE INDEX "Quote_status_idx" ON "Quote"("status");
CREATE INDEX "Quote_createdAt_idx" ON "Quote"("createdAt");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
