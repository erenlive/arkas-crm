import dotenv from 'dotenv';
dotenv.config();

import bcrypt from 'bcryptjs';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding database...');

  // Users
  const password = await bcrypt.hash('123456', 10);
  const [admin, s1, s2] = await Promise.all([
    prisma.user.upsert({ 
      where: { email: 'admin@arkas.com' }, 
      update: { position: 'Sistem Yöneticisi', phone: '+90 262 255 56 54' }, 
      create: { name: 'Zeynep Yılmaz', email: 'admin@arkas.com', passwordHash: password, role: 'ADMIN', position: 'Sistem Yöneticisi', phone: '+90 262 255 56 54' } 
    }),
    prisma.user.upsert({ 
      where: { email: 'satis1@arkas.com' }, 
      update: { position: 'Satış Temsilcisi', phone: '+90 555 123 45 67' }, 
      create: { name: 'Ahmet Kaya', email: 'satis1@arkas.com', passwordHash: password, role: 'USER', position: 'Satış Temsilcisi', phone: '+90 555 123 45 67' } 
    }),
    prisma.user.upsert({ 
      where: { email: 'satis2@arkas.com' }, 
      update: { position: 'Satış Uzmanı', phone: '+90 555 987 65 43' }, 
      create: { name: 'Fatma Demir', email: 'satis2@arkas.com', passwordHash: password, role: 'USER', position: 'Satış Uzmanı', phone: '+90 555 987 65 43' } 
    }),
  ]);

  // Cities (81 il - alfabetik sıralı)
  const cityNames = [
    'Adana', 'Adıyaman', 'Afyonkarahisar', 'Ağrı', 'Aksaray', 'Amasya', 'Ankara', 'Antalya', 
    'Ardahan', 'Artvin', 'Aydın', 'Balıkesir', 'Bartın', 'Batman', 'Bayburt', 'Bilecik', 
    'Bingöl', 'Bitlis', 'Bolu', 'Burdur', 'Bursa', 'Çanakkale', 'Çankırı', 'Çorum', 
    'Denizli', 'Diyarbakır', 'Düzce', 'Edirne', 'Elazığ', 'Erzincan', 'Erzurum', 'Eskişehir', 
    'Gaziantep', 'Giresun', 'Gümüşhane', 'Hakkâri', 'Hatay', 'Iğdır', 'Isparta', 'İstanbul', 
    'İzmir', 'Kahramanmaraş', 'Karabük', 'Karaman', 'Kars', 'Kastamonu', 'Kayseri', 'Kilis', 
    'Kırıkkale', 'Kırklareli', 'Kırşehir', 'Kocaeli', 'Konya', 'Kütahya', 'Malatya', 'Manisa', 
    'Mardin', 'Mersin', 'Muğla', 'Muş', 'Nevşehir', 'Niğde', 'Ordu', 'Osmaniye', 
    'Rize', 'Sakarya', 'Samsun', 'Siirt', 'Sinop', 'Sivas', 'Şanlıurfa', 'Şırnak', 
    'Tekirdağ', 'Tokat', 'Trabzon', 'Tunceli', 'Uşak', 'Van', 'Yalova', 'Yozgat', 'Zonguldak'
  ];
  const regions = [];
  for (const name of cityNames) {
    const r = await prisma.region.upsert({ where: { name }, update: {}, create: { name } });
    regions.push(r);
  }

  // Products
  const productNames = ['Köşebent', 'Mukavva', 'Streç Film', 'Koli', 'Bant'];
  for (const name of productNames) {
    await prisma.product.upsert({ where: { name }, update: {}, create: { name } });
  }

  // Email templates (upsert per item)
  const templates = [
    {
      name: 'İlk İletişim',
      subjectTemplate: 'Arkas Ambalaj - İş Birliği Fırsatı',
      bodyTemplate: '<p>Merhaba {{firma}} - {{yetkili}},<br/> Arkanızda Arkas Ambalaj ile güçlü bir çözüm ortağı...</p>',
      createdBy: admin.id
    },
    {
      name: 'Takip Maili',
      subjectTemplate: 'Teklif Takibi - Arkas Ambalaj',
      bodyTemplate: '<p>Merhaba {{yetkili}},<br/> Göndermiş olduğumuz teklif ile ilgili geri dönüşünüzü rica ederiz.</p>',
      createdBy: admin.id
    },
    {
      name: 'Ziyaret Hatırlatma',
      subjectTemplate: 'Ziyaret Hatırlatması - Arkas Ambalaj',
      bodyTemplate: '<p>Merhaba {{yetkili}},<br/> {{tarih_önerileri}} tarihleri için uygunluğunuzu rica ederiz.</p>',
      createdBy: admin.id
    }
  ];
  for (const t of templates) {
    await prisma.emailTemplate.upsert({
      where: { id: `tpl_${t.name}` },
      update: { subjectTemplate: t.subjectTemplate, bodyTemplate: t.bodyTemplate, createdBy: t.createdBy },
      create: { ...t }
    }).catch(async () => {
      // Fallback: try find by name (no unique constraint on name in schema)
      const existing = await prisma.emailTemplate.findFirst({ where: { name: t.name } });
      if (!existing) await prisma.emailTemplate.create({ data: t });
    });
  }

  // Sample leads (şehir bazlı)
  const istanbulId = regions.find(r => r.name === 'İstanbul')?.id || regions[33].id;
  const ankaraId = regions.find(r => r.name === 'Ankara')?.id || regions[5].id;
  const izmirId = regions.find(r => r.name === 'İzmir')?.id || regions[34].id;
  const bursaId = regions.find(r => r.name === 'Bursa')?.id || regions[15].id;
  const adanaId = regions.find(r => r.name === 'Adana')?.id || regions[0].id;
  const antalyaId = regions.find(r => r.name === 'Antalya')?.id || regions[6].id;
  const kocaeliId = regions.find(r => r.name === 'Kocaeli')?.id || regions[40].id;
  const konyaId = regions.find(r => r.name === 'Konya')?.id || regions[41].id;

  const sampleLeads = [
    { company: 'ABC Gıda A.Ş.', contactName: 'Ayşe Yılmaz', email: 'ayse@abc.com', phone: '555-111-2233', regionId: istanbulId, avgRevenue: 150000, status: 'TO_CALL', ownerUserId: s1.id },
    { company: 'XYZ Kimya', contactName: 'Mehmet Demir', email: 'mehmet@xyz.com', phone: '555-222-3344', regionId: ankaraId, avgRevenue: 220000, status: 'EMAIL_SENT', ownerUserId: s1.id },
    { company: 'Delta Lojistik', contactName: 'Elif Kaya', email: 'elif@delta.com', phone: '555-333-4455', regionId: izmirId, avgRevenue: 90000, status: 'PRICE_REJECTED', ownerUserId: s2.id },
    { company: 'Omega Otomotiv', contactName: 'Ahmet Ar', email: 'ahmet@omega.com', phone: '555-444-5566', regionId: bursaId, avgRevenue: 300000, status: 'WON', ownerUserId: s2.id },
    { company: 'Beta Tekstil', contactName: 'Zeynep Kara', email: 'zeynep@beta.com', phone: '555-777-8899', regionId: adanaId, avgRevenue: 180000, status: 'VISIT_WAITING', ownerUserId: s1.id },
    { company: 'Gamma İnşaat', contactName: 'Ali Veli', email: 'ali@gamma.com', phone: '555-999-1122', regionId: antalyaId, avgRevenue: 250000, status: 'SAMPLE_TAKEN', ownerUserId: s2.id },
    { company: 'Epsilon Enerji', contactName: 'Fatma Öz', email: 'fatma@epsilon.com', phone: '555-333-7788', regionId: kocaeliId, avgRevenue: 320000, status: 'PRICE_GIVEN', ownerUserId: s1.id },
    { company: 'Zeta Makine', contactName: 'Hasan Demir', email: 'hasan@zeta.com', phone: '555-666-4455', regionId: konyaId, avgRevenue: 95000, status: 'PAYMENT_ISSUE', ownerUserId: s2.id },
  ];
  for (const l of sampleLeads) {
    await prisma.lead.create({ data: l });
  }

  console.log('Seeding done.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
