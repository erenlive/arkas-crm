import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function fixQuoteCreators() {
  try {
    // Get the sales user (satis1@arkas.com)
    const salesUser = await prisma.user.findUnique({
      where: { email: 'satis1@arkas.com' }
    });

    if (!salesUser) {
      console.log('Sales user not found');
      return;
    }

    // Update all quotes to be created by sales user instead of admin
    const result = await prisma.quote.updateMany({
      data: {
        createdBy: salesUser.id
      }
    });

    console.log(`Updated ${result.count} quotes to be created by ${salesUser.name}`);
  } catch (error) {
    console.error('Error:', error);
  } finally {
    await prisma.$disconnect();
  }
}

fixQuoteCreators();
